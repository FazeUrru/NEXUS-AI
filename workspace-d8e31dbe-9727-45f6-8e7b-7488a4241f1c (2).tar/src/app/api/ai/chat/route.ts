import { NextRequest, NextResponse } from 'next/server';

// Intelligent response generator
function generateIntelligentResponse(message: string): string {
  const lowerMessage = message.toLowerCase().trim();
  
  // Greeting patterns
  if (lowerMessage.match(/^(hola|hi|hello|hey|buenos días|buenas tardes|buenas noches|buenos|buenas)/)) {
    return `¡Hola! 👋 Soy **NexusAI 7.5**, tu asistente de inteligencia artificial avanzada.

**¿En qué puedo ayudarte hoy?**

- 💬 **Chat inteligente** - Respondo cualquier pregunta
- 📝 **Generación de contenido** - Artículos, emails, posts
- 💻 **Programación** - Código en cualquier lenguaje
- 🎨 **Creación de imágenes** - Arte con IA
- 🔍 **Investigación** - Análisis profundo de temas
- 📊 **Análisis de datos** - Insights automáticos

Simplemente escribe tu consulta y te ayudaré de inmediato.`;
  }
  
  // Math questions
  const mathMatch = lowerMessage.match(/(?:cuánto es|cuanto es|calcula|resuelve)\s*(\d+)\s*([+\-*/x])\s*(\d+)/i);
  if (mathMatch) {
    const num1 = parseFloat(mathMatch[1]);
    const operator = mathMatch[2];
    const num2 = parseFloat(mathMatch[3]);
    let result: number;
    let operation: string;
    
    switch (operator) {
      case '+':
        result = num1 + num2;
        operation = 'suma';
        break;
      case '-':
        result = num1 - num2;
        operation = 'resta';
        break;
      case '*':
      case 'x':
        result = num1 * num2;
        operation = 'multiplicación';
        break;
      case '/':
        result = num2 !== 0 ? num1 / num2 : NaN;
        operation = 'división';
        break;
      default:
        result = NaN;
        operation = 'operación';
    }
    
    if (!isNaN(result)) {
      return `🧮 **Cálculo matemático**

La ${operation} de **${num1}** y **${num2}** es:

## ${result}

¿Necesitas algún otro cálculo?`;
    }
  }
  
  // Capital city questions - improved pattern matching
  const capitalPatterns = [
    /capital\s+(?:de\s+)?(.+)/i,
    /cu[áa]l\s+es\s+(?:la\s+)?capital\s+(?:de\s+)?(.+)/i,
  ];
  
  for (const pattern of capitalPatterns) {
    const capitalMatch = lowerMessage.match(pattern);
    if (capitalMatch) {
      const country = capitalMatch[1].trim().replace(/^[delal]+ /i, '');
      const capitals: Record<string, string> = {
        'francia': 'París 🗼',
        'españa': 'Madrid 🇪🇸',
        'méxico': 'Ciudad de México 🇲🇽',
        'mexico': 'Ciudad de México 🇲🇽',
        'argentina': 'Buenos Aires 🇦🇷',
        'colombia': 'Bogotá 🇨🇴',
        'perú': 'Lima 🇵🇪',
        'peru': 'Lima 🇵🇪',
        'chile': 'Santiago 🇨🇱',
        'brasil': 'Brasilia 🇧🇷',
        'estados unidos': 'Washington D.C. 🇺🇸',
        'usa': 'Washington D.C. 🇺🇸',
        'italia': 'Roma 🇮🇹',
        'alemania': 'Berlín 🇩🇪',
        'japón': 'Tokio 🇯🇵',
        'japon': 'Tokio 🇯🇵',
        'china': 'Pekín (Beijing) 🇨🇳',
        'inglaterra': 'Londres 🇬🇧',
        'reino unido': 'Londres 🇬🇧',
        'portugal': 'Lisboa 🇵🇹',
        'canadá': 'Ottawa 🇨🇦',
        'canada': 'Ottawa 🇨🇦',
        'rusia': 'Moscú 🇷🇺',
        'corea del sur': 'Seúl 🇰🇷',
        'australia': 'Canberra 🇦🇺',
        'india': 'Nueva Delhi 🇮🇳',
        'egipto': 'El Cairo 🇪🇬',
      };
      
      const capital = capitals[country.toLowerCase()];
      if (capital) {
        return `🌍 **Geografía**

La capital de **${country.charAt(0).toUpperCase() + country.slice(1)}** es **${capital}**

¿Quieres saber más sobre algún otro país?`;
      }
      break;
    }
  }
  
  // Code-related
  if (lowerMessage.includes('código') || lowerMessage.includes('code') || lowerMessage.includes('programar') || lowerMessage.includes('función') || lowerMessage.includes('function')) {
    return `💻 **Ayuda con Programación**

Puedo ayudarte con código en múltiples lenguajes:

| Lenguaje | Uso principal |
|----------|---------------|
| JavaScript/TypeScript | Web, Node.js |
| Python | IA, Data Science |
| Java | Enterprise |
| C/C++ | Sistemas |
| Rust | Seguridad |
| Go | Microservicios |

**Ejemplo de función Python:**
\`\`\`python
def fibonacci(n):
    """Calcula el n-ésimo número de Fibonacci"""
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Uso
print(fibonacci(10))  # Output: 55
\`\`\`

**Ejemplo de JavaScript:**
\`\`\`javascript
// Función async para obtener datos
async function fetchData(url) {
  const response = await fetch(url);
  return response.json();
}
\`\`\`

¿En qué lenguaje o proyecto específico necesitas ayuda?`;
  }
  
  // Image-related
  if (lowerMessage.includes('imagen') || lowerMessage.includes('image') || lowerMessage.includes('dibujo') || lowerMessage.includes('foto')) {
    return `🎨 **Generación de Imágenes con IA**

Para crear imágenes, ve a la función **"Generar Imágenes"** en el menú lateral.

**Tips para mejores resultados:**

1. **Sé específico** - Describe colores, estilos, atmósfera
2. **Añade detalles** - "estilo pintura al óleo", "fotorrealista", "anime"
3. **Define composición** - "primer plano", "paisaje", "retrato"

**Ejemplos de prompts efectivos:**
- "Un dragón azul sobre montañas nevadas al atardecer, estilo fantástico"
- "Retrato de mujer con gafas, luz cinematográfica, fondo bokeh"
- "Ciudad futurista con coches voladores, cyberpunk, neón"

¿Te gustaría que te ayude a crear un prompt para tu imagen?`;
  }
  
  // Help-related
  if (lowerMessage.includes('ayuda') || lowerMessage.includes('help') || lowerMessage.includes('qué puedes') || lowerMessage.includes('que puedes') || lowerMessage.includes('qué haces')) {
    return `✨ **Capacidades de NexusAI 7.5**

**🤖 Asistentes**
- **Chat IA** - Conversación inteligente
- **Chat Privado** - Cifrado E2E
- **Modo Agente** - Ejecuta tareas automáticamente
- **Modo Pensar** - Razonamiento paso a paso
- **Investigación Profunda** - Análisis exhaustivo

**🎨 Creación**
- Generar Imágenes - Arte con IA
- Presentaciones - Slides automáticos
- Documentos - PDFs y Docs
- Contenido - Artículos, posts

**💻 Desarrollo**
- Código - Cualquier lenguaje
- Páginas Web - Landing pages
- Aplicaciones - Apps completas
- Juegos - Interactivos
- Fullstack - Proyectos completos

**📊 Análisis**
- Análisis de Datos - Insights
- Investigación - Temas profundos
- Búsqueda Web - Tiempo real

**🆕 Novedades v7.5**
- Scroll inteligente
- Sin errores de hidratación
- CAPTCHA de seguridad
- Mejor rendimiento

¿Qué te gustaría probar?`;
  }
  
  // Weather (simulated)
  if (lowerMessage.includes('clima') || lowerMessage.includes('tiempo') || lowerMessage.includes('weather')) {
    return `🌤️ **Información del Clima**

Para información del clima en tiempo real, usa la función **Búsqueda Web**.

Sin embargo, puedo ayudarte con:
- Planificación de viajes
- Ropa adecuada por temporada
- Actividades según el clima

¿Sobre qué ciudad quieres información?`;
  }
  
  // Translation
  if (lowerMessage.includes('traducir') || lowerMessage.includes('translate') || lowerMessage.includes('inglés') || lowerMessage.includes('english')) {
    return `🌐 **Traducción**

Puedo ayudarte a traducir texto. Usa la función **Traducción** en el menú de Análisis, o dime el texto aquí.

**Idiomas disponibles:**
- Español ↔ English
- Español ↔ Português
- Español ↔ Français
- Español ↔ Deutsch
- Español ↔ Italiano
- Y 50+ idiomas más

¿Qué texto quieres traducir?`;
  }
  
  // Who are you
  if (lowerMessage.includes('quién eres') || lowerMessage.includes('quien eres') || lowerMessage.includes('qué eres') || lowerMessage.includes('que eres') || lowerMessage.includes('tu nombre') || lowerMessage.includes('your name')) {
    return `🤖 **Sobre NexusAI 7.5**

Soy **NexusAI 7.5**, un asistente de inteligencia artificial avanzado creado en 2026.

**Mis características:**
- 🧠 Múltiples modelos de IA (GPT-5, Claude, Grok, Gemini...)
- 🔒 Seguridad con CAPTCHA obligatorio
- 💬 Conversación natural en español
- 🎨 Generación de imágenes y contenido
- 💻 Asistencia en programación
- 📊 Análisis de datos

**Versión actual:** 7.5.0
**Estado:** Sistema Estable ✅

¿En qué puedo ayudarte hoy?`;
  }
  
  // Jokes
  if (lowerMessage.includes('chiste') || lowerMessage.includes('joke') || lowerMessage.includes('risa')) {
    const jokes = [
      "¿Por qué los programadores prefieren el modo oscuro? Porque la luz atrae bugs. 🐛",
      "Hay 10 tipos de personas: los que entienden binario y los que no. 💻",
      "¿Qué le dijo un HTML a un CSS? '¡Tienes mucho estilo!' 🎨",
      "Un SQL query entra a un bar, se acerca a dos tablas y pregunta: '¿Puedo unirme?' 🍺",
      "¿Por qué Java y JavaScript se llevan mal? Porque Java piensa que JavaScript le robó parte del nombre. ☕",
    ];
    const randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
    return `😂 **Un poco de humor**

${randomJoke}

¿Quieres otro chiste o puedo ayudarte con algo más?`;
  }
  
  // Thanks
  if (lowerMessage.includes('gracias') || lowerMessage.includes('thanks') || lowerMessage.includes('thank you')) {
    return `¡De nada! 😊 

Estoy aquí para ayudarte siempre que lo necesites.

**¿Hay algo más en lo que pueda asistirte?**

- 💬 Más preguntas
- 💻 Ayuda con código
- 🎨 Crear imágenes
- 📝 Generar contenido`;
  }
  
  // Goodbye
  if (lowerMessage.match(/^(adiós|adios|bye|chau|hasta luego|nos vemos)/)) {
    return `¡Hasta luego! 👋

Fue un placer ayudarte. Vuelve cuando quieras.

**NexusAI 7.5** siempre está disponible para ti. 🤖✨`;
  }
  
  // Default intelligent response
  return `📝 **Entendido**

He recibido tu mensaje: "${message.slice(0, 150)}${message.length > 150 ? '...' : ''}"

**Puedo ayudarte mejor si me dices:**
- Si es una **pregunta específica**
- Si necesitas **código** en algún lenguaje
- Si quieres **generar contenido**
- Si necesitas **analizar** algo

**Comandos útiles:**
- "Ayuda" - Ver todas las funciones
- "Código" - Ayuda de programación
- "Imagen" - Generar imágenes
- "Traducir" - Traducción de textos

¿En qué puedo ayudarte específicamente?`;
}

export async function POST(request: NextRequest) {
  try {
    // Parse request body with validation
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ response: 'Error: No se pudo procesar la solicitud. Por favor, inténtalo de nuevo.' });
    }
    
    const { message, thinkMode, agentMode } = body;

    // Validate input
    if (!message || typeof message !== 'string') {
      return NextResponse.json({ response: 'Por favor, escribe un mensaje para continuar.' });
    }

    // Limit message length
    if (message.length > 10000) {
      return NextResponse.json({ response: 'Tu mensaje es muy largo. Por favor, reduce el contenido a menos de 10,000 caracteres.' });
    }

    // Generate intelligent response
    const response = generateIntelligentResponse(message);
    
    return NextResponse.json({ response });

  } catch (error) {
    console.error('Chat API error:', error);
    return NextResponse.json({ 
      response: 'Lo siento, ha ocurrido un error. Por favor, inténtalo de nuevo.' 
    });
  }
}
