'use client';

import { useAppStore } from '@/store';
import { Sidebar } from '@/components/layout/sidebar';
import { FeatureArea } from '@/components/features/feature-area';
import { SettingsModal } from '@/components/modals/settings-modal';
import { ProfileModal } from '@/components/modals/profile-modal';
import { AuthScreen } from '@/components/auth/auth-screen';
import { ThemeProvider } from 'next-themes';

export default function Home() {
  const { isAuthenticated, login } = useAppStore();

  if (!isAuthenticated) {
    return (
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <AuthScreen onAuth={login} />
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <div className="flex h-screen bg-background overflow-hidden">
        <Sidebar />
        <main className="flex-1 flex flex-col overflow-hidden min-w-0">
          <div className="flex-1 overflow-hidden">
            <FeatureArea />
          </div>
          <footer className="border-t py-3 px-6 bg-card shrink-0">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>© 2026 NexusAI v7.7 - Plataforma de IA Avanzada</span>
              <div className="flex items-center gap-4">
                <span className="hidden sm:inline">v7.7.0</span>
                <span className="flex items-center gap-1">
                  <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  Sistema Estable
                </span>
              </div>
            </div>
          </footer>
        </main>
        <SettingsModal />
        <ProfileModal />
      </div>
    </ThemeProvider>
  );
}
