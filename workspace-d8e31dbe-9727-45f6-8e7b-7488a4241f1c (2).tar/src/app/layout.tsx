import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "NexusAI 7.6 - Plataforma de Inteligencia Artificial",
  description: "Tu plataforma completa de IA con 30+ funcionalidades, Sistema de créditos, Planes Pro/Premium/Business y más. Versión 7.6",
  keywords: ["IA", "Inteligencia Artificial", "GPT-5", "Claude", "Grok", "Gemini", "Chat IA", "Agente IA", "Créditos", "Planes"],
  authors: [{ name: "NexusAI Team" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}
