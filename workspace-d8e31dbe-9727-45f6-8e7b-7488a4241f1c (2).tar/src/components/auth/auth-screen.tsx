'use client';

import { useState, useSyncExternalStore, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Captcha } from '@/components/ui/captcha';
import { 
  Sparkles, 
  Mail, 
  Lock, 
  User, 
  Eye, 
  EyeOff, 
  Github, 
  Chrome,
  ArrowRight,
  Loader2,
  CheckCircle2,
  ShieldCheck,
  ShieldX
} from 'lucide-react';

interface AuthScreenProps {
  onAuth: (user: { name: string; email: string }) => void;
}

// Custom hook to detect if we're on the client
function useIsClient() {
  return useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  );
}

export function AuthScreen({ onAuth }: AuthScreenProps) {
  const isClient = useIsClient();
  
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const [loginCaptchaVerified, setLoginCaptchaVerified] = useState(false);
  const [registerCaptchaVerified, setRegisterCaptchaVerified] = useState(false);
  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);

  const handleLoginSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginCaptchaVerified) return;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsLoading(false);
    onAuth({ name: name || 'Usuario', email: email || 'usuario@nexusai.com' });
  }, [loginCaptchaVerified, name, email, onAuth]);

  const handleRegisterSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!registerCaptchaVerified || !acceptTerms) return;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsLoading(false);
    onAuth({ name: name || 'Usuario', email: email || 'usuario@nexusai.com' });
  }, [registerCaptchaVerified, acceptTerms, name, email, onAuth]);

  const handleSocialLogin = useCallback(async (provider: string) => {
    const captchaVerified = mode === 'login' ? loginCaptchaVerified : registerCaptchaVerified;
    if (!captchaVerified) return;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    setIsLoading(false);
    onAuth({ name: 'Usuario', email: `usuario@${provider}.com` });
  }, [mode, loginCaptchaVerified, registerCaptchaVerified, onAuth]);

  const handleModeChange = useCallback((newMode: string) => {
    setMode(newMode as 'login' | 'register');
    setLoginCaptchaVerified(false);
    setRegisterCaptchaVerified(false);
  }, []);

  const currentCaptchaVerified = mode === 'login' ? loginCaptchaVerified : registerCaptchaVerified;

  // Show loading state until mounted on client
  if (!isClient) {
    return (
      <div className="min-h-screen w-full flex bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg shadow-emerald-500/30 animate-pulse">
            <Sparkles className="h-9 w-9 text-white" />
          </div>
          <Loader2 className="h-6 w-6 animate-spin text-emerald-500" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full flex bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-center items-center p-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-600/20 via-teal-600/10 to-transparent" />
        
        <div className="absolute top-20 left-20 w-72 h-72 bg-emerald-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-teal-500/20 rounded-full blur-3xl" />
        
        <div className="relative z-10 text-center max-w-lg">
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg shadow-emerald-500/30">
              <Sparkles className="h-9 w-9 text-white" />
            </div>
            <span className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              NexusAI 7.6
            </span>
          </div>
          
          <h1 className="text-4xl font-bold text-white mb-4">
            El Futuro de la IA está Aquí
          </h1>
          <p className="text-lg text-slate-300 mb-8">
            Tu plataforma de inteligencia artificial más avanzada. Chat, código, imágenes y más.
          </p>
          
          <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
            {[
              { label: 'Modelos IA', value: '15+' },
              { label: 'Funciones', value: '30+' },
              { label: 'Idiomas', value: '50+' },
              { label: 'Usuarios', value: '1M+' },
            ].map((stat) => (
              <div key={stat.label} className="bg-white/5 rounded-lg p-4 border border-white/10">
                <div className="text-2xl font-bold text-emerald-400">{stat.value}</div>
                <div className="text-sm text-slate-400">{stat.label}</div>
              </div>
            ))}
          </div>
          
          <div className="mt-8 flex items-center justify-center gap-2 text-slate-400">
            <ShieldCheck className="h-5 w-5 text-emerald-400" />
            <span className="text-sm">Protegido con verificación anti-bots obligatoria</span>
          </div>
        </div>
      </div>

      {/* Right Side - Auth Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-4 sm:p-6 md:p-12 overflow-y-auto">
        <div className="w-full max-w-md py-8">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center justify-center gap-2 mb-8">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600">
              <Sparkles className="h-7 w-7 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
              NexusAI 7.6
            </span>
          </div>

          {/* Captcha Status Banner */}
          {!currentCaptchaVerified && (
            <div className="mb-4 p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg flex items-center gap-2">
              <ShieldX className="h-5 w-5 text-amber-400 shrink-0" />
              <p className="text-sm text-amber-300">
                <strong>Verificación requerida:</strong> Debes completar el captcha para continuar.
              </p>
            </div>
          )}

          <Card className="bg-white/5 backdrop-blur-xl border-white/10 shadow-2xl">
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-2xl text-white">
                {mode === 'login' ? 'Bienvenido de Nuevo' : 'Crear Cuenta'}
              </CardTitle>
              <CardDescription className="text-slate-400">
                {mode === 'login' 
                  ? 'Ingresa a tu cuenta para continuar' 
                  : 'Comienza tu viaje con IA hoy'}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pt-4">
              <Tabs value={mode} onValueChange={handleModeChange}>
                <TabsList className="grid w-full grid-cols-2 bg-white/5 mb-6">
                  <TabsTrigger value="login" className="data-[state=active]:bg-emerald-600">
                    Iniciar Sesión
                  </TabsTrigger>
                  <TabsTrigger value="register" className="data-[state=active]:bg-emerald-600">
                    Registrarse
                  </TabsTrigger>
                </TabsList>

                {/* Login Form */}
                <TabsContent value="login">
                  <form onSubmit={handleLoginSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-slate-300">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                        <Input
                          id="email"
                          type="email"
                          placeholder="tu@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-emerald-500"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-slate-300">Contraseña</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                        <Input
                          id="password"
                          type={showPassword ? 'text' : 'password'}
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="pl-10 pr-10 bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-emerald-500"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>

                    {/* CAPTCHA - MUST BE VERIFIED */}
                    <Captcha onVerify={setLoginCaptchaVerified} />

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="remember" className="border-white/20" />
                        <label htmlFor="remember" className="text-sm text-slate-400">Recordarme</label>
                      </div>
                      <Button 
                        type="button" 
                        variant="link" 
                        className="text-emerald-400 p-0 h-auto"
                        disabled={!loginCaptchaVerified}
                      >
                        ¿Olvidaste tu contraseña?
                      </Button>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 disabled:cursor-not-allowed"
                      disabled={isLoading || !loginCaptchaVerified}
                    >
                      {isLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : !loginCaptchaVerified ? (
                        <>
                          <ShieldX className="h-4 w-4 mr-2" />
                          Verifica el captcha primero
                        </>
                      ) : (
                        <>
                          Iniciar Sesión
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </form>
                </TabsContent>

                {/* Register Form */}
                <TabsContent value="register">
                  <form onSubmit={handleRegisterSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-slate-300">Nombre</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                        <Input
                          id="name"
                          type="text"
                          placeholder="Tu nombre"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-emerald-500"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="register-email" className="text-slate-300">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                        <Input
                          id="register-email"
                          type="email"
                          placeholder="tu@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-emerald-500"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="register-password" className="text-slate-300">Contraseña</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                        <Input
                          id="register-password"
                          type={showPassword ? 'text' : 'password'}
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="pl-10 pr-10 bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-emerald-500"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="confirm-password" className="text-slate-300">Confirmar Contraseña</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                        <Input
                          id="confirm-password"
                          type="password"
                          placeholder="••••••••"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-emerald-500"
                        />
                      </div>
                    </div>

                    {/* CAPTCHA - MUST BE VERIFIED */}
                    <Captcha onVerify={setRegisterCaptchaVerified} />

                    <div className="flex items-start space-x-2">
                      <Checkbox 
                        id="terms" 
                        checked={acceptTerms}
                        onCheckedChange={(checked) => setAcceptTerms(checked as boolean)}
                        className="border-white/20 mt-0.5"
                        disabled={!registerCaptchaVerified}
                      />
                      <label htmlFor="terms" className="text-sm text-slate-400 leading-tight">
                        Acepto los <span className="text-emerald-400">Términos</span> y{' '}
                        <span className="text-emerald-400">Privacidad</span>
                      </label>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 disabled:cursor-not-allowed"
                      disabled={isLoading || !acceptTerms || !registerCaptchaVerified}
                    >
                      {isLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : !registerCaptchaVerified ? (
                        <>
                          <ShieldX className="h-4 w-4 mr-2" />
                          Verifica el captcha primero
                        </>
                      ) : (
                        <>
                          Crear Cuenta
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>

              <div className="relative my-6">
                <Separator className="bg-white/10" />
                <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-slate-900 px-3 text-sm text-slate-500">
                  o continúa con
                </span>
              </div>

              {/* Social Login Buttons - ALSO REQUIRE CAPTCHA */}
              <div className="grid grid-cols-2 gap-3">
                <Button 
                  type="button"
                  variant="outline" 
                  className="bg-white/5 border-white/10 text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
                  onClick={() => handleSocialLogin('google')}
                  disabled={!currentCaptchaVerified || isLoading}
                >
                  <Chrome className="mr-2 h-4 w-4" />
                  Google
                  {!currentCaptchaVerified && <ShieldX className="ml-2 h-3 w-3 text-amber-400" />}
                </Button>
                <Button 
                  type="button"
                  variant="outline" 
                  className="bg-white/5 border-white/10 text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
                  onClick={() => handleSocialLogin('github')}
                  disabled={!currentCaptchaVerified || isLoading}
                >
                  <Github className="mr-2 h-4 w-4" />
                  GitHub
                  {!currentCaptchaVerified && <ShieldX className="ml-2 h-3 w-3 text-amber-400" />}
                </Button>
              </div>
              
              {!currentCaptchaVerified && (
                <p className="text-xs text-amber-400 text-center mt-3">
                  Verifica el captcha para desbloquear los botones de inicio social
                </p>
              )}
            </CardContent>
          </Card>

          {/* Features Preview */}
          <div className="mt-6 grid grid-cols-3 gap-2">
            {['Chat IA', 'Generar Código', 'Análisis'].map((feature) => (
              <div key={feature} className="bg-white/5 rounded-lg p-3 text-center border border-white/5">
                <CheckCircle2 className="h-4 w-4 text-emerald-400 mx-auto mb-1" />
                <span className="text-xs text-slate-400">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
