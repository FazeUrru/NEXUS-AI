'use client';

import { useAppStore, FEATURES, FeatureType } from '@/store';
import { ChatFeature } from './chat-feature';
import { ImageGenFeature } from './image-gen-feature';
import { CodeGenFeature } from './code-gen-feature';
import { TextAnalysisFeature } from './text-analysis-feature';
import { TranslationFeature } from './translation-feature';
import { SummarizeFeature } from './summarize-feature';
import { ContentGenFeature } from './content-gen-feature';
import { SentimentFeature } from './sentiment-feature';
import { IdeasFeature } from './ideas-feature';
import { GrammarFeature } from './grammar-feature';
import { TitlesFeature } from './titles-feature';
import { ExplainFeature } from './explain-feature';
import { EmailGenFeature } from './email-gen-feature';
import { StoryGenFeature } from './story-gen-feature';
import { CodeAssistantFeature } from './code-assistant-feature';
// v4.0 Features
import { PresentationsFeature } from './presentations-feature';
import { DocumentsFeature } from './documents-feature';
import { WebPagesFeature } from './web-pages-feature';
import { AppsFeature } from './apps-feature';
import { GamesFeature } from './games-feature';
import { UIDesignerFeature } from './ui-designer-feature';
import { FullstackFeature } from './fullstack-feature';
import { DeepResearchFeature } from './deep-research-feature';
import { WebSearchFeature } from './web-search-feature';
// v5.0 Beta Features
import { WritingFeature } from './writing-feature';
import { DataAnalysisFeature } from './data-analysis-feature';
import { MagicDesignFeature } from './magic-design-feature';
// v7.6 Pricing
import { PricingFeature } from './pricing-feature';

const featureComponents: Record<FeatureType, React.ComponentType> = {
  // v7.6 Pricing
  'pricing': PricingFeature,
  // Core
  'chat': ChatFeature,
  'chat-private': ChatFeature,
  'image-gen': ImageGenFeature,
  'code-gen': CodeGenFeature,
  'text-analysis': TextAnalysisFeature,
  'translation': TranslationFeature,
  'summarize': SummarizeFeature,
  'content-gen': ContentGenFeature,
  'sentiment': SentimentFeature,
  'ideas': IdeasFeature,
  'grammar': GrammarFeature,
  'titles': TitlesFeature,
  'explain': ExplainFeature,
  'email-gen': EmailGenFeature,
  'story-gen': StoryGenFeature,
  'code-assistant': CodeAssistantFeature,
  // v4.0
  'presentations': PresentationsFeature,
  'documents': DocumentsFeature,
  'web-pages': WebPagesFeature,
  'apps': AppsFeature,
  'games': GamesFeature,
  'ui-designer': UIDesignerFeature,
  'fullstack': FullstackFeature,
  'deep-research': DeepResearchFeature,
  'think-mode': ChatFeature,
  'web-search': WebSearchFeature,
  // v5.0 Beta
  'agent-mode': ChatFeature,
  'writing': WritingFeature,
  'data-analysis': DataAnalysisFeature,
  'magic-design': MagicDesignFeature,
};

export function FeatureArea() {
  const { activeFeature } = useAppStore();
  const feature = FEATURES.find(f => f.id === activeFeature);
  const FeatureComponent = featureComponents[activeFeature];

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="border-b bg-card px-6 py-4 shrink-0">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold">{feature?.name}</h1>
          {feature?.isNew && (
            <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${
              feature.badge === 'Beta' 
                ? 'bg-purple-100 text-purple-700 dark:bg-purple-900/50 dark:text-purple-300'
                : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-300'
            }`}>
              {feature.badge}
            </span>
          )}
        </div>
        <p className="text-muted-foreground mt-1">{feature?.description}</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {FeatureComponent && <FeatureComponent />}
      </div>
    </div>
  );
}
