'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Image as ImageIcon, Loader2, Download, RefreshCw, AlertCircle, CheckCircle2, Lock } from 'lucide-react';
import { toast } from 'sonner';

export function ImageGenFeature() {
  const { isLoading, setIsLoading, useImageCredit, getImagesRemaining, creditState } = useAppStore();
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState('realistic');
  const [size, setSize] = useState('1024x1024');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isFallback, setIsFallback] = useState(false);
  
  const imagesRemaining = getImagesRemaining();
  const canGenerate = imagesRemaining === -1 || imagesRemaining > 0;
  
  // Store the function reference
  const consumeImageCredit = useImageCredit;

  const handleGenerate = useCallback(async () => {
    if (!prompt.trim() || isLoading) return;
    
    // Check image limit
    if (!canGenerate) {
      toast.error('Has alcanzado el límite diario de imágenes. ¡Mejora tu plan para más!');
      return;
    }
    
    // Validate prompt length
    if (prompt.length > 2000) {
      toast.error('El prompt es demasiado largo. Máximo 2000 caracteres.');
      return;
    }

    // Use image credit
    const creditUsed = consumeImageCredit();
    if (!creditUsed) {
      toast.error('No tienes suficientes créditos para generar una imagen.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setIsFallback(false);
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000); // 60 second timeout

      const response = await fetch('/api/ai/image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          style,
          size,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data.image) {
        setGeneratedImage(data.image);
        setIsFallback(data.fallback || false);
        if (data.fallback) {
          toast.info('Se usó una imagen de respaldo. Intenta de nuevo para mejores resultados.');
        } else {
          toast.success('¡Imagen generada exitosamente!');
        }
      } else {
        throw new Error('No se recibió imagen del servidor');
      }
    } catch (err) {
      console.error('Error generating image:', err);
      if (err instanceof Error && err.name === 'AbortError') {
        setError('La solicitud tardó demasiado. Por favor, intenta de nuevo.');
        toast.error('Tiempo de espera agotado');
      } else {
        setError('Error al generar la imagen. Por favor, intenta de nuevo.');
        toast.error('Error al generar la imagen');
      }
    } finally {
      setIsLoading(false);
    }
  }, [prompt, style, size, isLoading, setIsLoading, canGenerate, consumeImageCredit]);

  const handleDownload = useCallback(async () => {
    if (!generatedImage) return;
    
    try {
      const response = await fetch(generatedImage);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `nexusai-image-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('Imagen descargada');
    } catch {
      toast.error('Error al descargar la imagen');
    }
  }, [generatedImage]);

  const handleRegenerate = useCallback(() => {
    setGeneratedImage(null);
    setError(null);
    setIsFallback(false);
    handleGenerate();
  }, [handleGenerate]);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Credit Limit Banner */}
        <div className={`flex items-center justify-between p-3 rounded-lg ${
          canGenerate 
            ? 'bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800' 
            : 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800'
        }`}>
          <div className="flex items-center gap-2">
            {canGenerate ? (
              <>
                <ImageIcon className="h-4 w-4 text-emerald-600" />
                <span className="text-sm text-emerald-700 dark:text-emerald-300">
                  {imagesRemaining === -1 
                    ? 'Imágenes ilimitadas' 
                    : `${imagesRemaining} imágenes restantes hoy`
                  }
                </span>
              </>
            ) : (
              <>
                <Lock className="h-4 w-4 text-red-600" />
                <span className="text-sm text-red-700 dark:text-red-300">
                  Límite diario alcanzado
                </span>
              </>
            )}
          </div>
          <Badge variant={canGenerate ? 'secondary' : 'destructive'}>
            Plan: {creditState.plan.charAt(0).toUpperCase() + creditState.plan.slice(1)}
          </Badge>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ImageIcon className="h-5 w-5 text-emerald-600" />
              Generador de Imágenes IA
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Descripción de la imagen</Label>
              <Textarea
                value={prompt}
                onChange={(e) => {
                  setPrompt(e.target.value);
                  setError(null);
                }}
                placeholder="Describe la imagen que quieres crear en detalle..."
                className="min-h-32 resize-none"
                maxLength={2000}
              />
              <p className="text-xs text-muted-foreground text-right">
                {prompt.length}/2000 caracteres
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Estilo</Label>
                <Select value={style} onValueChange={setStyle}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="realistic">Realista</SelectItem>
                    <SelectItem value="artistic">Artístico</SelectItem>
                    <SelectItem value="cartoon">Cartoon</SelectItem>
                    <SelectItem value="anime">Anime</SelectItem>
                    <SelectItem value="3d">3D Render</SelectItem>
                    <SelectItem value="watercolor">Acuarela</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Tamaño</Label>
                <Select value={size} onValueChange={setSize}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1024x1024">1024 x 1024 (Cuadrado)</SelectItem>
                    <SelectItem value="1344x768">1344 x 768 (Horizontal)</SelectItem>
                    <SelectItem value="768x1344">768 x 1344 (Vertical)</SelectItem>
                    <SelectItem value="1152x864">1152 x 864 (Horizontal)</SelectItem>
                    <SelectItem value="864x1152">864 x 1152 (Vertical)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-300">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span className="text-sm">{error}</span>
              </div>
            )}

            <Button
              onClick={handleGenerate}
              disabled={!prompt.trim() || isLoading || !canGenerate}
              className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generando imagen...
                </>
              ) : !canGenerate ? (
                <>
                  <Lock className="mr-2 h-4 w-4" />
                  Límite alcanzado - Mejora tu plan
                </>
              ) : (
                <>
                  <ImageIcon className="mr-2 h-4 w-4" />
                  Generar Imagen
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {generatedImage && (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                Imagen Generada
                {isFallback && (
                  <span className="text-xs font-normal text-muted-foreground">
                    (Imagen de respaldo)
                  </span>
                )}
              </CardTitle>
              {!isFallback && (
                <div className="flex items-center gap-1 text-emerald-600 text-sm">
                  <CheckCircle2 className="h-4 w-4" />
                  Generada con IA
                </div>
              )}
            </CardHeader>
            <CardContent>
              <div className="relative rounded-lg overflow-hidden bg-muted">
                <img
                  src={generatedImage}
                  alt="Generated"
                  className="w-full h-auto"
                  loading="lazy"
                />
              </div>
              <div className="flex gap-2 mt-4">
                <Button 
                  variant="outline" 
                  className="flex-1" 
                  onClick={handleRegenerate}
                  disabled={isLoading}
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Regenerar
                </Button>
                <Button 
                  variant="outline" 
                  className="flex-1" 
                  onClick={handleDownload}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Descargar
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
