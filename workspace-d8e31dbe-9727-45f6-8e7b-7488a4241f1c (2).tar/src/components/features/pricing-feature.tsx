'use client';

import { useState, useEffect, useSyncExternalStore } from 'react';
import { useAppStore, PLAN_LIMITS, ANNUAL_PRICES, ANNUAL_DISCOUNT, OFFER_END_DATE, SubscriptionPlan, CURRENCY } from '@/store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { 
  Crown, Sparkles, Check, Zap, Infinity, Clock, 
  TrendingUp, Star, Gift, Shield, Users, Rocket,
  CreditCard, Lock, Calendar, CheckCircle2,
  Play, XCircle, AlertTriangle, Timer, Code,
  Settings, Bug, Eye, TestTube, Gauge, Key, 
  Heart, BarChart3
} from 'lucide-react';
import { toast } from 'sonner';

// Trial duration in days
const TRIAL_DAYS = 7;

function useIsClient() {
  return useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  );
}

// Countdown timer component - improved visibility
function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const isClient = useIsClient();

  useEffect(() => {
    if (!isClient) return;

    const updateTimer = () => {
      const now = new Date();
      const diff = OFFER_END_DATE.getTime() - now.getTime();

      if (diff > 0) {
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        setTimeLeft({ days, hours, minutes, seconds });
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [isClient]);

  if (!isClient) {
    return (
      <div className="flex items-center justify-center gap-2 sm:gap-3">
        {[0, 0, 0, 0].map((_, i) => (
          <div key={i} className="flex flex-col items-center">
            <div className="bg-white/20 text-white px-3 py-2 rounded-lg font-bold text-xl min-w-[50px] text-center">
              --
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center gap-2 sm:gap-3">
      <div className="flex flex-col items-center">
        <div className="bg-white text-rose-600 px-3 py-2 sm:px-4 sm:py-3 rounded-lg font-bold text-xl sm:text-2xl min-w-[50px] sm:min-w-[60px] text-center shadow-lg border-2 border-white/50">
          {timeLeft.days}
        </div>
        <span className="text-xs mt-1 text-white font-medium">Días</span>
      </div>
      <span className="text-2xl sm:text-3xl font-bold text-white">:</span>
      <div className="flex flex-col items-center">
        <div className="bg-white text-rose-600 px-3 py-2 sm:px-4 sm:py-3 rounded-lg font-bold text-xl sm:text-2xl min-w-[50px] sm:min-w-[60px] text-center shadow-lg border-2 border-white/50">
          {String(timeLeft.hours).padStart(2, '0')}
        </div>
        <span className="text-xs mt-1 text-white font-medium">Horas</span>
      </div>
      <span className="text-2xl sm:text-3xl font-bold text-white">:</span>
      <div className="flex flex-col items-center">
        <div className="bg-white text-rose-600 px-3 py-2 sm:px-4 sm:py-3 rounded-lg font-bold text-xl sm:text-2xl min-w-[50px] sm:min-w-[60px] text-center shadow-lg border-2 border-white/50">
          {String(timeLeft.minutes).padStart(2, '0')}
        </div>
        <span className="text-xs mt-1 text-white font-medium">Min</span>
      </div>
      <span className="text-2xl sm:text-3xl font-bold text-white">:</span>
      <div className="flex flex-col items-center">
        <div className="bg-white text-rose-600 px-3 py-2 sm:px-4 sm:py-3 rounded-lg font-bold text-xl sm:text-2xl min-w-[50px] sm:min-w-[60px] text-center shadow-lg border-2 border-white/50">
          {String(timeLeft.seconds).padStart(2, '0')}
        </div>
        <span className="text-xs mt-1 text-white font-medium">Seg</span>
      </div>
    </div>
  );
}

// Trial Countdown Timer Component
function TrialCountdownTimer({ trialStartDate }: { trialStartDate: string }) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0, expired: false });
  const isClient = useIsClient();

  useEffect(() => {
    if (!isClient || !trialStartDate) return;

    const calculateTimeLeft = () => {
      const startDate = new Date(trialStartDate);
      const endDate = new Date(startDate.getTime() + TRIAL_DAYS * 24 * 60 * 60 * 1000);
      const now = new Date();
      const diff = endDate.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, expired: true });
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds, expired: false });
    };

    calculateTimeLeft();
    const interval = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(interval);
  }, [isClient, trialStartDate]);

  if (!isClient || !trialStartDate) return null;

  if (timeLeft.expired) {
    return (
      <div className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 px-4 py-3 rounded-lg text-center font-medium">
        ¡Tu prueba gratis ha terminado! Tu plan será activado próximamente.
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-amber-100 to-orange-100 dark:from-amber-900/30 dark:to-orange-900/30 rounded-lg p-4">
      <div className="flex items-center gap-2 mb-3">
        <Timer className="h-5 w-5 text-amber-600" />
        <span className="font-bold text-amber-700 dark:text-amber-300">
          Tu prueba gratis termina en:
        </span>
      </div>
      <div className="flex items-center justify-center gap-2 text-center">
        <div className="flex flex-col items-center">
          <div className="bg-white dark:bg-amber-800 text-amber-700 dark:text-amber-200 px-3 py-2 rounded-lg font-bold text-2xl min-w-[50px] shadow">
            {timeLeft.days}
          </div>
          <span className="text-xs mt-1 text-amber-600 dark:text-amber-400 font-medium">días</span>
        </div>
        <span className="font-bold text-2xl text-amber-600">:</span>
        <div className="flex flex-col items-center">
          <div className="bg-white dark:bg-amber-800 text-amber-700 dark:text-amber-200 px-3 py-2 rounded-lg font-bold text-2xl min-w-[50px] shadow">
            {String(timeLeft.hours).padStart(2, '0')}
          </div>
          <span className="text-xs mt-1 text-amber-600 dark:text-amber-400 font-medium">hrs</span>
        </div>
        <span className="font-bold text-2xl text-amber-600">:</span>
        <div className="flex flex-col items-center">
          <div className="bg-white dark:bg-amber-800 text-amber-700 dark:text-amber-200 px-3 py-2 rounded-lg font-bold text-2xl min-w-[50px] shadow">
            {String(timeLeft.minutes).padStart(2, '0')}
          </div>
          <span className="text-xs mt-1 text-amber-600 dark:text-amber-400 font-medium">min</span>
        </div>
        <span className="font-bold text-2xl text-amber-600">:</span>
        <div className="flex flex-col items-center">
          <div className="bg-white dark:bg-amber-800 text-amber-700 dark:text-amber-200 px-3 py-2 rounded-lg font-bold text-2xl min-w-[50px] shadow">
            {String(timeLeft.seconds).padStart(2, '0')}
          </div>
          <span className="text-xs mt-1 text-amber-600 dark:text-amber-400 font-medium">seg</span>
        </div>
      </div>
      <p className="text-center text-xs text-amber-600 dark:text-amber-400 mt-3">
        Cancela antes de que termine para evitar cargos
      </p>
    </div>
  );
}

// Payment Form Component with Trial Option
function PaymentForm({ 
  plan, 
  price, 
  billingPeriod, 
  onSuccess, 
  onCancel 
}: { 
  plan: SubscriptionPlan; 
  price: number;
  billingPeriod: 'monthly' | 'annual';
  onSuccess: () => void;
  onCancel: () => void;
}) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [cardData, setCardData] = useState({
    number: '',
    expiry: '',
    cvc: '',
    name: '',
    email: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    return parts.length ? parts.join(' ') : value;
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.slice(0, 2) + '/' + v.slice(2, 4);
    }
    return v;
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!cardData.name.trim()) newErrors.name = 'Nombre requerido';
    if (!cardData.email.trim() || !cardData.email.includes('@')) newErrors.email = 'Email válido requerido';
    if (cardData.number.replace(/\s/g, '').length < 16) newErrors.number = 'Número de tarjeta inválido';
    if (cardData.expiry.length < 5) newErrors.expiry = 'Fecha inválida';
    if (cardData.cvc.length < 3) newErrors.cvc = 'CVC inválido';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    
    setIsProcessing(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    setIsProcessing(false);
    onSuccess();
  };

  const planInfo = PLAN_LIMITS[plan];
  const finalPrice = billingPeriod === 'annual' 
    ? ANNUAL_PRICES[plan].annual 
    : price;

  return (
    <div className="space-y-4">
      {/* Trial Banner */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-lg p-4 text-center">
        <div className="flex items-center justify-center gap-2 mb-1">
          <Play className="h-5 w-5" />
          <span className="font-bold text-lg">¡Prueba Gratis {TRIAL_DAYS} Días!</span>
        </div>
        <p className="text-sm opacity-90">
          No se te cobrará hasta que termine tu prueba
        </p>
      </div>

      {/* Order Summary */}
      <div className="bg-muted/50 rounded-lg p-4">
        <div className="flex justify-between items-center mb-2">
          <span className="font-medium">{planInfo.name}</span>
          <Badge className="bg-emerald-600">-{Math.round(ANNUAL_DISCOUNT * 100)}%</Badge>
        </div>
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>{billingPeriod === 'annual' ? 'Facturación anual' : 'Facturación mensual'}</span>
          <span className="font-bold text-foreground">{finalPrice.toFixed(2)}{CURRENCY}</span>
        </div>
        {billingPeriod === 'annual' && (
          <div className="text-xs text-emerald-600 mt-1">
            Ahorras {(price * 12 - finalPrice).toFixed(2)}{CURRENCY} al año
          </div>
        )}
        <div className="text-xs text-muted-foreground mt-2">
          Primer cobro después de {TRIAL_DAYS} días
        </div>
      </div>

      <Separator />

      {/* Payment Form */}
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <Label htmlFor="name">Nombre completo</Label>
            <Input
              id="name"
              placeholder="Juan Pérez"
              value={cardData.name}
              onChange={(e) => setCardData({ ...cardData, name: e.target.value })}
              className={errors.name ? 'border-red-500' : ''}
            />
            {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name}</p>}
          </div>
          
          <div className="col-span-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="juan@ejemplo.com"
              value={cardData.email}
              onChange={(e) => setCardData({ ...cardData, email: e.target.value })}
              className={errors.email ? 'border-red-500' : ''}
            />
            {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
          </div>
          
          <div className="col-span-2">
            <Label htmlFor="card">Número de tarjeta</Label>
            <div className="relative">
              <Input
                id="card"
                placeholder="1234 5678 9012 3456"
                value={cardData.number}
                onChange={(e) => setCardData({ ...cardData, number: formatCardNumber(e.target.value) })}
                maxLength={19}
                className={errors.number ? 'border-red-500 pr-10' : 'pr-10'}
              />
              <CreditCard className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
            {errors.number && <p className="text-xs text-red-500 mt-1">{errors.number}</p>}
          </div>
          
          <div>
            <Label htmlFor="expiry">Fecha de expiración</Label>
            <Input
              id="expiry"
              placeholder="MM/YY"
              value={cardData.expiry}
              onChange={(e) => setCardData({ ...cardData, expiry: formatExpiry(e.target.value) })}
              maxLength={5}
              className={errors.expiry ? 'border-red-500' : ''}
            />
            {errors.expiry && <p className="text-xs text-red-500 mt-1">{errors.expiry}</p>}
          </div>
          
          <div>
            <Label htmlFor="cvc">CVC</Label>
            <Input
              id="cvc"
              placeholder="123"
              value={cardData.cvc}
              onChange={(e) => setCardData({ ...cardData, cvc: e.target.value.replace(/\D/g, '').slice(0, 4) })}
              maxLength={4}
              className={errors.cvc ? 'border-red-500' : ''}
            />
            {errors.cvc && <p className="text-xs text-red-500 mt-1">{errors.cvc}</p>}
          </div>
        </div>
      </div>

      {/* Security Info */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Lock className="h-3 w-3" />
        <span>Pago seguro con encriptación SSL</span>
      </div>

      {/* Actions */}
      <div className="flex gap-3 pt-2">
        <Button variant="outline" onClick={onCancel} disabled={isProcessing} className="flex-1">
          Cancelar
        </Button>
        <Button 
          onClick={handleSubmit} 
          disabled={isProcessing}
          className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
        >
          {isProcessing ? (
            <span className="flex items-center gap-2">
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
              Procesando...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <Play className="h-4 w-4" />
              Iniciar Prueba Gratis
            </span>
          )}
        </Button>
      </div>
    </div>
  );
}

// Trial Success Dialog
function TrialSuccessDialog({ 
  open, 
  onClose, 
  plan 
}: { 
  open: boolean; 
  onClose: () => void;
  plan: SubscriptionPlan;
}) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md text-center">
        <div className="py-6">
          <div className="mx-auto w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mb-4">
            <Play className="h-8 w-8 text-emerald-600" />
          </div>
          <DialogTitle className="text-2xl mb-2">¡Prueba Iniciada!</DialogTitle>
          <DialogDescription className="text-base">
            Tu prueba gratis de <strong>{TRIAL_DAYS} días</strong> del plan <strong>{PLAN_LIMITS[plan].name}</strong> ha comenzado.
          </DialogDescription>
          <div className="mt-6 p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
            <p className="text-sm text-muted-foreground">
              Recibirás un recordatorio antes de que termine tu prueba. 
              Puedes cancelar en cualquier momento sin cargo.
            </p>
          </div>
          <Button 
            onClick={onClose}
            className="mt-6 bg-emerald-600 hover:bg-emerald-700"
          >
            Comenzar a usar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

const planIcons: Record<SubscriptionPlan, React.ElementType> = {
  free: Gift,
  pro: Zap,
  premium: Crown,
  business: Rocket,
};

const planColors: Record<SubscriptionPlan, { gradient: string; border: string; bg: string; text: string }> = {
  free: { 
    gradient: 'from-gray-400 to-gray-500', 
    border: 'border-gray-300 dark:border-gray-700',
    bg: 'bg-gray-50 dark:bg-gray-900/20',
    text: 'text-gray-600 dark:text-gray-400'
  },
  pro: { 
    gradient: 'from-emerald-500 to-teal-600', 
    border: 'border-emerald-400 dark:border-emerald-700',
    bg: 'bg-emerald-50 dark:bg-emerald-900/20',
    text: 'text-emerald-600 dark:text-emerald-400'
  },
  premium: { 
    gradient: 'from-amber-500 to-orange-600', 
    border: 'border-amber-400 dark:border-amber-700',
    bg: 'bg-amber-50 dark:bg-amber-900/20',
    text: 'text-amber-600 dark:text-amber-400'
  },
  business: { 
    gradient: 'from-purple-500 to-indigo-600', 
    border: 'border-purple-400 dark:border-purple-700',
    bg: 'bg-purple-50 dark:bg-purple-900/20',
    text: 'text-purple-600 dark:text-purple-400'
  },
};

export function PricingFeature() {
  const isClient = useIsClient();
  const { creditState, changePlan, cancelPlan, developerSettings, updateDeveloperSettings } = useAppStore();
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'annual'>('annual');
  const [paymentPlan, setPaymentPlan] = useState<SubscriptionPlan | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [showDevSettings, setShowDevSettings] = useState(false);

  if (!isClient) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <Crown className="h-12 w-12 text-emerald-600" />
          <span className="text-muted-foreground">Cargando planes...</span>
        </div>
      </div>
    );
  }

  const isPaidPlan = creditState.plan !== 'free';
  const isDeveloper = developerSettings.isDeveloper && developerSettings.enabled;

  // Developer can select any plan for free
  const handleSelectPlan = (planId: SubscriptionPlan) => {
    if (isDeveloper && developerSettings.freePlanSelection) {
      changePlan(planId);
      toast.success(`Plan ${PLAN_LIMITS[planId].name} activado (Desarrollador)`);
      return;
    }
    
    if (planId === 'free') {
      changePlan(planId);
      toast.success('Plan Gratis activado');
    } else {
      setPaymentPlan(planId);
    }
  };

  const handlePaymentSuccess = () => {
    if (paymentPlan) {
      changePlan(paymentPlan);
      setPaymentPlan(null);
      setShowSuccess(true);
    }
  };

  const handleCancelPlan = () => {
    cancelPlan();
    setShowCancelDialog(false);
    toast.success('Plan cancelado. Ahora estás en el plan Gratis.');
  };

  return (
    <div className="h-full overflow-y-auto">
      {/* Hero Section with Timer */}
      <div className="bg-gradient-to-br from-rose-500 via-pink-500 to-rose-600 text-white">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:py-12">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-medium mb-4">
              <Sparkles className="h-4 w-4" />
              Oferta Especial de Lanzamiento v7.8
              {isDeveloper && (
                <Badge className="ml-2 bg-amber-500 text-white">
                  <Code className="h-3 w-3 mr-1" />
                  DEV
                </Badge>
              )}
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-3">
              Planes de Suscripción
            </h1>
            <p className="text-base sm:text-lg opacity-90 max-w-2xl mx-auto">
              Elige el plan perfecto para ti. Cancela cuando quieras.
            </p>
          </div>

          {/* Developer Badge */}
          {isDeveloper && (
            <div className="max-w-2xl mx-auto mb-6">
              <div className="bg-gradient-to-r from-amber-500 to-orange-500 rounded-xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                    <Code className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-white">Modo Desarrollador Activo</p>
                    <p className="text-sm text-white/80">Puedes elegir cualquier plan gratis</p>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowDevSettings(!showDevSettings)}
                  className="bg-white/20 border-white/30 text-white hover:bg-white/30"
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Ajustes Dev
                </Button>
              </div>
            </div>
          )}

          {/* Timer Banner */}
          <div className="max-w-2xl mx-auto">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 sm:p-6 border border-white/20">
              <div className="text-center mb-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Clock className="h-5 w-5" />
                  <span className="text-lg sm:text-xl font-bold">¡Oferta por Tiempo Limitado!</span>
                </div>
                <p className="text-sm sm:text-base opacity-90">
                  <span className="font-bold text-2xl sm:text-3xl">{Math.round(ANNUAL_DISCOUNT * 100)}% DE DESCUENTO</span>
                  <span className="block sm:inline sm:ml-2">en planes anuales hasta el 5 de Abril</span>
                </p>
              </div>
              <CountdownTimer />
            </div>
          </div>
        </div>
      </div>

      {/* Plans Section */}
      <div className="max-w-7xl mx-auto px-4 py-8 sm:py-12">
        {/* Developer Settings Panel */}
        {isDeveloper && showDevSettings && (
          <Card className="mb-6 border-2 border-amber-400 dark:border-amber-600 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/30 dark:to-orange-950/30">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-amber-700 dark:text-amber-400">
                <Code className="h-5 w-5" />
                Ajustes de Desarrollador (12 opciones)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* 1. Developer Mode Enabled */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Code className="h-4 w-4 text-amber-600" />
                    <span className="text-sm font-medium">Modo Dev Activo</span>
                  </div>
                  <Switch 
                    checked={developerSettings.enabled}
                    onCheckedChange={(checked) => updateDeveloperSettings({ enabled: checked })}
                  />
                </div>
                
                {/* 2. Is Developer */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Crown className="h-4 w-4 text-amber-600" />
                    <span className="text-sm font-medium">Es Desarrollador</span>
                  </div>
                  <Switch 
                    checked={developerSettings.isDeveloper}
                    onCheckedChange={(checked) => updateDeveloperSettings({ isDeveloper: checked })}
                  />
                </div>
                
                {/* 3. Auto Premium Plan */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Crown className="h-4 w-4 text-purple-600" />
                    <span className="text-sm font-medium">Auto Premium</span>
                  </div>
                  <Switch 
                    checked={developerSettings.autoPremiumPlan}
                    onCheckedChange={(checked) => updateDeveloperSettings({ autoPremiumPlan: checked })}
                  />
                </div>
                
                {/* 4. Free Plan Selection */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Gift className="h-4 w-4 text-emerald-600" />
                    <span className="text-sm font-medium">Planes Gratis</span>
                  </div>
                  <Switch 
                    checked={developerSettings.freePlanSelection}
                    onCheckedChange={(checked) => updateDeveloperSettings({ freePlanSelection: checked })}
                  />
                </div>
                
                {/* 5. Skip Payment */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <CreditCard className="h-4 w-4 text-blue-600" />
                    <span className="text-sm font-medium">Saltar Pago</span>
                  </div>
                  <Switch 
                    checked={developerSettings.skipPayment}
                    onCheckedChange={(checked) => updateDeveloperSettings({ skipPayment: checked })}
                  />
                </div>
                
                {/* 6. Unlimited Credits */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Zap className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm font-medium">Créditos Infinitos</span>
                  </div>
                  <Switch 
                    checked={developerSettings.unlimitedCredits}
                    onCheckedChange={(checked) => updateDeveloperSettings({ unlimitedCredits: checked })}
                  />
                </div>
                
                {/* 7. Unlimited Images */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-pink-600" />
                    <span className="text-sm font-medium">Imágenes Infinitas</span>
                  </div>
                  <Switch 
                    checked={developerSettings.unlimitedImages}
                    onCheckedChange={(checked) => updateDeveloperSettings({ unlimitedImages: checked })}
                  />
                </div>
                
                {/* 8. Debug Mode */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Bug className="h-4 w-4 text-red-600" />
                    <span className="text-sm font-medium">Modo Debug</span>
                  </div>
                  <Switch 
                    checked={developerSettings.debugMode}
                    onCheckedChange={(checked) => updateDeveloperSettings({ debugMode: checked })}
                  />
                </div>
                
                {/* 9. Show API Logs */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4 text-cyan-600" />
                    <span className="text-sm font-medium">Ver Logs API</span>
                  </div>
                  <Switch 
                    checked={developerSettings.showApiLogs}
                    onCheckedChange={(checked) => updateDeveloperSettings({ showApiLogs: checked })}
                  />
                </div>
                
                {/* 10. Beta Features */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <TestTube className="h-4 w-4 text-indigo-600" />
                    <span className="text-sm font-medium">Beta Features</span>
                  </div>
                  <Switch 
                    checked={developerSettings.enableBetaFeatures}
                    onCheckedChange={(checked) => updateDeveloperSettings({ enableBetaFeatures: checked })}
                  />
                </div>
                
                {/* 11. Bypass Rate Limits */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Gauge className="h-4 w-4 text-green-600" />
                    <span className="text-sm font-medium">Sin Límites Rate</span>
                  </div>
                  <Switch 
                    checked={developerSettings.bypassRateLimits}
                    onCheckedChange={(checked) => updateDeveloperSettings({ bypassRateLimits: checked })}
                  />
                </div>
                
                {/* 12. Custom Model Access */}
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Key className="h-4 w-4 text-orange-600" />
                    <span className="text-sm font-medium">Modelos Custom</span>
                  </div>
                  <Switch 
                    checked={developerSettings.customModelAccess}
                    onCheckedChange={(checked) => updateDeveloperSettings({ customModelAccess: checked })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Current Plan Info, Trial Timer & Cancel Button */}
        {isPaidPlan && (
          <div className="mb-6 space-y-4">
            <div className="p-4 bg-muted rounded-lg flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${planColors[creditState.plan].gradient} flex items-center justify-center`}>
                  {(() => {
                    const Icon = planIcons[creditState.plan];
                    return <Icon className="h-5 w-5 text-white" />;
                  })()}
                </div>
                <div>
                  <p className="font-medium">Plan Actual: <span className="text-emerald-600">{PLAN_LIMITS[creditState.plan].name}</span></p>
                  <p className="text-sm text-muted-foreground">
                    {PLAN_LIMITS[creditState.plan].price > 0 ? `${PLAN_LIMITS[creditState.plan].price}${CURRENCY}/mes` : 'Gratis'}
                  </p>
                </div>
              </div>
              <Button 
                variant="outline"
                className="text-red-600 border-red-300 hover:bg-red-50 dark:hover:bg-red-950/30"
                onClick={() => setShowCancelDialog(true)}
              >
                <XCircle className="h-4 w-4 mr-2" />
                Cancelar Plan
              </Button>
            </div>
            
            {/* Trial Countdown Timer */}
            {creditState.trialStartDate && (
              <TrialCountdownTimer trialStartDate={creditState.trialStartDate} />
            )}
          </div>
        )}

        {/* Free Trial Banner */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 px-4 py-2 rounded-full text-sm font-medium">
            <Play className="h-4 w-4" />
            Prueba GRATIS {TRIAL_DAYS} días en todos los planes
          </div>
        </div>

        {/* Billing Toggle */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex items-center gap-2 bg-muted p-1 rounded-lg">
            <Button
              variant={billingPeriod === 'monthly' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setBillingPeriod('monthly')}
              className={billingPeriod === 'monthly' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
            >
              Mensual
            </Button>
            <Button
              variant={billingPeriod === 'annual' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setBillingPeriod('annual')}
              className={billingPeriod === 'annual' ? 'bg-rose-500 hover:bg-rose-600' : ''}
            >
              <span>Anual</span>
              <Badge className="ml-2 bg-amber-500 text-white text-xs">-{Math.round(ANNUAL_DISCOUNT * 100)}%</Badge>
            </Button>
          </div>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-12">
          {(Object.entries(PLAN_LIMITS) as [SubscriptionPlan, typeof PLAN_LIMITS.free][]).map(([planId, plan]) => {
            const Icon = planIcons[planId];
            const colors = planColors[planId];
            const prices = ANNUAL_PRICES[planId];
            const isCurrentPlan = creditState.plan === planId;
            const displayPrice = billingPeriod === 'annual' ? prices.annualMonthly : prices.monthly;
            const annualPrice = prices.annual;

            return (
              <Card 
                key={planId}
                className={`relative overflow-hidden transition-all duration-300 hover:scale-105 hover:shadow-xl ${
                  plan.popular 
                    ? `border-2 ${colors.border} shadow-lg ring-2 ring-emerald-500/20` 
                    : ''
                } ${isCurrentPlan ? 'ring-2 ring-emerald-500' : ''}`}
              >
                {/* Popular Badge */}
                {plan.popular && (
                  <div className="absolute -top-0 left-0 right-0 bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-center py-1 text-xs font-bold flex items-center justify-center gap-1">
                    <Star className="h-3 w-3" /> MÁS POPULAR
                  </div>
                )}

                {/* Free Trial Badge */}
                {plan.price > 0 && (
                  <div className={`absolute ${plan.popular ? 'top-7' : 'top-2'} left-2`}>
                    <Badge className="bg-emerald-600 text-white text-xs">
                      <Play className="h-3 w-3 mr-1" />
                      {TRIAL_DAYS} días gratis
                    </Badge>
                  </div>
                )}

                {/* Current Plan Badge */}
                {isCurrentPlan && (
                  <div className="absolute top-2 right-2">
                    <Badge className="bg-emerald-600 text-white">Actual</Badge>
                  </div>
                )}

                <CardHeader className={`text-center ${plan.popular ? 'pt-12' : plan.price > 0 ? 'pt-10' : 'pt-6'} pb-2`}>
                  {/* Icon */}
                  <div className={`mx-auto w-14 h-14 rounded-full bg-gradient-to-br ${colors.gradient} flex items-center justify-center mb-3 shadow-lg`}>
                    <Icon className="h-7 w-7 text-white" />
                  </div>
                  
                  <CardTitle className="text-xl font-bold">{plan.name}</CardTitle>
                  
                  {/* Price */}
                  <div className="mt-3">
                    {plan.price === 0 ? (
                      <div className="text-3xl font-bold">Gratis</div>
                    ) : (
                      <>
                        <div className="flex items-baseline justify-center gap-1">
                          <span className="text-3xl sm:text-4xl font-bold">{displayPrice.toFixed(2)}{CURRENCY}</span>
                          <span className="text-muted-foreground text-sm">/mes</span>
                        </div>
                        {billingPeriod === 'annual' && (
                          <div className="mt-1">
                            <span className="text-sm text-muted-foreground line-through">{prices.monthly.toFixed(2)}{CURRENCY}/mes</span>
                            <span className="ml-2 text-xs text-emerald-600 font-medium">
                              {annualPrice.toFixed(2)}{CURRENCY}/año
                            </span>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Features */}
                  <ul className="space-y-2">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <Check className={`h-4 w-4 ${colors.text} shrink-0 mt-0.5`} />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA Button */}
                  <Button
                    className={`w-full ${
                      isCurrentPlan 
                        ? 'bg-muted text-muted-foreground' 
                        : `bg-gradient-to-r ${colors.gradient} hover:opacity-90`
                    }`}
                    disabled={isCurrentPlan}
                    onClick={() => handleSelectPlan(planId)}
                  >
                    {isCurrentPlan ? (
                      'Plan Actual'
                    ) : plan.price === 0 ? (
                      'Comenzar Gratis'
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Probar {TRIAL_DAYS} días gratis
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Trust Badges */}
        <div className="flex flex-wrap justify-center gap-4 sm:gap-8 mb-8">
          {[
            { icon: Play, text: `${TRIAL_DAYS} Días Gratis` },
            { icon: Shield, text: 'Pago Seguro SSL' },
            { icon: Clock, text: 'Cancelación Fácil' },
            { icon: Users, text: '+10,000 Usuarios' },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-2 text-muted-foreground">
              <item.icon className="h-4 w-4 sm:h-5 sm:w-5 text-emerald-600" />
              <span className="text-xs sm:text-sm">{item.text}</span>
            </div>
          ))}
        </div>

        {/* Guarantee */}
        <Card className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 border-emerald-200 dark:border-emerald-800">
          <CardContent className="p-4 sm:p-6 text-center">
            <Shield className="h-8 w-8 sm:h-10 sm:w-10 text-emerald-600 mx-auto mb-3" />
            <h3 className="text-base sm:text-lg font-bold mb-2">Garantía de Satisfacción {TRIAL_DAYS} Días</h3>
            <p className="text-xs sm:text-sm text-muted-foreground max-w-2xl mx-auto">
              Prueba cualquier plan gratis durante {TRIAL_DAYS} días. Si no estás satisfecho, 
              cancela antes de que termine la prueba y no se te cobrará nada.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Payment Dialog */}
      <Dialog open={!!paymentPlan} onOpenChange={() => setPaymentPlan(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Play className="h-5 w-5 text-emerald-600" />
              Iniciar Prueba Gratis
            </DialogTitle>
            <DialogDescription>
              Ingrese los datos de tu tarjeta. No se realizará ningún cargo hasta que termine tu prueba de {TRIAL_DAYS} días.
            </DialogDescription>
          </DialogHeader>
          {paymentPlan && (
            <PaymentForm
              plan={paymentPlan}
              price={PLAN_LIMITS[paymentPlan].price}
              billingPeriod={billingPeriod}
              onSuccess={handlePaymentSuccess}
              onCancel={() => setPaymentPlan(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Success Dialog */}
      <TrialSuccessDialog
        open={showSuccess}
        onClose={() => setShowSuccess(false)}
        plan={creditState.plan}
      />

      {/* Cancel Plan Dialog */}
      <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              Cancelar Plan
            </DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que quieres cancelar tu plan <strong>{PLAN_LIMITS[creditState.plan].name}</strong>?
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg p-4">
              <p className="text-sm text-red-700 dark:text-red-300 font-medium">
                Al cancelar tu plan:
              </p>
              <ul className="text-sm text-red-600 dark:text-red-400 mt-2 space-y-1">
                <li>• Perderás acceso a las funciones premium</li>
                <li>• Tus créditos volverán al límite gratuito</li>
                <li>• Se perderán los créditos mensuales extra</li>
              </ul>
            </div>
          </div>
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={() => setShowCancelDialog(false)}
              className="flex-1"
            >
              Mantener Plan
            </Button>
            <Button 
              variant="destructive"
              onClick={handleCancelPlan}
              className="flex-1"
            >
              <XCircle className="h-4 w-4 mr-2" />
              Cancelar Plan
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
