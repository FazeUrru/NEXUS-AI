'use client';

import { useAppStore, FEATURES, FeatureType } from '@/store';
import { cn } from '@/lib/utils';
import {
  MessageSquare, Image, Code, FileText, Languages, FileMinus,
  PenTool, Heart, Lightbulb, CheckCircle, Type, HelpCircle,
  Mail, BookOpen, Terminal, Settings, User, Sparkles, Zap,
  Brain, Lock, Search, Globe, Presentation, Layout, Smartphone,
  Gamepad2, Palette, Layers
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { CreditsDisplay } from '@/components/ui/credits-display';

const iconMap: Record<string, React.ElementType> = {
  MessageSquare,
  Lock,
  Image,
  Code,
  FileText,
  Languages,
  FileMinus,
  PenTool,
  Heart,
  Lightbulb,
  CheckCircle,
  Type,
  HelpCircle,
  Mail,
  BookOpen,
  Terminal,
  Search,
  Brain,
  Globe,
  Presentation,
  Layout,
  Smartphone,
  Gamepad2,
  Palette,
  Layers,
};

// Add FileSearch mapping (uses Search icon)
iconMap['FileSearch'] = Search;

const categoryLabels = {
  assistant: { label: 'Asistentes', icon: Brain },
  creation: { label: 'Creación', icon: Sparkles },
  analysis: { label: 'Análisis', icon: Zap },
  developer: { label: 'Desarrollo', icon: Code },
  advanced: { label: 'Avanzado', icon: Layers },
};

const categoryColors = {
  assistant: 'text-blue-600 bg-blue-100 dark:bg-blue-900/30',
  creation: 'text-emerald-600 bg-emerald-100 dark:bg-emerald-900/30',
  analysis: 'text-purple-600 bg-purple-100 dark:bg-purple-900/30',
  developer: 'text-orange-600 bg-orange-100 dark:bg-orange-900/30',
  advanced: 'text-pink-600 bg-pink-100 dark:bg-pink-900/30',
};

export function Sidebar() {
  const { activeFeature, setActiveFeature, setSettingsOpen, setProfileOpen } = useAppStore();

  const groupedFeatures = FEATURES.reduce((acc, feature) => {
    if (!acc[feature.category]) {
      acc[feature.category] = [];
    }
    acc[feature.category].push(feature);
    return acc;
  }, {} as Record<string, typeof FEATURES>);

  return (
    <TooltipProvider delayDuration={0}>
      <div className="flex h-full w-16 flex-col border-r bg-card md:w-72">
        {/* Logo */}
        <div className="flex h-16 items-center justify-center border-b px-4 shrink-0">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <span className="hidden font-bold text-lg md:block bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              NexusAI 7.6
            </span>
          </div>
        </div>

        {/* Features */}
        <ScrollArea className="flex-1 px-2 py-4">
          <div className="space-y-6">
            {(['assistant', 'creation', 'developer', 'analysis'] as const).map((category) => {
              const features = groupedFeatures[category];
              if (!features) return null;
              const catInfo = categoryLabels[category];
              const CatIcon = catInfo.icon;

              return (
                <div key={category}>
                  <div className="mb-2 flex items-center gap-2 px-2">
                    <CatIcon className="h-4 w-4 text-muted-foreground" />
                    <span className="hidden text-xs font-semibold uppercase tracking-wider text-muted-foreground md:block">
                      {catInfo.label}
                    </span>
                  </div>
                  <div className="space-y-1">
                    {features.map((feature) => {
                      const Icon = iconMap[feature.icon] || MessageSquare;
                      const isActive = activeFeature === feature.id;
                      const isPrivate = feature.id === 'chat-private';
                      const isNew = feature.isNew;
                      
                      return (
                        <Tooltip key={feature.id}>
                          <TooltipTrigger asChild>
                            <Button
                              variant={isActive ? 'secondary' : 'ghost'}
                              className={cn(
                                'w-full justify-start gap-3 relative',
                                isActive && categoryColors[category],
                                isPrivate && isActive && 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
                              )}
                              onClick={() => setActiveFeature(feature.id as FeatureType)}
                            >
                              <Icon className="h-5 w-5 shrink-0" />
                              <span className="hidden md:block flex items-center gap-2 truncate">
                                {feature.name}
                                {isNew && (
                                  <Badge variant="secondary" className="text-[10px] px-1 py-0 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-300">
                                    {feature.badge || 'Nuevo'}
                                  </Badge>
                                )}
                                {isPrivate && (
                                  <span className="text-[10px] px-1.5 py-0.5 bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-300 rounded-full">
                                    Cifrado
                                  </span>
                                )}
                              </span>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent side="right" className="md:hidden">
                            <p>{feature.name} {isPrivate && '(Cifrado)'} {isNew && `(${feature.badge})`}</p>
                          </TooltipContent>
                        </Tooltip>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>

        {/* Bottom Actions */}
        <div className="border-t p-2 shrink-0 space-y-2">
          {/* Credits Display */}
          <div className="hidden md:block px-1">
            <CreditsDisplay />
          </div>
          
          <div className="space-y-1">
            <Button
              variant="ghost"
              className="w-full justify-start gap-3"
              onClick={() => setSettingsOpen(true)}
            >
              <Settings className="h-5 w-5" />
              <span className="hidden md:block">Ajustes</span>
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start gap-3"
              onClick={() => setProfileOpen(true)}
            >
              <User className="h-5 w-5" />
              <span className="hidden md:block">Perfil</span>
            </Button>
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
}
