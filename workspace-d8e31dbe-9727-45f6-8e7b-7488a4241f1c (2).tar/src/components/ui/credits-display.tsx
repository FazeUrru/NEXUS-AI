'use client';

import { useState, useEffect, useSyncExternalStore } from 'react';
import { useAppStore, PLAN_LIMITS, SubscriptionPlan, SocialShare, CURRENCY } from '@/store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { 
  Coins, ImageIcon, Sparkles, Crown, Zap, Check, Share2,
  Twitter, Facebook, Linkedin, MessageCircle, Send,
  Gift, Infinity, XCircle, AlertTriangle, Clock, Timer
} from 'lucide-react';
import { toast } from 'sonner';

// Social platforms configuration
const SOCIAL_PLATFORMS: { id: SocialShare['platform']; name: string; icon: React.ElementType; color: string }[] = [
  { id: 'twitter', name: 'Twitter/X', icon: Twitter, color: 'bg-black hover:bg-gray-800' },
  { id: 'facebook', name: 'Facebook', icon: Facebook, color: 'bg-blue-600 hover:bg-blue-700' },
  { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, color: 'bg-blue-700 hover:bg-blue-800' },
  { id: 'whatsapp', name: 'WhatsApp', icon: MessageCircle, color: 'bg-green-500 hover:bg-green-600' },
  { id: 'telegram', name: 'Telegram', icon: Send, color: 'bg-blue-500 hover:bg-blue-600' },
];

const TRIAL_DAYS = 7;

function useIsClient() {
  return useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  );
}

// Trial countdown component
function TrialCountdown({ trialStartDate }: { trialStartDate: string }) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0, expired: false });
  const isClient = useIsClient();

  useEffect(() => {
    if (!isClient || !trialStartDate) return;

    const calculateTimeLeft = () => {
      const startDate = new Date(trialStartDate);
      const endDate = new Date(startDate.getTime() + TRIAL_DAYS * 24 * 60 * 60 * 1000);
      const now = new Date();
      const diff = endDate.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, expired: true });
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds, expired: false });
    };

    calculateTimeLeft();
    const interval = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(interval);
  }, [isClient, trialStartDate]);

  if (!isClient || !trialStartDate) return null;

  if (timeLeft.expired) {
    return (
      <div className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 px-3 py-2 rounded-lg text-sm font-medium text-center">
        ¡Tu prueba ha terminado!
      </div>
    );
  }

  return (
    <div className="bg-amber-100 dark:bg-amber-900/30 rounded-lg p-3">
      <div className="flex items-center gap-2 mb-2">
        <Timer className="h-4 w-4 text-amber-600" />
        <span className="text-sm font-medium text-amber-700 dark:text-amber-300">
          Prueba gratis restante
        </span>
      </div>
      <div className="flex items-center justify-center gap-2 text-center">
        <div className="flex flex-col items-center">
          <div className="bg-white dark:bg-amber-800 text-amber-700 dark:text-amber-200 px-2 py-1 rounded font-bold text-lg min-w-[40px]">
            {timeLeft.days}
          </div>
          <span className="text-[10px] text-amber-600 dark:text-amber-400">días</span>
        </div>
        <span className="font-bold text-amber-600">:</span>
        <div className="flex flex-col items-center">
          <div className="bg-white dark:bg-amber-800 text-amber-700 dark:text-amber-200 px-2 py-1 rounded font-bold text-lg min-w-[40px]">
            {String(timeLeft.hours).padStart(2, '0')}
          </div>
          <span className="text-[10px] text-amber-600 dark:text-amber-400">hrs</span>
        </div>
        <span className="font-bold text-amber-600">:</span>
        <div className="flex flex-col items-center">
          <div className="bg-white dark:bg-amber-800 text-amber-700 dark:text-amber-200 px-2 py-1 rounded font-bold text-lg min-w-[40px]">
            {String(timeLeft.minutes).padStart(2, '0')}
          </div>
          <span className="text-[10px] text-amber-600 dark:text-amber-400">min</span>
        </div>
        <span className="font-bold text-amber-600">:</span>
        <div className="flex flex-col items-center">
          <div className="bg-white dark:bg-amber-800 text-amber-700 dark:text-amber-200 px-2 py-1 rounded font-bold text-lg min-w-[40px]">
            {String(timeLeft.seconds).padStart(2, '0')}
          </div>
          <span className="text-[10px] text-amber-600 dark:text-amber-400">seg</span>
        </div>
      </div>
    </div>
  );
}

export function CreditsDisplay() {
  const isClient = useIsClient();
  const { 
    creditState, 
    getCurrentPlanLimits, 
    getDailyCreditsRemaining, 
    getImagesRemaining,
    addSocialShareCredit,
    changePlan,
    cancelPlan
  } = useAppStore();
  
  const [showPlans, setShowPlans] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  
  if (!isClient) return null;
  
  const limits = getCurrentPlanLimits();
  const dailyRemaining = getDailyCreditsRemaining();
  const imagesRemaining = getImagesRemaining();
  const isPaidPlan = creditState.plan !== 'free';
  
  const dailyCreditsPercent = limits.dailyCredits === -1 
    ? 100 
    : Math.round(((limits.dailyCredits - creditState.dailyCreditsUsed) / limits.dailyCredits) * 100);
  
  const imagesPercent = limits.dailyImages === -1 
    ? 100 
    : Math.round((imagesRemaining / limits.dailyImages) * 100);
  
  const handleShare = (platform: SocialShare['platform']) => {
    const shareUrl = 'https://nexusai.app';
    const shareText = '¡Estoy usando NexusAI 7.7, la mejor IA del 2026! Pruébala gratis: ';
    
    const urls: Record<SocialShare['platform'], string> = {
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`,
      whatsapp: `https://wa.me/?text=${encodeURIComponent(shareText + shareUrl)}`,
      telegram: `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`,
    };
    
    window.open(urls[platform], '_blank', 'width=600,height=400');
    
    if (addSocialShareCredit(platform)) {
      toast.success('¡+200 créditos añadidos por compartir!');
    } else {
      toast.info('Ya has recibido créditos por compartir en esta plataforma');
    }
  };
  
  const handleCancelPlan = () => {
    cancelPlan();
    setShowCancelDialog(false);
    toast.success('Plan cancelado. Ahora estás en el plan Gratis.');
  };
  
  const sharedPlatforms = creditState.socialShares.map(s => s.platform);

  return (
    <>
      <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 border-emerald-200 dark:border-emerald-800">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm flex items-center gap-2">
              <Coins className="h-4 w-4 text-emerald-600" />
              Créditos
            </CardTitle>
            <Badge className={
              creditState.plan === 'business' ? 'bg-purple-600' :
              creditState.plan === 'premium' ? 'bg-amber-500' :
              creditState.plan === 'pro' ? 'bg-blue-500' :
              'bg-gray-500'
            }>
              {limits.name}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Trial Countdown - Show if in trial */}
          {creditState.trialStartDate && isPaidPlan && (
            <TrialCountdown trialStartDate={creditState.trialStartDate} />
          )}
          
          {/* Daily Credits */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Créditos diarios</span>
              <span className="font-medium">
                {dailyRemaining === -1 ? (
                  <span className="flex items-center gap-1"><Infinity className="h-3 w-3" /> Ilimitado</span>
                ) : (
                  <>
                    {dailyRemaining.toLocaleString()} / {limits.dailyCredits.toLocaleString()}
                    {creditState.bonusCredits > 0 && (
                      <span className="text-emerald-600 ml-1">(+{creditState.bonusCredits} bonus)</span>
                    )}
                  </>
                )}
              </span>
            </div>
            <Progress value={dailyCreditsPercent} className="h-2" />
          </div>
          
          {/* Images */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground flex items-center gap-1">
                <ImageIcon className="h-3 w-3" /> Imágenes hoy
              </span>
              <span className="font-medium">
                {imagesRemaining === -1 ? (
                  <span className="flex items-center gap-1"><Infinity className="h-3 w-3" /> Ilimitado</span>
                ) : (
                  `${imagesRemaining} / ${limits.dailyImages}`
                )}
              </span>
            </div>
            <Progress value={imagesPercent} className="h-2" />
          </div>
          
          {/* Monthly Credits (if applicable) */}
          {limits.monthlyCredits > 0 && (
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Créditos mensuales</span>
                <span className="font-medium">{limits.monthlyCredits.toLocaleString()} extra</span>
              </div>
            </div>
          )}
          
          {/* Action Buttons */}
          <div className="flex gap-2 pt-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1"
              onClick={() => setShowShare(true)}
            >
              <Gift className="h-3 w-3 mr-1" />
              +200
            </Button>
            {isPaidPlan ? (
              <Button 
                variant="outline"
                size="sm" 
                className="flex-1 text-red-600 border-red-300 hover:bg-red-50 dark:hover:bg-red-950/30"
                onClick={() => setShowCancelDialog(true)}
              >
                <XCircle className="h-3 w-3 mr-1" />
                Cancelar
              </Button>
            ) : (
              <Button 
                size="sm" 
                className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                onClick={() => setShowPlans(true)}
              >
                <Crown className="h-3 w-3 mr-1" />
                Mejorar
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Share Dialog */}
      <Dialog open={showShare} onOpenChange={setShowShare}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5 text-emerald-600" />
              Gana 200 Créditos por Compartir
            </DialogTitle>
            <DialogDescription>
              Comparte NexusAI en redes sociales y obtén 200 créditos extra por cada una.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3 py-4">
            {SOCIAL_PLATFORMS.map(platform => {
              const alreadyShared = sharedPlatforms.includes(platform.id);
              return (
                <Button
                  key={platform.id}
                  variant={alreadyShared ? 'outline' : 'default'}
                  className={`${platform.color} text-white ${alreadyShared ? 'opacity-50' : ''}`}
                  onClick={() => handleShare(platform.id)}
                  disabled={alreadyShared}
                >
                  <platform.icon className="h-4 w-4 mr-2" />
                  {platform.name}
                  {alreadyShared && <Check className="h-3 w-3 ml-auto" />}
                </Button>
              );
            })}
          </div>
          <div className="text-center text-sm text-muted-foreground">
            {creditState.bonusCredits > 0 ? (
              <span className="text-emerald-600 font-medium">
                Has ganado {creditState.bonusCredits} créditos extra
              </span>
            ) : (
              'Máximo 5 compartidos = 1,000 créditos extra'
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Plans Dialog */}
      <Dialog open={showPlans} onOpenChange={setShowPlans}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-emerald-600" />
              Planes de Suscripción
            </DialogTitle>
            <DialogDescription>
              Elige el plan perfecto para ti. Cancela cuando quieras.
            </DialogDescription>
          </DialogHeader>
          <div className="grid md:grid-cols-4 gap-4 py-6">
            {(Object.entries(PLAN_LIMITS) as [SubscriptionPlan, typeof PLAN_LIMITS.free][]).map(([planId, plan]) => {
              const isCurrentPlan = creditState.plan === planId;
              return (
                <Card 
                  key={planId}
                  className={`relative ${plan.popular ? 'border-emerald-500 border-2 shadow-lg' : ''} ${isCurrentPlan ? 'ring-2 ring-emerald-500' : ''}`}
                >
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <Badge className="bg-emerald-600">Más Popular</Badge>
                    </div>
                  )}
                  <CardHeader className="text-center pb-2">
                    <CardTitle className="text-lg">{plan.name}</CardTitle>
                    <div className="text-3xl font-bold">
                      {plan.price === 0 ? 'Gratis' : `${plan.price}${CURRENCY}`}
                      {plan.price > 0 && <span className="text-sm font-normal text-muted-foreground">/mes</span>}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <ul className="space-y-2 text-sm">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <Check className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button
                      className="w-full"
                      variant={isCurrentPlan ? 'outline' : 'default'}
                      disabled={isCurrentPlan}
                      onClick={() => {
                        changePlan(planId);
                        toast.success(`Plan ${plan.name} activado`);
                        setShowPlans(false);
                      }}
                    >
                      {isCurrentPlan ? 'Plan Actual' : 'Seleccionar'}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      {/* Cancel Plan Dialog */}
      <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              Cancelar Plan
            </DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que quieres cancelar tu plan <strong>{limits.name}</strong>?
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg p-4">
              <p className="text-sm text-red-700 dark:text-red-300">
                Al cancelar tu plan:
              </p>
              <ul className="text-sm text-red-600 dark:text-red-400 mt-2 space-y-1">
                <li>• Perderás acceso a las funciones premium</li>
                <li>• Tus créditos volverán al límite gratuito</li>
                <li>• Se perderán los créditos mensuales extra</li>
              </ul>
            </div>
          </div>
          <DialogFooter className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={() => setShowCancelDialog(false)}
              className="flex-1"
            >
              Mantener Plan
            </Button>
            <Button 
              variant="destructive"
              onClick={handleCancelPlan}
              className="flex-1"
            >
              <XCircle className="h-4 w-4 mr-2" />
              Cancelar Plan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
