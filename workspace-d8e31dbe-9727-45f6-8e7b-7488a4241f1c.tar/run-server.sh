#!/bin/bash
while true; do
  echo "Starting server at $(date)"
  bun run dev
  exit_code=$?
  echo "Server exited with code $exit_code"
  if [ $exit_code -ne 0 ]; then
    echo "Restarting in 5 seconds..."
    sleep 5
  fi
done
