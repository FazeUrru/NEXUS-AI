#!/bin/bash
cd /home/z/my-project
while true; do
  if ! pgrep -f "next-server" > /dev/null; then
    echo "[$(date)] Starting server..."
    bun run dev &
    sleep 20
  fi
  sleep 5
done
