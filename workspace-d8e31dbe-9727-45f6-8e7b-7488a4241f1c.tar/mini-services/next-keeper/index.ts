import { spawn } from 'child_process';
import { setTimeout as sleep } from 'timers/promises';

const PORT = 3000;
let child: ReturnType<typeof spawn> | null = null;
let restartCount = 0;
const MAX_RESTARTS = 10;

async function isServerRunning(): Promise<boolean> {
  try {
    const res = await fetch(`http://localhost:${PORT}/`, { 
      method: 'HEAD',
      signal: AbortSignal.timeout(5000)
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function startServer(): Promise<void> {
  console.log('[Keeper] Starting Next.js server...');
  
  child = spawn('bun', ['run', 'dev'], {
    cwd: '/home/z/my-project',
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: false
  });

  child.stdout?.on('data', (data) => {
    process.stdout.write(data);
  });

  child.stderr?.on('data', (data) => {
    process.stderr.write(data);
  });

  child.on('exit', (code, signal) => {
    console.log(`[Keeper] Server exited with code ${code}, signal ${signal}`);
    child = null;
  });

  // Wait for server to be ready
  for (let i = 0; i < 30; i++) {
    await sleep(1000);
    if (await isServerRunning()) {
      console.log('[Keeper] Server is UP!');
      return;
    }
  }
  
  throw new Error('Server failed to start');
}

async function main(): Promise<void> {
  console.log('[Keeper] Starting Next.js keeper service...');
  
  while (restartCount < MAX_RESTARTS) {
    try {
      const running = await isServerRunning();
      
      if (!running) {
        console.log('[Keeper] Server not running, starting...');
        await startServer();
        restartCount = 0;
      } else {
        console.log('[Keeper] Server is healthy');
      }
    } catch (error) {
      console.error('[Keeper] Error:', error);
      restartCount++;
    }
    
    // Check every 10 seconds
    await sleep(10000);
  }
  
  console.error('[Keeper] Max restarts reached, exiting');
  process.exit(1);
}

main().catch(console.error);
