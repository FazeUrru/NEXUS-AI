#!/bin/bash
LOG_FILE="/home/z/my-project/server-watch.log"
DEV_LOG="/home/z/my-project/dev.log"

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

start_server() {
  log "Starting Next.js server..."
  cd /home/z/my-project
  bun run dev >> "$DEV_LOG" 2>&1 &
  SERVER_PID=$!
  log "Server started with PID $SERVER_PID"
  echo $SERVER_PID > /tmp/nexusai-server.pid
  
  # Wait for server to be ready
  for i in {1..30}; do
    if curl -s -o /dev/null http://localhost:3000/ 2>/dev/null; then
      log "Server is ready!"
      return 0
    fi
    sleep 1
  done
  log "Server failed to start in 30 seconds"
  return 1
}

check_server() {
  if curl -s -o /dev/null --connect-timeout 5 http://localhost:3000/ 2>/dev/null; then
    return 0
  fi
  return 1
}

# Main loop
log "=== Starting server watcher ==="
start_server

while true; do
  sleep 10
  if ! check_server; then
    log "Server not responding, restarting..."
    pkill -f "next-server" 2>/dev/null
    sleep 2
    start_server
  fi
done
