import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

// Feature types - Extended for v5.0
export type FeatureType = 
  // Core Features
  | 'chat'
  | 'chat-private'
  | 'image-gen'
  | 'code-gen'
  | 'text-analysis'
  | 'translation'
  | 'summarize'
  | 'content-gen'
  | 'sentiment'
  | 'ideas'
  | 'grammar'
  | 'titles'
  | 'explain'
  | 'email-gen'
  | 'story-gen'
  | 'code-assistant'
  // v4.0 Features
  | 'deep-research'
  | 'think-mode'
  | 'presentations'
  | 'documents'
  | 'web-pages'
  | 'apps'
  | 'games'
  | 'ui-designer'
  | 'fullstack'
  | 'web-search'
  // v5.0 Beta Features
  | 'agent-mode'
  | 'writing'
  | 'data-analysis'
  | 'magic-design';

export interface Feature {
  id: FeatureType;
  name: string;
  description: string;
  icon: string;
  category: 'creation' | 'analysis' | 'assistant' | 'advanced' | 'developer';
  isNew?: boolean;
  badge?: string;
}

export const FEATURES: Feature[] = [
  // Assistant
  { id: 'chat', name: 'Chat IA', description: 'Conversación inteligente con IA', icon: 'MessageSquare', category: 'assistant' },
  { id: 'agent-mode', name: 'Agente IA', description: 'Agente autónomo que ejecuta tareas', icon: 'Bot', category: 'assistant', isNew: true, badge: 'Beta' },
  { id: 'chat-private', name: 'Chat Privado', description: 'Conversación cifrada y privada', icon: 'Lock', category: 'assistant' },
  { id: 'think-mode', name: 'Modo Pensar', description: 'Razonamiento profundo paso a paso', icon: 'Brain', category: 'assistant', isNew: true, badge: 'Nuevo' },
  { id: 'deep-research', name: 'Investigación Profunda', description: 'Análisis exhaustivo de temas', icon: 'Search', category: 'assistant', isNew: true, badge: 'Pro' },
  { id: 'web-search', name: 'Búsqueda Web', description: 'Busca información en tiempo real', icon: 'Globe', category: 'assistant', isNew: true, badge: 'Live' },
  
  // Creation
  { id: 'image-gen', name: 'Generar Imágenes', description: 'Crea imágenes desde texto', icon: 'Image', category: 'creation' },
  { id: 'writing', name: 'Escribiendo', description: 'Asistente de escritura avanzado', icon: 'Pen', category: 'creation', isNew: true, badge: 'Beta' },
  { id: 'magic-design', name: 'Diseño Mágico', description: 'Diseño automático con IA', icon: 'Wand2', category: 'creation', isNew: true, badge: 'Beta' },
  { id: 'presentations', name: 'Presentaciones IA', description: 'Crea presentaciones completas', icon: 'Presentation', category: 'creation', isNew: true, badge: 'Nuevo' },
  { id: 'documents', name: 'Documentos IA', description: 'Genera documentos profesionales', icon: 'FileText', category: 'creation', isNew: true, badge: 'Nuevo' },
  { id: 'content-gen', name: 'Generar Contenido', description: 'Crea artículos, posts y más', icon: 'PenTool', category: 'creation' },
  { id: 'ideas', name: 'Generador de Ideas', description: 'Obtén ideas creativas', icon: 'Lightbulb', category: 'creation' },
  { id: 'titles', name: 'Generar Títulos', description: 'Crea títulos atractivos', icon: 'Type', category: 'creation' },
  { id: 'email-gen', name: 'Generar Emails', description: 'Redacta emails profesionales', icon: 'Mail', category: 'creation' },
  { id: 'story-gen', name: 'Crear Historias', description: 'Genera narrativas creativas', icon: 'BookOpen', category: 'creation' },
  
  // Developer
  { id: 'code-gen', name: 'Generar Código', description: 'Genera código en cualquier lenguaje', icon: 'Code', category: 'developer' },
  { id: 'code-assistant', name: 'Asistente de Código', description: 'Ayuda con programación', icon: 'Terminal', category: 'developer' },
  { id: 'web-pages', name: 'Páginas Web', description: 'Crea páginas web completas', icon: 'Layout', category: 'developer', isNew: true, badge: 'Nuevo' },
  { id: 'apps', name: 'Aplicaciones', description: 'Desarrolla apps completas', icon: 'Smartphone', category: 'developer', isNew: true, badge: 'Pro' },
  { id: 'games', name: 'Juegos', description: 'Crea juegos interactivos', icon: 'Gamepad2', category: 'developer', isNew: true, badge: 'Nuevo' },
  { id: 'ui-designer', name: 'UI Designer', description: 'Diseña interfaces modernas', icon: 'Palette', category: 'developer', isNew: true, badge: 'Nuevo' },
  { id: 'fullstack', name: 'Fullstack', description: 'Proyectos fullstack completos', icon: 'Layers', category: 'developer', isNew: true, badge: 'Pro' },
  
  // Analysis
  { id: 'data-analysis', name: 'Análisis de Datos', description: 'Analiza datos y genera insights', icon: 'BarChart3', category: 'analysis', isNew: true, badge: 'Beta' },
  { id: 'text-analysis', name: 'Análisis de Texto', description: 'Analiza y extrae información', icon: 'FileSearch', category: 'analysis' },
  { id: 'translation', name: 'Traducción', description: 'Traduce entre idiomas', icon: 'Languages', category: 'analysis' },
  { id: 'summarize', name: 'Resumir Texto', description: 'Crea resúmenes concisos', icon: 'FileMinus', category: 'analysis' },
  { id: 'sentiment', name: 'Análisis de Sentimiento', description: 'Detecta emociones en textos', icon: 'Heart', category: 'analysis' },
  { id: 'grammar', name: 'Corrección Gramatical', description: 'Corrige errores de escritura', icon: 'CheckCircle', category: 'analysis' },
  { id: 'explain', name: 'Explicar Conceptos', description: 'Simplifica conceptos complejos', icon: 'HelpCircle', category: 'analysis' },
];

// Available AI Models - Updated for 2026
export const AI_MODELS = [
  // OpenAI
  { id: 'gpt-5.4', name: 'GPT-5.4', provider: 'OpenAI', description: 'El modelo más avanzado de OpenAI 2026' },
  { id: 'gpt-5.2', name: 'GPT-5.2', provider: 'OpenAI', description: 'Balance perfecto entre velocidad y calidad' },
  { id: 'gpt-5', name: 'GPT-5', provider: 'OpenAI', description: 'Modelo versátil de OpenAI' },
  { id: 'gpt-4-turbo', name: 'GPT-4 Turbo', provider: 'OpenAI', description: 'Modelo rápido y eficiente' },
  // Anthropic
  { id: 'claude-opus-4', name: 'Claude Opus 4', provider: 'Anthropic', description: 'Máxima capacidad de razonamiento' },
  { id: 'claude-sonnet-4', name: 'Claude Sonnet 4', provider: 'Anthropic', description: 'Balance rendimiento y costo' },
  // xAI
  { id: 'grok-4.20', name: 'Grok 4.20', provider: 'xAI', description: 'IA con sentido del humor de Elon Musk' },
  // Google
  { id: 'gemini-3-pro', name: 'Gemini 3 Pro', provider: 'Google', description: 'Multimodalidad avanzada de Google' },
  { id: 'gemini-3-flash', name: 'Gemini 3 Flash', provider: 'Google', description: 'Respuestas ultrarrápidas' },
  // Meta
  { id: 'llama-4-405b', name: 'Llama 4 405B', provider: 'Meta', description: 'Open source más potente' },
  // Alibaba - QWEN
  { id: 'qwen-3.5-plus', name: 'QWEN 3.5 Plus', provider: 'Alibaba', description: 'Modelo avanzado de Alibaba' },
  { id: 'qwen-3.5-flash', name: 'QWEN 3.5 Flash', provider: 'Alibaba', description: 'Respuestas ultrarrápidas de QWEN' },
  // Zhipu AI - GLM
  { id: 'glm-5', name: 'GLM-5', provider: 'Zhipu AI', description: 'Modelo bilingüe chino-inglés' },
  { id: 'glm-4.5', name: 'GLM-4.5', provider: 'Zhipu AI', description: 'Modelo versátil de Zhipu' },
  // Microsoft
  { id: 'copilot-365', name: 'Copilot 365', provider: 'Microsoft', description: 'Asistente de Microsoft 365' },
] as const;

export type AIModelId = typeof AI_MODELS[number]['id'];

// File attachment type
export interface FileAttachment {
  id: string;
  name: string;
  type: string;
  size: number;
  content?: string;
  url?: string;
}

// Memory settings type
export interface MemorySettings {
  enabled: boolean;
  maxMemorySize: number;
  rememberContext: boolean;
  autoForget: boolean;
  forgetAfterDays: number;
  rememberUserPreferences: boolean;
  rememberConversationContext: boolean;
  crossSessionMemory: boolean;
}

// Settings types
export interface GeneralSettings {
  language: string;
  theme: string;
  fontSize: string;
  notifications: boolean;
  sounds: boolean;
  animations: boolean;
  autoSave: boolean;
  historyEnabled: boolean;
  privacy: string;
  storageLimit: number;
  accessibility: boolean;
  keyboardShortcuts: boolean;
  autoUpdate: boolean;
  showStats: boolean;
  dataExport: boolean;
  cacheEnabled: boolean;
  // v6.0 - New settings
  autoSaveInterval: number;
  compactMode: boolean;
  showTypingIndicator: boolean;
  enableRichText: boolean;
  languageDetection: boolean;
}

export interface ProfileSettings {
  name: string;
  email: string;
  avatar: string;
  bio: string;
  location: string;
  website: string;
  phone: string;
  twitter: string;
  linkedin: string;
  github: string;
  aiModel: string;
  responseStyle: string;
  creativityLevel: number;
  maxTokens: number;
  temperature: number;
  planType: string;
  monthlyLimit: number;
  usedTokens: number;
  twoFactorEnabled: boolean;
  activeSessions: number;
  profileVisibility: string;
  emailNotifications: boolean;
  pushNotifications: boolean;
  marketingEmails: boolean;
  dataRetention: string;
  preferredVoice: string;
  // v6.0 - New profile settings
  autoLanguageDetect: boolean;
  codeTheme: string;
  messageFormat: string;
  showTimestamps: boolean;
  enableMarkdown: boolean;
  enableLatex: boolean;
  responseLength: string;
}

// Message type for conversations
export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  attachments?: FileAttachment[];
  thinking?: string;
  sources?: { title: string; url: string; snippet: string }[];
  agentActions?: AgentAction[];
}

// Agent action type
export interface AgentAction {
  id: string;
  type: 'search' | 'browse' | 'write' | 'code' | 'analyze' | 'design' | 'execute';
  description: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  result?: string;
  timestamp: string;
}

// Conversation status type
export type ConversationStatus = 'active' | 'archived' | 'pinned';

// Conversation type
export interface Conversation {
  id: string;
  featureType?: FeatureType;
  title: string;
  messages: Message[];
  createdAt: string;
  updatedAt: string;
  status: ConversationStatus;
  isShared: boolean;
  shareId?: string;
}

// Chat mode type
export type ChatMode = 'chat' | 'agent';

// Store state
interface AppState {
  // Auth state
  isAuthenticated: boolean;
  user: { name: string; email: string } | null;
  login: (user: { name: string; email: string }) => void;
  logout: () => void;
  
  // Feature state
  activeFeature: FeatureType;
  setActiveFeature: (feature: FeatureType) => void;
  
  // Chat mode state
  chatMode: ChatMode;
  setChatMode: (mode: ChatMode) => void;
  
  // Settings state
  generalSettings: GeneralSettings;
  profileSettings: ProfileSettings;
  memorySettings: MemorySettings;
  updateGeneralSettings: (settings: Partial<GeneralSettings>) => void;
  updateProfileSettings: (settings: Partial<ProfileSettings>) => void;
  updateMemorySettings: (settings: Partial<MemorySettings>) => void;
  
  // UI state
  settingsOpen: boolean;
  profileOpen: boolean;
  setSettingsOpen: (open: boolean) => void;
  setProfileOpen: (open: boolean) => void;
  
  // Conversations
  conversations: Conversation[];
  currentConversationId: string | null;
  messages: Message[];
  attachments: FileAttachment[];
  addAttachment: (file: FileAttachment) => void;
  removeAttachment: (id: string) => void;
  clearAttachments: () => void;
  addMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
  clearMessages: () => void;
  createNewConversation: (featureType: FeatureType) => string;
  saveCurrentConversation: () => void;
  loadConversation: (conversationId: string) => void;
  deleteConversation: (conversationId: string) => void;
  archiveConversation: (conversationId: string) => void;
  unarchiveConversation: (conversationId: string) => void;
  pinConversation: (conversationId: string) => void;
  unpinConversation: (conversationId: string) => void;
  editConversationTitle: (conversationId: string, title: string) => void;
  shareConversation: (conversationId: string) => string;
  getSharedConversation: (shareId: string) => Conversation | null;
  cleanupOldConversations: () => void;
  
  // Loading state
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  
  // Mode states
  thinkModeEnabled: boolean;
  deepResearchEnabled: boolean;
  setThinkMode: (enabled: boolean) => void;
  setDeepResearch: (enabled: boolean) => void;
  
  // Agent state
  agentActions: AgentAction[];
  addAgentAction: (action: Omit<AgentAction, 'id' | 'timestamp'>) => void;
  updateAgentAction: (id: string, updates: Partial<AgentAction>) => void;
  clearAgentActions: () => void;
}

const defaultGeneralSettings: GeneralSettings = {
  language: 'es',
  theme: 'system',
  fontSize: 'medium',
  notifications: true,
  sounds: true,
  animations: true,
  autoSave: true,
  historyEnabled: true,
  privacy: 'standard',
  storageLimit: 1000,
  accessibility: false,
  keyboardShortcuts: true,
  autoUpdate: true,
  showStats: true,
  dataExport: false,
  cacheEnabled: true,
  // v6.0 - New defaults
  autoSaveInterval: 30,
  compactMode: false,
  showTypingIndicator: true,
  enableRichText: true,
  languageDetection: true,
};

const defaultProfileSettings: ProfileSettings = {
  name: 'Usuario',
  email: 'usuario@ejemplo.com',
  avatar: '',
  bio: '',
  location: '',
  website: '',
  phone: '',
  twitter: '',
  linkedin: '',
  github: '',
  aiModel: 'gpt-5.4',
  responseStyle: 'balanced',
  creativityLevel: 70,
  maxTokens: 4000,
  temperature: 0.7,
  planType: 'free',
  monthlyLimit: 100,
  usedTokens: 0,
  twoFactorEnabled: false,
  activeSessions: 1,
  profileVisibility: 'public',
  emailNotifications: true,
  pushNotifications: false,
  marketingEmails: false,
  dataRetention: '30days',
  preferredVoice: 'default',
  // v6.0 - New defaults
  autoLanguageDetect: true,
  codeTheme: 'github-dark',
  messageFormat: 'rich',
  showTimestamps: true,
  enableMarkdown: true,
  enableLatex: true,
  responseLength: 'auto',
};

const defaultMemorySettings: MemorySettings = {
  enabled: true,
  maxMemorySize: 100,
  rememberContext: true,
  autoForget: false,
  forgetAfterDays: 30,
  rememberUserPreferences: true,
  rememberConversationContext: true,
  crossSessionMemory: true,
};

const MAX_CONVERSATIONS = 100;

function generateId(): string {
  try {
    return crypto.randomUUID();
  } catch {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

function getTimestamp(): string {
  return new Date().toISOString();
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Auth state
      isAuthenticated: false,
      user: null,
      login: (user) => set({ 
        isAuthenticated: true, 
        user, 
        profileSettings: { ...defaultProfileSettings, name: user.name, email: user.email } 
      }),
      logout: () => set({ 
        isAuthenticated: false, 
        user: null, 
        messages: [], 
        currentConversationId: null,
        attachments: [],
        agentActions: [],
        chatMode: 'chat'
      }),
      
      // Feature state
      activeFeature: 'chat',
      setActiveFeature: (feature) => {
        const state = get();
        if (state.messages.length > 0) {
          state.saveCurrentConversation();
        }
        set({ activeFeature: feature, messages: [], currentConversationId: null, attachments: [], agentActions: [] });
      },
      
      // Chat mode state
      chatMode: 'chat',
      setChatMode: (mode) => set({ chatMode: mode }),
      
      // Settings state
      generalSettings: defaultGeneralSettings,
      profileSettings: defaultProfileSettings,
      memorySettings: defaultMemorySettings,
      updateGeneralSettings: (settings) =>
        set((state) => ({
          generalSettings: { ...state.generalSettings, ...settings },
        })),
      updateProfileSettings: (settings) =>
        set((state) => ({
          profileSettings: { ...state.profileSettings, ...settings },
        })),
      updateMemorySettings: (settings) =>
        set((state) => ({
          memorySettings: { ...state.memorySettings, ...settings },
        })),
      
      // UI state
      settingsOpen: false,
      profileOpen: false,
      setSettingsOpen: (open) => set({ settingsOpen: open }),
      setProfileOpen: (open) => set({ profileOpen: open }),
      
      // Conversations
      conversations: [],
      currentConversationId: null,
      messages: [],
      attachments: [],
      
      addAttachment: (file) => {
        set((state) => ({
          attachments: [...state.attachments, file]
        }));
      },
      removeAttachment: (id) => {
        set((state) => ({
          attachments: state.attachments.filter(a => a.id !== id)
        }));
      },
      clearAttachments: () => set({ attachments: [] }),
      
      addMessage: (message) => {
        if (!message.content || typeof message.content !== 'string') return;
        
        const newMessage: Message = {
          ...message,
          id: generateId(),
          timestamp: getTimestamp(),
        };
        set((state) => ({
          messages: [...state.messages, newMessage],
        }));
      },
      clearMessages: () => set({ messages: [], currentConversationId: null, attachments: [], agentActions: [] }),
      createNewConversation: (featureType) => {
        const id = generateId();
        const now = getTimestamp();
        const conversation: Conversation = {
          id,
          featureType,
          title: 'Nueva conversación',
          messages: [],
          createdAt: now,
          updatedAt: now,
          status: 'active',
          isShared: false,
        };
        set((state) => ({
          conversations: [conversation, ...state.conversations].slice(0, MAX_CONVERSATIONS),
          currentConversationId: id,
          messages: [],
          attachments: [],
          agentActions: [],
        }));
        return id;
      },
      saveCurrentConversation: () => {
        const state = get();
        if (state.messages.length === 0) return;
        
        const title = state.messages[0]?.content?.slice(0, 50) || 'Conversación';
        const now = getTimestamp();
        
        if (state.currentConversationId) {
          set((s) => ({
            conversations: s.conversations.map((conv) =>
              conv.id === state.currentConversationId
                ? { ...conv, messages: state.messages, title, updatedAt: now }
                : conv
            ),
          }));
        } else {
          const id = generateId();
          const conversation: Conversation = {
            id,
            featureType: state.activeFeature,
            title,
            messages: state.messages,
            createdAt: now,
            updatedAt: now,
            status: 'active',
            isShared: false,
          };
          set((s) => ({
            conversations: [conversation, ...s.conversations].slice(0, MAX_CONVERSATIONS),
            currentConversationId: id,
          }));
        }
      },
      loadConversation: (conversationId) => {
        const state = get();
        const conversation = state.conversations.find((c) => c.id === conversationId);
        if (conversation && Array.isArray(conversation.messages)) {
          set({
            currentConversationId: conversationId,
            messages: conversation.messages,
            activeFeature: conversation.featureType || 'chat',
            attachments: [],
            agentActions: [],
          });
        }
      },
      deleteConversation: (conversationId) => {
        set((state) => ({
          conversations: state.conversations.filter((c) => c.id !== conversationId),
          currentConversationId: state.currentConversationId === conversationId ? null : state.currentConversationId,
          messages: state.currentConversationId === conversationId ? [] : state.messages,
        }));
      },
      archiveConversation: (conversationId) => {
        set((state) => ({
          conversations: state.conversations.map((c) =>
            c.id === conversationId ? { ...c, status: 'archived' as ConversationStatus } : c
          ),
        }));
      },
      unarchiveConversation: (conversationId) => {
        set((state) => ({
          conversations: state.conversations.map((c) =>
            c.id === conversationId ? { ...c, status: 'active' as ConversationStatus } : c
          ),
        }));
      },
      pinConversation: (conversationId) => {
        set((state) => ({
          conversations: state.conversations.map((c) =>
            c.id === conversationId ? { ...c, status: 'pinned' as ConversationStatus } : c
          ),
        }));
      },
      unpinConversation: (conversationId) => {
        set((state) => ({
          conversations: state.conversations.map((c) =>
            c.id === conversationId ? { ...c, status: 'active' as ConversationStatus } : c
          ),
        }));
      },
      editConversationTitle: (conversationId, title) => {
        if (!title || typeof title !== 'string') return;
        set((state) => ({
          conversations: state.conversations.map((c) =>
            c.id === conversationId ? { ...c, title: title.slice(0, 100) } : c
          ),
        }));
      },
      shareConversation: (conversationId) => {
        const shareId = generateId().slice(0, 8);
        set((state) => ({
          conversations: state.conversations.map((c) =>
            c.id === conversationId ? { ...c, isShared: true, shareId } : c
          ),
        }));
        return shareId;
      },
      getSharedConversation: (shareId) => {
        const state = get();
        return state.conversations.find((c) => c.shareId === shareId) || null;
      },
      cleanupOldConversations: () => {
        const state = get();
        const retentionDays = parseInt(state.profileSettings.dataRetention) || 30;
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - retentionDays);
        
        set((s) => ({
          conversations: s.conversations.filter((c) => {
            if (c.status === 'pinned') return true;
            const updatedAt = new Date(c.updatedAt);
            return updatedAt >= cutoffDate;
          }),
        }));
      },
      
      // Loading state
      isLoading: false,
      setIsLoading: (loading) => set({ isLoading: loading }),
      
      // Mode states
      thinkModeEnabled: false,
      deepResearchEnabled: false,
      setThinkMode: (enabled) => set({ thinkModeEnabled: enabled }),
      setDeepResearch: (enabled) => set({ deepResearchEnabled: enabled }),
      
      // Agent state
      agentActions: [],
      addAgentAction: (action) => {
        const newAction: AgentAction = {
          ...action,
          id: generateId(),
          timestamp: getTimestamp(),
        };
        set((state) => ({
          agentActions: [...state.agentActions, newAction],
        }));
      },
      updateAgentAction: (id, updates) => {
        set((state) => ({
          agentActions: state.agentActions.map(a =>
            a.id === id ? { ...a, ...updates } : a
          ),
        }));
      },
      clearAgentActions: () => set({ agentActions: [] }),
    }),
    {
      name: 'nexusai-v7.4-storage',
      version: 11,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        isAuthenticated: state.isAuthenticated,
        user: state.user,
        activeFeature: state.activeFeature,
        generalSettings: state.generalSettings,
        profileSettings: state.profileSettings,
        memorySettings: state.memorySettings,
        conversations: state.conversations.slice(0, MAX_CONVERSATIONS),
        thinkModeEnabled: state.thinkModeEnabled,
        deepResearchEnabled: state.deepResearchEnabled,
        chatMode: state.chatMode,
      }),
      migrate: (persistedState, version) => {
        if (version < 9) {
          return {
            ...(typeof persistedState === 'object' && persistedState !== null ? persistedState : {}),
            generalSettings: { ...defaultGeneralSettings, ...(typeof persistedState === 'object' && persistedState !== null && 'generalSettings' in persistedState ? persistedState.generalSettings : {}) },
            profileSettings: { ...defaultProfileSettings, ...(typeof persistedState === 'object' && persistedState !== null && 'profileSettings' in persistedState ? persistedState.profileSettings : {}) },
            memorySettings: defaultMemorySettings,
            thinkModeEnabled: false,
            deepResearchEnabled: false,
            chatMode: 'chat',
            agentActions: [],
          };
        }
        return persistedState;
      },
    }
  )
);
