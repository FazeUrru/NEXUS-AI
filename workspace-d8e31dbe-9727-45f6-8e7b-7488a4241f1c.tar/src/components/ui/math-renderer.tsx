'use client';

import { useMemo } from 'react';

interface MathRendererProps {
  content: string;
}

// Simple text formatter
function formatContent(text: string): string {
  if (!text) return '';
  
  let result = text;
  
  // Bold: **text**
  result = result.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  
  // Italic: *text*
  result = result.replace(/\*([^*]+)\*/g, '<em>$1</em>');
  
  // Code: `text`
  result = result.replace(/`([^`]+)`/g, '<code class="bg-muted px-1 py-0.5 rounded text-sm">$1</code>');
  
  // Links: [text](url)
  result = result.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener" class="text-emerald-600 hover:underline">$1</a>');
  
  // Newlines
  result = result.replace(/\n/g, '<br/>');
  
  return result;
}

export function MathRenderer({ content }: MathRendererProps) {
  const renderedContent = useMemo(() => {
    return formatContent(content);
  }, [content]);

  if (!content) return null;

  return (
    <div 
      className="prose prose-sm dark:prose-invert max-w-none"
      dangerouslySetInnerHTML={{ __html: renderedContent }}
    />
  );
}

export function formatMath(text: string): string {
  return text;
}
