'use client';

import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RefreshCw, Check, X, ShieldCheck, AlertTriangle } from 'lucide-react';

interface CaptchaProps {
  onVerify: (verified: boolean) => void;
}

interface CaptchaChallenge {
  num1: number;
  num2: number;
  operator: '+' | '-' | '×';
  answer: number;
}

// Generate challenge
function generateNewChallenge(): CaptchaChallenge {
  const operators: ('+' | '-' | '×')[] = ['+', '-', '×'];
  const operator = operators[Math.floor(Math.random() * operators.length)];
  
  let num1: number;
  let num2: number;
  let answer: number;

  switch (operator) {
    case '+':
      num1 = Math.floor(Math.random() * 20) + 1;
      num2 = Math.floor(Math.random() * 20) + 1;
      answer = num1 + num2;
      break;
    case '-':
      num1 = Math.floor(Math.random() * 20) + 10;
      num2 = Math.floor(Math.random() * num1);
      answer = num1 - num2;
      break;
    case '×':
      num1 = Math.floor(Math.random() * 10) + 1;
      num2 = Math.floor(Math.random() * 10) + 1;
      answer = num1 * num2;
      break;
  }

  return { num1, num2, operator, answer };
}

// Rate limiting
const MAX_ATTEMPTS_PER_MINUTE = 10;
const LOCKOUT_DURATION = 60000;

export function Captcha({ onVerify }: CaptchaProps) {
  // Use a ref to track if we've generated a real challenge
  const hasGeneratedChallenge = useRef(false);
  
  // Fixed initial challenge to prevent hydration mismatch
  const [challenge, setChallenge] = useState<CaptchaChallenge>({ num1: 5, num2: 3, operator: '+', answer: 8 });
  const [userAnswer, setUserAnswer] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [lockoutRemaining, setLockoutRemaining] = useState(0);
  const [attempts, setAttempts] = useState(0);
  
  const attemptsInLastMinute = useRef<number[]>([]);
  const lockoutIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Generate challenge on first interaction (client-side only)
  const ensureChallengeGenerated = () => {
    if (!hasGeneratedChallenge.current) {
      hasGeneratedChallenge.current = true;
      setChallenge(generateNewChallenge());
    }
  };

  // Lockout countdown effect
  useEffect(() => {
    if (isLocked && lockoutRemaining > 0) {
      lockoutIntervalRef.current = setInterval(() => {
        setLockoutRemaining(prev => {
          if (prev <= 1000) {
            setIsLocked(false);
            ensureChallengeGenerated();
            setChallenge(generateNewChallenge());
            setUserAnswer('');
            setIsVerified(false);
            setHasError(false);
            setAttempts(0);
            onVerify(false);
            return 0;
          }
          return prev - 1000;
        });
      }, 1000);
      
      return () => {
        if (lockoutIntervalRef.current) {
          clearInterval(lockoutIntervalRef.current);
        }
      };
    }
  }, [isLocked, lockoutRemaining, onVerify]);

  const regenerateChallenge = () => {
    ensureChallengeGenerated();
    setChallenge(generateNewChallenge());
    setUserAnswer('');
    setIsVerified(false);
    setHasError(false);
    setAttempts(0);
    onVerify(false);
  };

  const checkRateLimit = () => {
    const now = Date.now();
    attemptsInLastMinute.current = attemptsInLastMinute.current.filter(
      time => now - time < 60000
    );
    
    if (attemptsInLastMinute.current.length >= MAX_ATTEMPTS_PER_MINUTE) {
      setIsLocked(true);
      setLockoutRemaining(LOCKOUT_DURATION);
      return false;
    }
    
    attemptsInLastMinute.current.push(now);
    return true;
  };

  const verifyAnswer = () => {
    ensureChallengeGenerated();
    if (isLocked) return;
    if (!checkRateLimit()) return;
    
    const userNum = parseInt(userAnswer, 10);
    
    if (isNaN(userNum)) {
      setHasError(true);
      onVerify(false);
      return;
    }
    
    if (userNum === challenge.answer) {
      setIsVerified(true);
      setHasError(false);
      onVerify(true);
    } else {
      setHasError(true);
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      onVerify(false);
      
      if (newAttempts >= 3) {
        setTimeout(() => regenerateChallenge(), 1000);
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && userAnswer && !isLocked) {
      e.preventDefault();
      verifyAnswer();
    }
  };

  const formatTime = (ms: number) => {
    const seconds = Math.ceil(ms / 1000);
    return `${seconds}s`;
  };

  return (
    <div className="space-y-3" onClick={ensureChallengeGenerated} onFocus={ensureChallengeGenerated}>
      <Label className="text-slate-300 flex items-center gap-2">
        <ShieldCheck className="h-4 w-4 text-emerald-400" />
        Verificación de Seguridad
        <span className="text-xs text-amber-400 ml-auto">Obligatorio</span>
      </Label>
      
      <div className="bg-white/5 border border-white/10 rounded-lg p-4">
        {isLocked ? (
          <div className="flex items-center justify-center gap-2 text-amber-400 py-2">
            <AlertTriangle className="h-5 w-5" />
            <span className="font-medium">
              Demasiados intentos. Espera {formatTime(lockoutRemaining)}
            </span>
          </div>
        ) : isVerified ? (
          <div className="flex items-center justify-center gap-2 text-emerald-400 py-2">
            <Check className="h-5 w-5" />
            <span className="font-medium">Verificación completada ✓</span>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <span className="text-2xl font-bold text-white tabular-nums">
                  {challenge.num1} {challenge.operator} {challenge.num2} = ?
                </span>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={regenerateChallenge}
                className="text-slate-400 hover:text-white hover:bg-white/10"
                disabled={isLocked}
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  type="number"
                  placeholder="Tu respuesta"
                  value={userAnswer}
                  onChange={(e) => {
                    setUserAnswer(e.target.value);
                    setHasError(false);
                  }}
                  onKeyPress={handleKeyPress}
                  disabled={isLocked}
                  className={`bg-white/5 border-white/10 text-white placeholder:text-slate-500 
                    ${hasError ? 'border-red-500 focus:border-red-500' : 'focus:border-emerald-500'}`}
                />
                {hasError && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    <X className="h-4 w-4 text-red-500" />
                  </div>
                )}
              </div>
              <Button
                type="button"
                onClick={verifyAnswer}
                disabled={!userAnswer || isLocked}
                className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50"
              >
                Verificar
              </Button>
            </div>
            
            {hasError && (
              <p className="text-sm text-red-400 mt-2">
                Respuesta incorrecta. {attempts >= 2 ? 'Se generará un nuevo desafío.' : `Intento ${attempts + 1}/3`}
              </p>
            )}
          </>
        )}
      </div>
    </div>
  );
}
