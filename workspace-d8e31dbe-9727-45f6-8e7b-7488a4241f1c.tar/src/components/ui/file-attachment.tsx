'use client';

import { useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { useAppStore, FileAttachment } from '@/store';
import { Paperclip, X, File, FileImage, FileCode, FileText, Music, Video, FileSpreadsheet, Archive } from 'lucide-react';
import { toast } from 'sonner';

// Maximum file size (10MB)
const MAX_FILE_SIZE = 10 * 1024 * 1024;

function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Component to render the appropriate icon based on file type
function FileIcon({ type, className }: { type: string; className?: string }) {
  if (type.startsWith('image/')) return <FileImage className={className} />;
  if (type.includes('pdf') || type.includes('document') || type.includes('text/plain')) return <FileText className={className} />;
  if (type.includes('javascript') || type.includes('json') || type.includes('typescript') || type.includes('html') || type.includes('css')) return <FileCode className={className} />;
  if (type.startsWith('audio/')) return <Music className={className} />;
  if (type.startsWith('video/')) return <Video className={className} />;
  if (type.includes('spreadsheet') || type.includes('excel') || type.includes('csv')) return <FileSpreadsheet className={className} />;
  if (type.includes('zip') || type.includes('rar') || type.includes('tar') || type.includes('gz')) return <Archive className={className} />;
  return <File className={className} />;
}

export function FileAttachmentButton() {
  const { attachments, addAttachment, removeAttachment } = useAppStore();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach((file) => {
      if (file.size > MAX_FILE_SIZE) {
        toast.error(`El archivo ${file.name} excede el tamaño máximo de 10MB`);
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const attachment: FileAttachment = {
          id: crypto.randomUUID(),
          name: file.name,
          type: file.type,
          size: file.size,
          content: reader.result as string,
        };
        addAttachment(attachment);
        toast.success(`Archivo ${file.name} adjuntado`);
      };
      
      reader.onerror = () => {
        toast.error(`Error al leer el archivo ${file.name}`);
      };

      if (file.type.startsWith('image/')) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, [addAttachment]);

  const handleRemove = useCallback((id: string, name: string) => {
    removeAttachment(id);
    toast.info(`Archivo ${name} eliminado`);
  }, [removeAttachment]);

  return (
    <div className="relative">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*,.pdf,.doc,.docx,.txt,.csv,.json,.js,.ts,.py,.java,.html,.css"
        onChange={handleFileSelect}
        className="hidden"
      />
      
      <Button
        type="button"
        variant="ghost"
        size="icon"
        onClick={() => fileInputRef.current?.click()}
        className="text-muted-foreground hover:text-foreground"
        title="Adjuntar archivo"
      >
        <Paperclip className="h-5 w-5" />
      </Button>

      {attachments.length > 0 && (
        <div className="absolute bottom-full left-0 mb-2 w-72 bg-card border rounded-lg shadow-lg p-2 space-y-2 z-50">
          <p className="text-xs text-muted-foreground px-1">
            Archivos adjuntos ({attachments.length})
          </p>
          {attachments.map((file) => (
            <div
              key={file.id}
              className="flex items-center gap-2 p-2 bg-muted rounded-md group"
            >
              <FileIcon type={file.type} className="h-4 w-4 text-muted-foreground shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate">{file.name}</p>
                <p className="text-[10px] text-muted-foreground">
                  {formatFileSize(file.size)}
                </p>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="h-6 w-6 opacity-0 group-hover:opacity-100"
                onClick={() => handleRemove(file.id, file.name)}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

interface FilePreviewProps {
  attachment: FileAttachment;
}

export function FilePreview({ attachment }: FilePreviewProps) {
  if (attachment.type.startsWith('image/') && attachment.content) {
    return (
      <div className="relative inline-block">
        <img
          src={attachment.content}
          alt={attachment.name}
          className="max-w-xs max-h-40 rounded-lg border"
        />
      </div>
    );
  }
  
  return (
    <div className="flex items-center gap-2 p-2 bg-muted rounded-lg">
      <FileIcon type={attachment.type} className="h-5 w-5 text-muted-foreground" />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium truncate">{attachment.name}</p>
        <p className="text-xs text-muted-foreground">{formatFileSize(attachment.size)}</p>
      </div>
    </div>
  );
}
