'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Pen, Loader2, Copy, Check, Sparkles, FileText, 
  BookOpen, Newspaper, FileEdit, MessageSquare, 
  Wand2, RefreshCw, Download, Type
} from 'lucide-react';
import { toast } from 'sonner';

const writingTypes = [
  { id: 'blog', name: 'Blog Post', icon: BookOpen, description: 'Artículo para blog' },
  { id: 'article', name: 'Artículo', icon: Newspaper, description: 'Artículo periodístico' },
  { id: 'essay', name: 'Ensayo', icon: FileText, description: 'Ensayo académico' },
  { id: 'story', name: 'Historia', icon: BookOpen, description: 'Narrativa creativa' },
  { id: 'copy', name: 'Copywriting', icon: MessageSquare, description: 'Texto persuasivo' },
  { id: 'email', name: 'Email', icon: FileEdit, description: 'Email profesional' },
];

const toneOptions = [
  'Profesional', 'Casual', 'Formal', 'Amigable', 'Técnico', 'Creativo', 'Persuasivo', 'Informativo'
];

export function WritingFeature() {
  const { isLoading, setIsLoading, profileSettings } = useAppStore();
  const [writingType, setWritingType] = useState('blog');
  const [topic, setTopic] = useState('');
  const [tone, setTone] = useState('Profesional');
  const [length, setLength] = useState('medium');
  const [generatedText, setGeneratedText] = useState('');
  const [copied, setCopied] = useState(false);

  const handleGenerate = useCallback(async () => {
    if (!topic.trim() || isLoading) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/writing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: writingType,
          topic,
          tone,
          length,
          model: profileSettings.aiModel,
        }),
      });

      const data = await response.json();
      if (data.content) {
        setGeneratedText(data.content);
        toast.success('¡Texto generado exitosamente!');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al generar el texto');
    } finally {
      setIsLoading(false);
    }
  }, [writingType, topic, tone, length, isLoading, setIsLoading, profileSettings.aiModel]);

  const handleCopy = useCallback(async () => {
    await navigator.clipboard.writeText(generatedText);
    setCopied(true);
    toast.success('Copiado al portapapeles');
    setTimeout(() => setCopied(false), 2000);
  }, [generatedText]);

  const handleDownload = useCallback((format: string) => {
    const blob = new Blob([generatedText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `escritura-${writingType}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success(`Descargando como ${format.toUpperCase()}`);
  }, [generatedText, writingType]);

  const handleImprove = useCallback(async () => {
    if (!generatedText || isLoading) return;
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/writing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'improve',
          topic: generatedText,
          tone,
          model: profileSettings.aiModel,
        }),
      });

      const data = await response.json();
      if (data.content) {
        setGeneratedText(data.content);
        toast.success('¡Texto mejorado!');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al mejorar el texto');
    } finally {
      setIsLoading(false);
    }
  }, [generatedText, tone, isLoading, setIsLoading, profileSettings.aiModel]);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
            <Pen className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              Escribiendo
              <Badge className="bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300">Beta</Badge>
            </h2>
            <p className="text-muted-foreground">Asistente de escritura avanzado con IA</p>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Wand2 className="h-5 w-5 text-purple-600" />
                Configuración
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Writing Type */}
              <div className="space-y-2">
                <Label>Tipo de escritura</Label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {writingTypes.map((type) => (
                    <Button
                      key={type.id}
                      variant={writingType === type.id ? 'default' : 'outline'}
                      className={`h-auto py-3 flex flex-col items-center gap-1 ${writingType === type.id ? 'bg-purple-600 hover:bg-purple-700' : ''}`}
                      onClick={() => setWritingType(type.id)}
                    >
                      <type.icon className="h-5 w-5" />
                      <span className="text-xs">{type.name}</span>
                    </Button>
                  ))}
                </div>
              </div>

              {/* Topic */}
              <div className="space-y-2">
                <Label>Tema o idea principal</Label>
                <Textarea
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="Describe el tema que quieres escribir..."
                  className="min-h-24"
                />
              </div>

              {/* Tone */}
              <div className="space-y-2">
                <Label>Tono</Label>
                <div className="flex flex-wrap gap-2">
                  {toneOptions.map((t) => (
                    <Button
                      key={t}
                      variant={tone === t ? 'default' : 'outline'}
                      size="sm"
                      className={tone === t ? 'bg-purple-600 hover:bg-purple-700' : ''}
                      onClick={() => setTone(t)}
                    >
                      {t}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Length */}
              <div className="space-y-2">
                <Label>Longitud</Label>
                <div className="flex gap-2">
                  {[
                    { id: 'short', label: 'Corto', words: '~300' },
                    { id: 'medium', label: 'Medio', words: '~600' },
                    { id: 'long', label: 'Largo', words: '~1000+' },
                  ].map((l) => (
                    <Button
                      key={l.id}
                      variant={length === l.id ? 'default' : 'outline'}
                      className={`flex-1 ${length === l.id ? 'bg-purple-600 hover:bg-purple-700' : ''}`}
                      onClick={() => setLength(l.id)}
                    >
                      <div className="text-center">
                        <div className="font-medium">{l.label}</div>
                        <div className="text-xs opacity-70">{l.words} palabras</div>
                      </div>
                    </Button>
                  ))}
                </div>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={!topic.trim() || isLoading}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Escribiendo...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" />
                    Generar Texto
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Output */}
          <Card className="flex flex-col">
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText className="h-5 w-5 text-purple-600" />
                Texto Generado
              </CardTitle>
              {generatedText && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleImprove} disabled={isLoading}>
                    <RefreshCw className="h-4 w-4 mr-1" />
                    Mejorar
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleCopy}>
                    {copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleDownload('txt')}>
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent className="flex-1">
              {generatedText ? (
                <ScrollArea className="h-96">
                  <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap font-mono text-sm">
                    {generatedText}
                  </div>
                </ScrollArea>
              ) : (
                <div className="h-96 flex items-center justify-center text-center">
                  <div>
                    <Pen className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                    <p className="text-muted-foreground">
                      El texto generado aparecerá aquí
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Templates */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Plantillas rápidas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
              {[
                'Cómo la IA está transformando la medicina en 2026',
                'Guía completa de productividad personal',
                'Los 10 mejores destinos turísticos emergentes',
                'Estrategias de marketing digital para startups',
              ].map((template) => (
                <Button
                  key={template}
                  variant="outline"
                  className="h-auto py-3 text-left justify-start hover:bg-purple-50 dark:hover:bg-purple-900/20"
                  onClick={() => setTopic(template)}
                >
                  <Type className="h-4 w-4 mr-2 shrink-0" />
                  <span className="text-xs truncate">{template}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
