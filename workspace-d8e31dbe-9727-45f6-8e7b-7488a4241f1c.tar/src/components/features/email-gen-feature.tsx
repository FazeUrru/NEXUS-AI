'use client';

import { useState } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Mail, Loader2, Copy } from 'lucide-react';

export function EmailGenFeature() {
  const { isLoading, setIsLoading } = useAppStore();
  const [subject, setSubject] = useState('');
  const [recipient, setRecipient] = useState('');
  const [purpose, setPurpose] = useState('professional');
  const [tone, setTone] = useState('formal');
  const [keyPoints, setKeyPoints] = useState('');
  const [generatedEmail, setGeneratedEmail] = useState('');

  const handleGenerate = async () => {
    if (!subject.trim() || isLoading) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject,
          recipient,
          purpose,
          tone,
          keyPoints,
        }),
      });

      const data = await response.json();
      if (data.email) {
        setGeneratedEmail(data.email);
      }
    } catch (error) {
      console.error('Error generating email:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(generatedEmail);
  };

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5 text-emerald-600" />
              Generador de Emails
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Asunto</Label>
                <Input
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="¿De qué trata el email?"
                />
              </div>
              <div className="space-y-2">
                <Label>Destinatario (opcional)</Label>
                <Input
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  placeholder="¿A quién va dirigido?"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Propósito</Label>
                <Select value={purpose} onValueChange={setPurpose}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="professional">Profesional</SelectItem>
                    <SelectItem value="followup">Seguimiento</SelectItem>
                    <SelectItem value="introduction">Presentación</SelectItem>
                    <SelectItem value="request">Solicitud</SelectItem>
                    <SelectItem value="thankyou">Agradecimiento</SelectItem>
                    <SelectItem value="apology">Disculpa</SelectItem>
                    <SelectItem value="invitation">Invitación</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Tono</Label>
                <Select value={tone} onValueChange={setTone}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="formal">Formal</SelectItem>
                    <SelectItem value="semiformal">Semi-formal</SelectItem>
                    <SelectItem value="casual">Casual</SelectItem>
                    <SelectItem value="friendly">Amigable</SelectItem>
                    <SelectItem value="urgent">Urgente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Puntos clave (opcional)</Label>
              <Textarea
                value={keyPoints}
                onChange={(e) => setKeyPoints(e.target.value)}
                placeholder="¿Qué puntos importantes debe incluir el email?"
                className="min-h-24"
              />
            </div>

            <Button
              onClick={handleGenerate}
              disabled={!subject.trim() || isLoading}
              className="w-full bg-emerald-600 hover:bg-emerald-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generando...
                </>
              ) : (
                <>
                  <Mail className="mr-2 h-4 w-4" />
                  Generar Email
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {generatedEmail && (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Email Generado</CardTitle>
              <Button variant="outline" size="sm" onClick={handleCopy}>
                <Copy className="mr-2 h-4 w-4" />
                Copiar
              </Button>
            </CardHeader>
            <CardContent>
              <div className="whitespace-pre-wrap bg-muted p-4 rounded-lg">{generatedEmail}</div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
