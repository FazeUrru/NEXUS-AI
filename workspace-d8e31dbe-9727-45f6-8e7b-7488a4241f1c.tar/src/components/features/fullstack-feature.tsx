'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Layers, Loader2, Sparkles, FolderTree, Code } from 'lucide-react';
import { toast } from 'sonner';

export function FullstackFeature() {
  const { isLoading, setIsLoading, profileSettings } = useAppStore();
  const [projectName, setProjectName] = useState('');
  const [description, setDescription] = useState('');
  const [result, setResult] = useState<{ structure: string; frontend: any[]; backend: any[]; features: string[] } | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!projectName.trim() || !description.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/fullstack', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectType: 'saas', techStack: 'nextjs', projectName, description, model: profileSettings.aiModel }),
      });
      const data = await response.json();
      if (data.project) {
        setResult(data.project);
        toast.success('¡Proyecto fullstack generado!');
      }
    } catch (error) {
      toast.error('Error al generar proyecto');
    } finally {
      setIsLoading(false);
    }
  }, [projectName, description, isLoading, setIsLoading, profileSettings.aiModel]);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center">
            <Layers className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Fullstack</h2>
            <p className="text-muted-foreground">Genera proyectos fullstack completos</p>
          </div>
          <Badge className="bg-indigo-100 text-indigo-700">Pro</Badge>
        </div>

        <Card>
          <CardContent className="p-6 space-y-4">
            <Input value={projectName} onChange={(e) => setProjectName(e.target.value)} placeholder="Nombre del proyecto..." />
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe tu proyecto fullstack..." className="min-h-24" />
            <Button onClick={handleGenerate} disabled={!projectName.trim() || !description.trim() || isLoading} className="w-full bg-indigo-600 hover:bg-indigo-700">
              {isLoading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Generando...</> : <><Sparkles className="mr-2 h-4 w-4" />Generar Proyecto Fullstack</>}
            </Button>
          </CardContent>
        </Card>

        {result && (
          <div className="grid gap-4">
            <Card>
              <CardHeader className="flex-row items-center gap-2"><FolderTree className="h-5 w-5 text-indigo-600" /><CardTitle>Estructura del Proyecto</CardTitle></CardHeader>
              <CardContent><pre className="text-xs font-mono bg-muted p-4 rounded overflow-auto">{result.structure}</pre></CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle>Características</CardTitle></CardHeader>
              <CardContent><div className="flex flex-wrap gap-2">{result.features.map((f, i) => <Badge key={i} variant="secondary">{f}</Badge>)}</div></CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
