'use client';

import { useState } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Heart, Loader2, Smile, Meh, Frown, Angry, Laugh } from 'lucide-react';

interface SentimentResult {
  sentiment: string;
  confidence: number;
  emotions: {
    joy: number;
    sadness: number;
    anger: number;
    fear: number;
    surprise: number;
  };
  explanation: string;
}

const sentimentIcons: Record<string, React.ElementType> = {
  positive: Laugh,
  neutral: Meh,
  negative: Frown,
  very_negative: Angry,
};

const sentimentColors: Record<string, string> = {
  positive: 'text-emerald-600',
  neutral: 'text-amber-600',
  negative: 'text-orange-600',
  very_negative: 'text-red-600',
};

export function SentimentFeature() {
  const { isLoading, setIsLoading } = useAppStore();
  const [text, setText] = useState('');
  const [result, setResult] = useState<SentimentResult | null>(null);

  const handleAnalyze = async () => {
    if (!text.trim() || isLoading) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/sentiment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });

      const data = await response.json();
      if (data.result) {
        setResult(data.result);
      }
    } catch (error) {
      console.error('Error analyzing sentiment:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const SentimentIcon = result ? sentimentIcons[result.sentiment] || Meh : Meh;

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="h-5 w-5 text-emerald-600" />
              Análisis de Sentimiento
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Texto a analizar</label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Escribe o pega el texto cuyo sentimiento deseas analizar..."
                className="min-h-32"
              />
            </div>

            <Button
              onClick={handleAnalyze}
              disabled={!text.trim() || isLoading}
              className="w-full bg-emerald-600 hover:bg-emerald-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analizando...
                </>
              ) : (
                <>
                  <Heart className="mr-2 h-4 w-4" />
                  Analizar Sentimiento
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {result && (
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Sentimiento General</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center">
                  <SentimentIcon className={`h-16 w-16 mb-4 ${sentimentColors[result.sentiment]}`} />
                  <p className="text-xl font-semibold capitalize">{result.sentiment.replace('_', ' ')}</p>
                  <div className="w-full mt-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Confianza</span>
                      <span>{Math.round(result.confidence * 100)}%</span>
                    </div>
                    <Progress value={result.confidence * 100} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Emociones Detectadas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(result.emotions).map(([emotion, value]) => (
                  <div key={emotion}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="capitalize">{emotion}</span>
                      <span>{Math.round(value * 100)}%</span>
                    </div>
                    <Progress value={value * 100} className="h-2" />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg">Explicación</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{result.explanation}</p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
