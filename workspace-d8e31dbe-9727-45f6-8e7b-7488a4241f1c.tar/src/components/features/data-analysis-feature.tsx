'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  BarChart3, Loader2, Upload, PieChart, TrendingUp, 
  Activity, FileSpreadsheet, Brain, 
  Sparkles, Copy, Check, AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';

const analysisTypes = [
  { id: 'descriptive', name: 'Descriptivo', icon: PieChart, description: 'Estadísticas básicas y resumen' },
  { id: 'trend', name: 'Tendencias', icon: TrendingUp, description: 'Análisis de patrones temporales' },
  { id: 'correlation', name: 'Correlación', icon: Activity, description: 'Relaciones entre variables' },
  { id: 'predictive', name: 'Predictivo', icon: Brain, description: 'Predicciones basadas en datos' },
];

interface AnalysisResult {
  summary: string;
  insights: string[];
  statistics?: Record<string, number | string>;
  recommendations: string[];
  visualizations?: { type: string; description: string }[];
}

export function DataAnalysisFeature() {
  const { isLoading, setIsLoading, profileSettings } = useAppStore();
  const [analysisType, setAnalysisType] = useState('descriptive');
  const [dataInput, setDataInput] = useState('');
  const [question, setQuestion] = useState('');
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [copied, setCopied] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<string | null>(null);

  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        setDataInput(content);
        setUploadedFile(file.name);
        toast.success(`Archivo "${file.name}" cargado`);
      };
      reader.readAsText(file);
    }
  }, []);

  const handleAnalyze = useCallback(async () => {
    if (!dataInput.trim() || isLoading) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/data-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: analysisType,
          data: dataInput,
          question,
          model: profileSettings.aiModel,
        }),
      });

      const data = await response.json();
      if (data.result) {
        setResult(data.result);
        toast.success('¡Análisis completado!');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error en el análisis');
    } finally {
      setIsLoading(false);
    }
  }, [analysisType, dataInput, question, isLoading, setIsLoading, profileSettings.aiModel]);

  const handleCopy = useCallback(async () => {
    if (!result) return;
    const text = `Resumen:\n${result.summary}\n\nInsights:\n${result.insights.map((i, n) => `${n + 1}. ${i}`).join('\n')}\n\nRecomendaciones:\n${result.recommendations.map((r, n) => `${n + 1}. ${r}`).join('\n')}`;
    await navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success('Copiado al portapapeles');
    setTimeout(() => setCopied(false), 2000);
  }, [result]);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center">
            <BarChart3 className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              Análisis de Datos
              <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">Beta</Badge>
            </h2>
            <p className="text-muted-foreground">Analiza datos y obtén insights con IA</p>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Input */}
          <div className="space-y-4">
            {/* Analysis Type */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <PieChart className="h-5 w-5 text-blue-600" />
                  Tipo de Análisis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  {analysisTypes.map((type) => (
                    <Button
                      key={type.id}
                      variant={analysisType === type.id ? 'default' : 'outline'}
                      className={`h-auto py-3 flex flex-col items-center gap-1 ${analysisType === type.id ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
                      onClick={() => setAnalysisType(type.id)}
                    >
                      <type.icon className="h-5 w-5" />
                      <span className="text-xs font-medium">{type.name}</span>
                      <span className="text-[10px] opacity-70">{type.description}</span>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Data Input */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileSpreadsheet className="h-5 w-5 text-blue-600" />
                  Datos
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* File Upload */}
                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    accept=".csv,.txt,.json"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="file-upload"
                  />
                  <Button variant="outline" asChild className="flex-1">
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <Upload className="h-4 w-4 mr-2" />
                      {uploadedFile || 'Subir CSV/TXT/JSON'}
                    </label>
                  </Button>
                  {uploadedFile && (
                    <Button variant="ghost" size="sm" onClick={() => { setUploadedFile(null); setDataInput(''); }}>
                      ×
                    </Button>
                  )}
                </div>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-card px-2 text-muted-foreground">o pega los datos</span>
                  </div>
                </div>

                <Textarea
                  value={dataInput}
                  onChange={(e) => setDataInput(e.target.value)}
                  placeholder="Pega aquí tus datos (CSV, JSON, o texto separado por comas)..."
                  className="min-h-32 font-mono text-sm"
                />
              </CardContent>
            </Card>

            {/* Question */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Brain className="h-5 w-5 text-blue-600" />
                  Pregunta (opcional)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Input
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  placeholder="¿Qué quieres descubrir de estos datos?"
                />
              </CardContent>
            </Card>

            <Button
              onClick={handleAnalyze}
              disabled={!dataInput.trim() || isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analizando...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Analizar Datos
                </>
              )}
            </Button>
          </div>

          {/* Results */}
          <Card className="flex flex-col">
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Activity className="h-5 w-5 text-blue-600" />
                Resultados
              </CardTitle>
              {result && (
                <Button variant="outline" size="sm" onClick={handleCopy}>
                  {copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
                </Button>
              )}
            </CardHeader>
            <CardContent className="flex-1">
              {result ? (
                <ScrollArea className="h-[500px]">
                  <div className="space-y-4">
                    {/* Summary */}
                    <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                      <h4 className="font-medium mb-2">Resumen</h4>
                      <p className="text-sm text-muted-foreground">{result.summary}</p>
                    </div>

                    {/* Insights */}
                    <div>
                      <h4 className="font-medium mb-2">Insights</h4>
                      <div className="space-y-2">
                        {result.insights.map((insight, i) => (
                          <div
                            key={i}
                            className="flex items-start gap-2 p-3 rounded-lg bg-muted"
                          >
                            <span className="text-blue-600 font-bold">{i + 1}.</span>
                            <span className="text-sm">{insight}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Statistics */}
                    {result.statistics && Object.keys(result.statistics).length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Estadísticas</h4>
                        <div className="grid grid-cols-2 gap-2">
                          {Object.entries(result.statistics).map(([key, value]) => (
                            <div key={key} className="p-3 rounded-lg bg-muted">
                              <div className="text-xs text-muted-foreground">{key}</div>
                              <div className="text-lg font-bold">{value}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Recommendations */}
                    <div>
                      <h4 className="font-medium mb-2">Recomendaciones</h4>
                      <div className="space-y-2">
                        {result.recommendations.map((rec, i) => (
                          <div key={i} className="flex items-start gap-2 p-3 rounded-lg border">
                            <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
                            <span className="text-sm">{rec}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </ScrollArea>
              ) : (
                <div className="h-[500px] flex items-center justify-center text-center">
                  <div>
                    <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                    <p className="text-muted-foreground">
                      Los resultados del análisis aparecerán aquí
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
