'use client';

import { useState } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Loader2, AlertCircle, Check, X } from 'lucide-react';

interface Correction {
  original: string;
  corrected: string;
  type: string;
  explanation: string;
}

interface GrammarResult {
  correctedText: string;
  corrections: Correction[];
  score: number;
}

export function GrammarFeature() {
  const { isLoading, setIsLoading } = useAppStore();
  const [text, setText] = useState('');
  const [result, setResult] = useState<GrammarResult | null>(null);

  const handleCorrect = async () => {
    if (!text.trim() || isLoading) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/grammar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });

      const data = await response.json();
      if (data.result) {
        setResult(data.result);
      }
    } catch (error) {
      console.error('Error correcting grammar:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-emerald-600" />
              Corrección Gramatical
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Texto a corregir</label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Escribe o pega el texto que deseas corregir..."
                className="min-h-32"
              />
            </div>

            <Button
              onClick={handleCorrect}
              disabled={!text.trim() || isLoading}
              className="w-full bg-emerald-600 hover:bg-emerald-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Corrigiendo...
                </>
              ) : (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Corregir Texto
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {result && (
          <div className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">Texto Corregido</CardTitle>
                <Badge variant={result.score >= 80 ? 'default' : result.score >= 60 ? 'secondary' : 'destructive'}>
                  Puntuación: {result.score}%
                </Badge>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-wrap">{result.correctedText}</p>
              </CardContent>
            </Card>

            {result.corrections.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-amber-500" />
                    Correcciones ({result.corrections.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {result.corrections.map((correction, index) => (
                      <div key={index} className="p-3 rounded-lg border bg-muted/50">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline">{correction.type}</Badge>
                        </div>
                        <div className="flex items-center gap-2 mb-2">
                          <span className="line-through text-red-500">{correction.original}</span>
                          <X className="h-4 w-4 text-red-500" />
                          <span className="text-emerald-600">{correction.corrected}</span>
                          <Check className="h-4 w-4 text-emerald-600" />
                        </div>
                        <p className="text-sm text-muted-foreground">{correction.explanation}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
