'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Smartphone, Loader2, Sparkles, Play } from 'lucide-react';
import { toast } from 'sonner';

export function AppsFeature() {
  const { isLoading, setIsLoading, profileSettings } = useAppStore();
  const [description, setDescription] = useState('');
  const [result, setResult] = useState<{ structure: string; screens: any[]; features: string[] } | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!description.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/apps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'mobile', category: 'Productividad', description, model: profileSettings.aiModel }),
      });
      const data = await response.json();
      if (data.app) {
        setResult(data.app);
        toast.success('¡App generada!');
      }
    } catch (error) {
      toast.error('Error al generar app');
    } finally {
      setIsLoading(false);
    }
  }, [description, isLoading, setIsLoading, profileSettings.aiModel]);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center">
            <Smartphone className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Aplicaciones</h2>
            <p className="text-muted-foreground">Genera apps completas con IA</p>
          </div>
          <Badge className="bg-green-100 text-green-700">Pro</Badge>
        </div>

        <Card>
          <CardContent className="p-6 space-y-4">
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe la aplicación que quieres crear..." className="min-h-24" />
            <Button onClick={handleGenerate} disabled={!description.trim() || isLoading} className="w-full bg-green-600 hover:bg-green-700">
              {isLoading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Generando...</> : <><Sparkles className="mr-2 h-4 w-4" />Generar App</>}
            </Button>
          </CardContent>
        </Card>

        {result && (
          <div className="grid gap-4">
            <Card>
              <CardHeader><CardTitle>Estructura</CardTitle></CardHeader>
              <CardContent><pre className="text-xs font-mono bg-muted p-4 rounded overflow-auto">{result.structure}</pre></CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle>Funcionalidades</CardTitle></CardHeader>
              <CardContent><div className="flex flex-wrap gap-2">{result.features.map((f, i) => <Badge key={i}>{f}</Badge>)}</div></CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
