'use client';

import { useState } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Type, Loader2, Copy, RefreshCw } from 'lucide-react';

export function TitlesFeature() {
  const { isLoading, setIsLoading } = useAppStore();
  const [topic, setTopic] = useState('');
  const [context, setContext] = useState('');
  const [style, setStyle] = useState('catchy');
  const [count, setCount] = useState('5');
  const [titles, setTitles] = useState<string[]>([]);

  const handleGenerate = async () => {
    if (!topic.trim() || isLoading) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/titles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          context,
          style,
          count: parseInt(count),
        }),
      });

      const data = await response.json();
      if (data.titles) {
        setTitles(data.titles);
      }
    } catch (error) {
      console.error('Error generating titles:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Type className="h-5 w-5 text-emerald-600" />
              Generador de Títulos
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Tema principal</Label>
              <Input
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="¿Cuál es el tema de tu contenido?"
              />
            </div>

            <div className="space-y-2">
              <Label>Contexto adicional (opcional)</Label>
              <Textarea
                value={context}
                onChange={(e) => setContext(e.target.value)}
                placeholder="Añade más detalles sobre el contenido..."
                className="min-h-20"
              />
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Estilo</Label>
                <Select value={style} onValueChange={setStyle}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="catchy">Llamativo</SelectItem>
                    <SelectItem value="professional">Profesional</SelectItem>
                    <SelectItem value="question">Pregunta</SelectItem>
                    <SelectItem value="howto">Cómo hacer</SelectItem>
                    <SelectItem value="list">Lista</SelectItem>
                    <SelectItem value="viral">Viral</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Cantidad</Label>
                <Select value={count} onValueChange={setCount}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 títulos</SelectItem>
                    <SelectItem value="5">5 títulos</SelectItem>
                    <SelectItem value="10">10 títulos</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={handleGenerate}
              disabled={!topic.trim() || isLoading}
              className="w-full bg-emerald-600 hover:bg-emerald-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generando...
                </>
              ) : (
                <>
                  <Type className="mr-2 h-4 w-4" />
                  Generar Títulos
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {titles.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Títulos Sugeridos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {titles.map((title, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between gap-3 p-3 rounded-lg border bg-muted/50"
                  >
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="shrink-0">
                        {index + 1}
                      </Badge>
                      <p className="font-medium">{title}</p>
                    </div>
                    <Button variant="ghost" size="icon" className="shrink-0">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4" onClick={handleGenerate}>
                <RefreshCw className="mr-2 h-4 w-4" />
                Generar más títulos
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
