'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Palette, Loader2, Sparkles, Eye, Copy } from 'lucide-react';
import { toast } from 'sonner';

export function UIDesignerFeature() {
  const { isLoading, setIsLoading, profileSettings } = useAppStore();
  const [description, setDescription] = useState('');
  const [result, setResult] = useState<{ html: string; css: string; components: any[] } | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!description.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/ui-designer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description, style: 'modern', model: profileSettings.aiModel }),
      });
      const data = await response.json();
      if (data.design) {
        setResult(data.design);
        toast.success('¡Diseño UI generado!');
      }
    } catch (error) {
      toast.error('Error al generar diseño');
    } finally {
      setIsLoading(false);
    }
  }, [description, isLoading, setIsLoading, profileSettings.aiModel]);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
            <Palette className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">UI Designer</h2>
            <p className="text-muted-foreground">Diseña interfaces modernas con IA</p>
          </div>
        </div>

        <Card>
          <CardContent className="p-6 space-y-4">
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe el componente UI que quieres diseñar..." className="min-h-24" />
            <Button onClick={handleGenerate} disabled={!description.trim() || isLoading} className="w-full bg-violet-600 hover:bg-violet-700">
              {isLoading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Generando...</> : <><Sparkles className="mr-2 h-4 w-4" />Generar Diseño UI</>}
            </Button>
          </CardContent>
        </Card>

        {result && (
          <Card>
            <CardHeader><CardTitle>Diseño Generado</CardTitle></CardHeader>
            <CardContent>
              <iframe srcDoc={`<!DOCTYPE html><html><head><script src="https://cdn.tailwindcss.com"></script><style>${result.css}</style></head><body class="p-4">${result.html}</body></html>`} className="w-full h-[300px] rounded-lg border" title="UI Preview" />
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
