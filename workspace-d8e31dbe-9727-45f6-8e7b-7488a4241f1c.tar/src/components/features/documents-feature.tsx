'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { FileText, Loader2, Sparkles, Download, Copy, Check } from 'lucide-react';
import { toast } from 'sonner';

const docTypes = [
  { id: 'report', name: 'Informe', description: 'Informe profesional' },
  { id: 'proposal', name: 'Propuesta', description: 'Propuesta de proyecto' },
  { id: 'article', name: 'Artículo', description: 'Artículo informativo' },
  { id: 'resume', name: 'CV', description: 'Currículum vitae' },
];

export function DocumentsFeature() {
  const { isLoading, setIsLoading, profileSettings } = useAppStore();
  const [docType, setDocType] = useState('report');
  const [topic, setTopic] = useState('');
  const [content, setContent] = useState('');

  const handleGenerate = useCallback(async () => {
    if (!topic.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/documents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: docType, topic, model: profileSettings.aiModel }),
      });
      const data = await response.json();
      if (data.content) {
        setContent(data.content);
        toast.success('¡Documento generado!');
      }
    } catch (error) {
      toast.error('Error al generar documento');
    } finally {
      setIsLoading(false);
    }
  }, [docType, topic, isLoading, setIsLoading, profileSettings.aiModel]);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
            <FileText className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Documentos IA</h2>
            <p className="text-muted-foreground">Genera documentos profesionales</p>
          </div>
        </div>

        <Card>
          <CardContent className="p-6 space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {docTypes.map(type => (
                <Button key={type.id} variant={docType === type.id ? 'default' : 'outline'} onClick={() => setDocType(type.id)} className={docType === type.id ? 'bg-blue-600 hover:bg-blue-700' : ''}>
                  <div className="text-center">
                    <div className="font-medium">{type.name}</div>
                    <div className="text-xs opacity-70">{type.description}</div>
                  </div>
                </Button>
              ))}
            </div>
            <Textarea value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="Tema del documento..." className="min-h-24" />
            <Button onClick={handleGenerate} disabled={!topic.trim() || isLoading} className="w-full bg-blue-600 hover:bg-blue-700">
              {isLoading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Generando...</> : <><Sparkles className="mr-2 h-4 w-4" />Generar Documento</>}
            </Button>
          </CardContent>
        </Card>

        {content && (
          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <CardTitle>Documento Generado</CardTitle>
              <Button variant="outline" size="sm" onClick={() => navigator.clipboard.writeText(content)}><Copy className="h-4 w-4 mr-1" />Copiar</Button>
            </CardHeader>
            <CardContent>
              <pre className="whitespace-pre-wrap font-mono text-sm bg-muted p-4 rounded-lg max-h-96 overflow-auto">{content}</pre>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
