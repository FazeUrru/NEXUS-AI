'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, Loader2, Sparkles, BookOpen, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';

export function DeepResearchFeature() {
  const { isLoading, setIsLoading, profileSettings } = useAppStore();
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<{ summary: string; keyPoints: string[]; sources: any[]; relatedTopics: string[] } | null>(null);

  const handleResearch = useCallback(async () => {
    if (!query.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/deep-research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: query, thinkMode: true, model: profileSettings.aiModel }),
      });
      const data = await response.json();
      if (data.response) {
        setResult({
          summary: data.response,
          keyPoints: data.keyPoints || [],
          sources: data.sources || [],
          relatedTopics: data.relatedTopics || [],
        });
        toast.success('¡Investigación completada!');
      }
    } catch (error) {
      toast.error('Error en la investigación');
    } finally {
      setIsLoading(false);
    }
  }, [query, isLoading, setIsLoading, profileSettings.aiModel]);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-600 flex items-center justify-center">
            <Search className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Investigación Profunda</h2>
            <p className="text-muted-foreground">Análisis exhaustivo con IA</p>
          </div>
          <Badge className="bg-blue-100 text-blue-700">Pro</Badge>
        </div>

        <Card>
          <CardContent className="p-6 space-y-4">
            <Textarea value={query} onChange={(e) => setQuery(e.target.value)} placeholder="¿Qué quieres investigar?" className="min-h-24" />
            <Button onClick={handleResearch} disabled={!query.trim() || isLoading} className="w-full bg-blue-600 hover:bg-blue-700">
              {isLoading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Investigando...</> : <><Sparkles className="mr-2 h-4 w-4" />Investigar</>}
            </Button>
          </CardContent>
        </Card>

        {result && (
          <div className="space-y-4">
            <Card>
              <CardHeader className="flex-row items-center gap-2"><BookOpen className="h-5 w-5 text-blue-600" /><CardTitle>Resumen</CardTitle></CardHeader>
              <CardContent><p className="text-sm">{result.summary}</p></CardContent>
            </Card>
            {result.keyPoints.length > 0 && (
              <Card>
                <CardHeader className="flex-row items-center gap-2"><TrendingUp className="h-5 w-5 text-blue-600" /><CardTitle>Puntos Clave</CardTitle></CardHeader>
                <CardContent>
                  <ul className="space-y-2">{result.keyPoints.map((p, i) => <li key={i} className="flex gap-2"><span className="font-bold text-blue-600">{i + 1}.</span>{p}</li>)}</ul>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
