'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Wand2, Loader2, Palette, Sparkles, Layout, 
  Type, Square, Layers, Copy, Check,
  Download, Eye, RefreshCw, Monitor, Smartphone, Tablet
} from 'lucide-react';
import { toast } from 'sonner';

const designTypes = [
  { id: 'landing', name: 'Landing Page', icon: Layout, description: 'Página de aterrizaje' },
  { id: 'dashboard', name: 'Dashboard', icon: Square, description: 'Panel de control' },
  { id: 'card', name: 'Tarjeta', icon: Square, description: 'Componente tarjeta' },
  { id: 'form', name: 'Formulario', icon: Layers, description: 'Formulario completo' },
  { id: 'profile', name: 'Perfil', icon: Square, description: 'Página de perfil' },
  { id: 'pricing', name: 'Precios', icon: Square, description: 'Tabla de precios' },
];

const stylePresets = [
  { id: 'modern', name: 'Moderno', colors: ['bg-slate-900', 'bg-blue-500', 'bg-white'] },
  { id: 'minimal', name: 'Minimal', colors: ['bg-white', 'bg-gray-100', 'bg-black'] },
  { id: 'vibrant', name: 'Vibrante', colors: ['bg-purple-600', 'bg-pink-500', 'bg-yellow-400'] },
  { id: 'professional', name: 'Profesional', colors: ['bg-blue-900', 'bg-blue-600', 'bg-slate-100'] },
  { id: 'playful', name: 'Juguetón', colors: ['bg-orange-500', 'bg-green-400', 'bg-purple-500'] },
];

interface DesignResult {
  html: string;
  css: string;
  description: string;
  components: string[];
  colorPalette: string[];
  responsive: boolean;
}

export function MagicDesignFeature() {
  const { isLoading, setIsLoading, profileSettings } = useAppStore();
  const [designType, setDesignType] = useState('landing');
  const [description, setDescription] = useState('');
  const [style, setStyle] = useState('modern');
  const [result, setResult] = useState<DesignResult | null>(null);
  const [copied, setCopied] = useState<'html' | 'css' | null>(null);
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [activeTab, setActiveTab] = useState<'preview' | 'html' | 'css'>('preview');

  const handleGenerate = useCallback(async () => {
    if (!description.trim() || isLoading) return;
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/magic-design', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: designType,
          description,
          style,
          model: profileSettings.aiModel,
        }),
      });

      const data = await response.json();
      if (data.design) {
        setResult(data.design);
        toast.success('¡Diseño generado mágicamente!');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al generar el diseño');
    } finally {
      setIsLoading(false);
    }
  }, [designType, description, style, isLoading, setIsLoading, profileSettings.aiModel]);

  const handleCopy = useCallback(async (type: 'html' | 'css') => {
    if (!result) return;
    const text = type === 'html' ? result.html : result.css;
    await navigator.clipboard.writeText(text);
    setCopied(type);
    toast.success(`${type.toUpperCase()} copiado al portapapeles`);
    setTimeout(() => setCopied(null), 2000);
  }, [result]);

  const handleDownload = useCallback(() => {
    if (!result) return;
    const blob = new Blob([result.html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `magic-design-${designType}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Diseño descargado');
  }, [result, designType]);

  const handleRegenerate = useCallback(async () => {
    if (!description.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/magic-design', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: designType,
          description,
          style,
          model: profileSettings.aiModel,
          regenerate: true,
        }),
      });

      const data = await response.json();
      if (data.design) {
        setResult(data.design);
        toast.success('¡Nuevo diseño generado!');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al regenerar');
    } finally {
      setIsLoading(false);
    }
  }, [designType, description, style, isLoading, setIsLoading, profileSettings.aiModel]);

  const previewWidth = {
    desktop: 'w-full',
    tablet: 'w-[768px] max-w-full',
    mobile: 'w-[375px] max-w-full',
  }[previewDevice];

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center">
            <Wand2 className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              Diseño Mágico
              <Badge className="bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-300">Beta</Badge>
            </h2>
            <p className="text-muted-foreground">Genera diseños automáticamente con IA</p>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Configuration */}
          <div className="space-y-4">
            {/* Design Type */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Layout className="h-5 w-5 text-pink-600" />
                  Tipo de Diseño
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {designTypes.map((type) => (
                    <Button
                      key={type.id}
                      variant={designType === type.id ? 'default' : 'outline'}
                      className={`h-auto py-3 flex flex-col items-center gap-1 ${designType === type.id ? 'bg-pink-600 hover:bg-pink-700' : ''}`}
                      onClick={() => setDesignType(type.id)}
                    >
                      <type.icon className="h-5 w-5" />
                      <span className="text-xs">{type.name}</span>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Description */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-pink-600" />
                  Describe tu Diseño
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe cómo quieres que sea tu diseño... Ej: Una landing page moderna para una app de fitness con colores vibrantes y secciones de características..."
                  className="min-h-24"
                />
              </CardContent>
            </Card>

            {/* Style */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Palette className="h-5 w-5 text-pink-600" />
                  Estilo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {stylePresets.map((preset) => (
                    <Button
                      key={preset.id}
                      variant={style === preset.id ? 'default' : 'outline'}
                      className={`h-auto py-3 ${style === preset.id ? 'bg-pink-600 hover:bg-pink-700' : ''}`}
                      onClick={() => setStyle(preset.id)}
                    >
                      <div className="flex items-center gap-2">
                        <div className="flex -space-x-1">
                          {preset.colors.map((color, i) => (
                            <div key={i} className={`h-4 w-4 rounded-full ${color} border-2 border-white dark:border-gray-800`} />
                          ))}
                        </div>
                        <span className="text-xs">{preset.name}</span>
                      </div>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleGenerate}
              disabled={!description.trim() || isLoading}
              className="w-full bg-gradient-to-r from-pink-600 to-orange-500 hover:from-pink-700 hover:to-orange-600"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generando magia...
                </>
              ) : (
                <>
                  <Wand2 className="mr-2 h-4 w-4" />
                  Generar Diseño Mágico
                </>
              )}
            </Button>
          </div>

          {/* Preview */}
          <Card className="flex flex-col">
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <CardTitle className="text-lg flex items-center gap-2">
                <Eye className="h-5 w-5 text-pink-600" />
                Vista Previa
              </CardTitle>
              {result && (
                <div className="flex items-center gap-2">
                  {/* Device Toggle */}
                  <div className="flex gap-1">
                    <Button
                      variant={previewDevice === 'desktop' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setPreviewDevice('desktop')}
                      className={previewDevice === 'desktop' ? 'bg-pink-600' : ''}
                    >
                      <Monitor className="h-4 w-4" />
                    </Button>
                    <Button
                      variant={previewDevice === 'tablet' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setPreviewDevice('tablet')}
                      className={previewDevice === 'tablet' ? 'bg-pink-600' : ''}
                    >
                      <Tablet className="h-4 w-4" />
                    </Button>
                    <Button
                      variant={previewDevice === 'mobile' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setPreviewDevice('mobile')}
                      className={previewDevice === 'mobile' ? 'bg-pink-600' : ''}
                    >
                      <Smartphone className="h-4 w-4" />
                    </Button>
                  </div>
                  <Button variant="outline" size="sm" onClick={handleRegenerate} disabled={isLoading}>
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleDownload}>
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent className="flex-1">
              {result ? (
                <div className="space-y-4">
                  {/* Tabs */}
                  <div className="flex gap-2 border-b pb-2">
                    {['preview', 'html', 'css'].map((tab) => (
                      <Button
                        key={tab}
                        variant={activeTab === tab ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setActiveTab(tab as typeof activeTab)}
                        className={activeTab === tab ? 'bg-pink-600' : ''}
                      >
                        {tab === 'preview' ? <Eye className="h-4 w-4 mr-1" /> : tab === 'html' ? <Type className="h-4 w-4 mr-1" /> : <Palette className="h-4 w-4 mr-1" />}
                        {tab.toUpperCase()}
                      </Button>
                    ))}
                  </div>

                  {/* Content */}
                  {activeTab === 'preview' && (
                    <div className={`mx-auto ${previewWidth} border rounded-lg overflow-hidden`}>
                      <iframe
                        srcDoc={`<!DOCTYPE html><html><head><script src="https://cdn.tailwindcss.com"></script><style>${result.css}</style></head><body>${result.html}</body></html>`}
                        className="w-full h-[400px] bg-white"
                        title="Design Preview"
                      />
                    </div>
                  )}

                  {activeTab === 'html' && (
                    <div className="relative">
                      <Button
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => handleCopy('html')}
                      >
                        {copied === 'html' ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
                      </Button>
                      <ScrollArea className="h-[350px]">
                        <pre className="text-xs font-mono bg-muted p-4 rounded-lg">{result.html}</pre>
                      </ScrollArea>
                    </div>
                  )}

                  {activeTab === 'css' && (
                    <div className="relative">
                      <Button
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => handleCopy('css')}
                      >
                        {copied === 'css' ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
                      </Button>
                      <ScrollArea className="h-[350px]">
                        <pre className="text-xs font-mono bg-muted p-4 rounded-lg">{result.css}</pre>
                      </ScrollArea>
                    </div>
                  )}

                  {/* Components */}
                  <div className="flex flex-wrap gap-2">
                    {result.components.map((comp, i) => (
                      <Badge key={i} variant="secondary">{comp}</Badge>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="h-[400px] flex items-center justify-center text-center">
                  <div>
                    <Wand2 className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                    <p className="text-muted-foreground">
                      El diseño mágico aparecerá aquí
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
