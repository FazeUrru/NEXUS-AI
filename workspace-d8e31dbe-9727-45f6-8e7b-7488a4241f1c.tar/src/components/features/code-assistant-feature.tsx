'use client';

import { useState } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Terminal, Loader2, Bug, Wrench, Sparkles, FileCode } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface CodeAssistantResult {
  explanation: string;
  code?: string;
  suggestions?: string[];
  fixedCode?: string;
}

export function CodeAssistantFeature() {
  const { isLoading, setIsLoading } = useAppStore();
  const [code, setCode] = useState('');
  const [language, setLanguage] = useState('javascript');
  const [task, setTask] = useState('explain');
  const [result, setResult] = useState<CodeAssistantResult | null>(null);

  const handleAnalyze = async () => {
    if (!code.trim() || isLoading) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/code-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          language,
          task,
        }),
      });

      const data = await response.json();
      if (data.result) {
        setResult(data.result);
      }
    } catch (error) {
      console.error('Error analyzing code:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const taskOptions = [
    { value: 'explain', label: 'Explicar código', icon: Sparkles },
    { value: 'debug', label: 'Depurar', icon: Bug },
    { value: 'optimize', label: 'Optimizar', icon: Wrench },
    { value: 'document', label: 'Documentar', icon: FileCode },
  ];

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5 text-emerald-600" />
              Asistente de Código
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Lenguaje</Label>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <option value="javascript">JavaScript</option>
                  <option value="typescript">TypeScript</option>
                  <option value="python">Python</option>
                  <option value="java">Java</option>
                  <option value="csharp">C#</option>
                  <option value="cpp">C++</option>
                  <option value="go">Go</option>
                  <option value="rust">Rust</option>
                  <option value="php">PHP</option>
                  <option value="ruby">Ruby</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label>Tarea</Label>
                <div className="flex gap-2 flex-wrap">
                  {taskOptions.map((opt) => {
                    const Icon = opt.icon;
                    return (
                      <Badge
                        key={opt.value}
                        variant={task === opt.value ? 'default' : 'outline'}
                        className="cursor-pointer"
                        onClick={() => setTask(opt.value)}
                      >
                        <Icon className="h-3 w-3 mr-1" />
                        {opt.label}
                      </Badge>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Código</Label>
              <Textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Pega tu código aquí..."
                className="font-mono text-sm min-h-48"
              />
            </div>

            <Button
              onClick={handleAnalyze}
              disabled={!code.trim() || isLoading}
              className="w-full bg-emerald-600 hover:bg-emerald-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Procesando...
                </>
              ) : (
                <>
                  <Terminal className="mr-2 h-4 w-4" />
                  Analizar Código
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {result && (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Análisis</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-wrap">{result.explanation}</p>
              </CardContent>
            </Card>

            {result.suggestions && result.suggestions.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Sugerencias</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="list-disc list-inside space-y-2">
                    {result.suggestions.map((suggestion, index) => (
                      <li key={index} className="text-muted-foreground">
                        {suggestion}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            {result.code && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Código Mejorado</CardTitle>
                </CardHeader>
                <CardContent>
                  <SyntaxHighlighter
                    language={language}
                    style={oneDark}
                    customStyle={{
                      margin: 0,
                      borderRadius: '0.5rem',
                      fontSize: '0.875rem',
                    }}
                  >
                    {result.code}
                  </SyntaxHighlighter>
                </CardContent>
              </Card>
            )}

            {result.fixedCode && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Código Corregido</CardTitle>
                </CardHeader>
                <CardContent>
                  <SyntaxHighlighter
                    language={language}
                    style={oneDark}
                    customStyle={{
                      margin: 0,
                      borderRadius: '0.5rem',
                      fontSize: '0.875rem',
                    }}
                  >
                    {result.fixedCode}
                  </SyntaxHighlighter>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
