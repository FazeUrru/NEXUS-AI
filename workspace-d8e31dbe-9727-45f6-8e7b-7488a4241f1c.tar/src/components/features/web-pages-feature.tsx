'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Layout, Loader2, Sparkles, Eye, Code, Download } from 'lucide-react';
import { toast } from 'sonner';

export function WebPagesFeature() {
  const { isLoading, setIsLoading, profileSettings } = useAppStore();
  const [description, setDescription] = useState('');
  const [html, setHtml] = useState('');

  const handleGenerate = useCallback(async () => {
    if (!description.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/web-pages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description, model: profileSettings.aiModel }),
      });
      const data = await response.json();
      if (data.html) {
        setHtml(data.html);
        toast.success('¡Página web generada!');
      }
    } catch (error) {
      toast.error('Error al generar página');
    } finally {
      setIsLoading(false);
    }
  }, [description, isLoading, setIsLoading, profileSettings.aiModel]);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
            <Layout className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Páginas Web</h2>
            <p className="text-muted-foreground">Genera páginas web completas con IA</p>
          </div>
        </div>

        <Card>
          <CardContent className="p-6 space-y-4">
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe la página web que quieres crear..." className="min-h-24" />
            <Button onClick={handleGenerate} disabled={!description.trim() || isLoading} className="w-full bg-cyan-600 hover:bg-cyan-700">
              {isLoading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Generando...</> : <><Sparkles className="mr-2 h-4 w-4" />Generar Página Web</>}
            </Button>
          </CardContent>
        </Card>

        {html && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Eye className="h-5 w-5" />Vista Previa</CardTitle>
            </CardHeader>
            <CardContent>
              <iframe srcDoc={html} className="w-full h-[400px] rounded-lg border" title="Preview" />
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
