'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Gamepad2, Loader2, Sparkles, Play, Code } from 'lucide-react';
import { toast } from 'sonner';

export function GamesFeature() {
  const { isLoading, setIsLoading, profileSettings } = useAppStore();
  const [description, setDescription] = useState('');
  const [result, setResult] = useState<{ html: string; features: string[]; controls: string } | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!description.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/games', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'arcade', name: 'Mi Juego', description, model: profileSettings.aiModel }),
      });
      const data = await response.json();
      if (data.game) {
        setResult(data.game);
        toast.success('¡Juego generado!');
      }
    } catch (error) {
      toast.error('Error al generar juego');
    } finally {
      setIsLoading(false);
    }
  }, [description, isLoading, setIsLoading, profileSettings.aiModel]);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-rose-500 to-pink-600 flex items-center justify-center">
            <Gamepad2 className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Juegos</h2>
            <p className="text-muted-foreground">Crea juegos interactivos con IA</p>
          </div>
        </div>

        <Card>
          <CardContent className="p-6 space-y-4">
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe el juego que quieres crear..." className="min-h-24" />
            <Button onClick={handleGenerate} disabled={!description.trim() || isLoading} className="w-full bg-rose-600 hover:bg-rose-700">
              {isLoading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Generando...</> : <><Sparkles className="mr-2 h-4 w-4" />Generar Juego</>}
            </Button>
          </CardContent>
        </Card>

        {result && (
          <Card>
            <CardHeader><CardTitle>Juego Generado</CardTitle></CardHeader>
            <CardContent>
              <Tabs defaultValue="play">
                <TabsList><TabsTrigger value="play"><Play className="h-4 w-4 mr-1" />Jugar</TabsTrigger><TabsTrigger value="code"><Code className="h-4 w-4 mr-1" />Código</TabsTrigger></TabsList>
                <TabsContent value="play" className="mt-4">
                  <iframe srcDoc={result.html} className="w-full h-[400px] rounded-lg border bg-black" title="Game" />
                  <p className="text-sm text-muted-foreground mt-2">Controles: {result.controls}</p>
                </TabsContent>
                <TabsContent value="code" className="mt-4">
                  <pre className="text-xs font-mono bg-muted p-4 rounded overflow-auto max-h-96">{result.html}</pre>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
