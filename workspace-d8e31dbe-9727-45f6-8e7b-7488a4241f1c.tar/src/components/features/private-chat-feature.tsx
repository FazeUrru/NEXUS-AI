'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { useAppStore, AI_MODELS, Conversation } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Send, Bot, User, Loader2, Trash2, Plus, 
  MessageSquare, Save, ChevronDown, Zap, Archive, 
  ArchiveRestore, Pin, PinOff, Edit2, Copy,
  Lock, Shield, ShieldCheck, MoreHorizontal, Eye, EyeOff, ArrowDown
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

// Simple text formatter
function formatText(text: string): string {
  if (!text) return '';
  let result = text;
  result = result.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  result = result.replace(/\*([^*]+)\*/g, '<em>$1</em>');
  result = result.replace(/`([^`]+)`/g, '<code class="bg-muted px-1 rounded">$1</code>');
  result = result.replace(/\n/g, '<br/>');
  return result;
}

export function PrivateChatFeature() {
  const { 
    messages, addMessage, isLoading, setIsLoading, profileSettings,
    conversations, createNewConversation, saveCurrentConversation,
    loadConversation, deleteConversation, currentConversationId,
    generalSettings, updateProfileSettings,
    archiveConversation, unarchiveConversation,
    pinConversation, unpinConversation,
    editConversationTitle
  } = useAppStore();
  
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [showEncryptionInfo, setShowEncryptionInfo] = useState(true);
  
  // Dialog states
  const [editingConversation, setEditingConversation] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'archived' | 'pinned'>('all');
  
  // Scroll state
  const [showScrollButton, setShowScrollButton] = useState(false);
  const lastMessageCountRef = useRef(0);
  const isUserScrollingRef = useRef(false);

  // Scroll to bottom function
  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  // Handle scroll
  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    const target = e.target as HTMLDivElement;
    const { scrollTop, scrollHeight, clientHeight } = target;
    const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
    isUserScrollingRef.current = !isNearBottom;
    setShowScrollButton(!isNearBottom && messages.length > 3);
  }, [messages.length]);

  // Auto-scroll only for new messages
  useEffect(() => {
    const currentCount = messages.length;
    if (currentCount > lastMessageCountRef.current && currentCount > 0) {
      if (!isUserScrollingRef.current) {
        setTimeout(() => scrollToBottom(), 50);
      }
    }
    lastMessageCountRef.current = currentCount;
  }, [messages, scrollToBottom]);

  // Auto-save conversations
  useEffect(() => {
    if (generalSettings.autoSave && messages.length > 0) {
      const timer = setTimeout(() => {
        saveCurrentConversation();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [messages.length, generalSettings.autoSave, saveCurrentConversation]);

  const handleSend = useCallback(async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    isUserScrollingRef.current = false;
    addMessage({ role: 'user', content: userMessage });
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: userMessage,
          model: profileSettings.aiModel,
          temperature: profileSettings.temperature,
        }),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      
      if (data.response) {
        addMessage({ role: 'assistant', content: data.response });
      } else {
        addMessage({ role: 'assistant', content: 'Lo siento, ha ocurrido un error. Por favor, inténtalo de nuevo.' });
      }
    } catch (error) {
      console.error('Chat error:', error);
      addMessage({ role: 'assistant', content: 'Error de conexión. Por favor, verifica tu conexión a internet.' });
    } finally {
      setIsLoading(false);
    }
  }, [input, isLoading, addMessage, setIsLoading, profileSettings.aiModel, profileSettings.temperature]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  const handleNewChat = useCallback(() => {
    saveCurrentConversation();
    createNewConversation('chat-private');
  }, [saveCurrentConversation, createNewConversation]);

  const handleAction = useCallback((action: string, conv: Conversation, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    
    switch (action) {
      case 'delete':
        deleteConversation(conv.id);
        toast.success('Conversación eliminada');
        break;
      case 'archive':
        archiveConversation(conv.id);
        toast.success('Conversación archivada');
        break;
      case 'unarchive':
        unarchiveConversation(conv.id);
        toast.success('Conversación desarchivada');
        break;
      case 'pin':
        pinConversation(conv.id);
        toast.success('Conversación anclada');
        break;
      case 'unpin':
        unpinConversation(conv.id);
        toast.success('Conversación desanclada');
        break;
      case 'edit':
        setEditingConversation(conv.id);
        setEditTitle(conv.title);
        break;
      case 'copy':
        navigator.clipboard.writeText(conv.messages.map(m => `${m.role}: ${m.content}`).join('\n\n'));
        toast.success('Conversación copiada al portapapeles');
        break;
    }
  }, [deleteConversation, archiveConversation, unarchiveConversation, pinConversation, unpinConversation]);

  const handleSaveTitle = useCallback(() => {
    if (editingConversation && editTitle.trim()) {
      editConversationTitle(editingConversation, editTitle.trim());
      toast.success('Título actualizado');
      setEditingConversation(null);
    }
  }, [editingConversation, editTitle, editConversationTitle]);

  const formatTime = useCallback((timestamp: string) => {
    try {
      return new Date(timestamp).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  }, []);

  const formatDate = useCallback((timestamp: string) => {
    try {
      return new Date(timestamp).toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
    } catch {
      return '';
    }
  }, []);

  const currentModel = AI_MODELS.find(m => m.id === profileSettings.aiModel) || AI_MODELS[0];
  
  // Filter private chat conversations
  const privateConversations = conversations
    .filter(c => c.featureType === 'chat-private')
    .filter(c => {
      if (filter === 'active') return c.status === 'active';
      if (filter === 'archived') return c.status === 'archived';
      if (filter === 'pinned') return c.status === 'pinned';
      return true;
    })
    .sort((a, b) => {
      if (a.status === 'pinned' && b.status !== 'pinned') return -1;
      if (b.status === 'pinned' && a.status !== 'pinned') return 1;
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    })
    .slice(0, 30);

  return (
    <div className="flex h-full">
      {/* Conversations Sidebar */}
      <div className="w-72 border-r bg-card/50 flex-col hidden md:flex">
        <div className="p-3 border-b space-y-2">
          <Button onClick={handleNewChat} className="w-full bg-amber-600 hover:bg-amber-700">
            <Lock className="mr-2 h-4 w-4" />
            Nuevo Chat Privado
          </Button>
          
          <div className="flex gap-1">
            {[
              { key: 'all', label: 'Todas' },
              { key: 'pinned', label: 'Ancladas' },
              { key: 'archived', label: 'Archivadas' },
            ].map(f => (
              <Button
                key={f.key}
                variant={filter === f.key ? 'secondary' : 'ghost'}
                size="sm"
                className="flex-1 text-xs"
                onClick={() => setFilter(f.key as typeof filter)}
              >
                {f.label}
              </Button>
            ))}
          </div>
        </div>
        
        <ScrollArea className="flex-1 p-2">
          <div className="space-y-1">
            <div className="flex items-center gap-2 px-2 py-1">
              <p className="text-xs font-medium text-muted-foreground">Historial Privado ({privateConversations.length})</p>
              <Lock className="h-3 w-3 text-amber-500" />
            </div>
            {privateConversations.length === 0 ? (
              <p className="text-xs text-muted-foreground px-2 py-4 text-center">No hay conversaciones privadas</p>
            ) : (
              privateConversations.map((conv) => (
                <div key={conv.id} className="group">
                  <div
                    className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-colors ${
                      currentConversationId === conv.id ? 'bg-amber-100 dark:bg-amber-900/30' : 'hover:bg-muted'
                    }`}
                    onClick={() => loadConversation(conv.id)}
                  >
                    <Lock className="h-4 w-4 shrink-0 text-amber-500" />
                    <div className="flex-1 min-w-0">
                      <p className="truncate text-xs font-medium">{conv.title}</p>
                      <p className="text-[10px] text-muted-foreground">{formatDate(conv.updatedAt)} • {conv.messages.length} msgs</p>
                    </div>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0 opacity-0 group-hover:opacity-100">
                          <MoreHorizontal className="h-3 w-3" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuItem onClick={(e) => handleAction('edit', conv, e)}><Edit2 className="h-4 w-4 mr-2" />Editar título</DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => handleAction('copy', conv, e)}><Copy className="h-4 w-4 mr-2" />Copiar conversación</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        {conv.status === 'pinned' ? (
                          <DropdownMenuItem onClick={(e) => handleAction('unpin', conv, e)}><PinOff className="h-4 w-4 mr-2" />Desanclar</DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem onClick={(e) => handleAction('pin', conv, e)}><Pin className="h-4 w-4 mr-2" />Anclar</DropdownMenuItem>
                        )}
                        {conv.status === 'archived' ? (
                          <DropdownMenuItem onClick={(e) => handleAction('unarchive', conv, e)}><ArchiveRestore className="h-4 w-4 mr-2" />Desarchivar</DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem onClick={(e) => handleAction('archive', conv, e)}><Archive className="h-4 w-4 mr-2" />Archivar</DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={(e) => handleAction('delete', conv, e)} className="text-red-600"><Trash2 className="h-4 w-4 mr-2" />Eliminar</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full">
        {/* Private Chat Header */}
        <div className="border-b px-4 py-2 flex items-center justify-between bg-gradient-to-r from-amber-50 to-amber-100/50 dark:from-amber-950/20 dark:to-amber-900/10 shrink-0">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500">
              <Lock className="h-4 w-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-medium">Chat Privado</span>
                <Badge variant="outline" className="text-amber-600 border-amber-300">
                  <ShieldCheck className="h-3 w-3 mr-1" />Cifrado E2E
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground">Conversación cifrada de extremo a extremo</p>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="ml-4 gap-1">
                  <Zap className="h-3 w-3" />
                  <span className="hidden sm:inline">{currentModel.name}</span>
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-64">
                {AI_MODELS.map((model) => (
                  <DropdownMenuItem key={model.id} onClick={() => updateProfileSettings({ aiModel: model.id })}>
                    <div className="flex-1">
                      <div className="font-medium">{model.name}</div>
                      <div className="text-xs text-muted-foreground">{model.provider}</div>
                    </div>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={handleNewChat}><Plus className="h-4 w-4 mr-1" />Nuevo</Button>
            <Button variant="ghost" size="sm" onClick={saveCurrentConversation}><Save className="h-4 w-4 mr-1" />Guardar</Button>
          </div>
        </div>

        {/* Encryption Notice */}
        {showEncryptionInfo && (
          <div className="px-4 py-2 bg-amber-50 dark:bg-amber-950/30 border-b flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-amber-700 dark:text-amber-300">
              <Shield className="h-4 w-4" />
              <span>Los mensajes están cifrados y solo tú puedes verlos</span>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setShowEncryptionInfo(false)} className="text-amber-600">
              <EyeOff className="h-4 w-4" />
            </Button>
          </div>
        )}

        {/* Chat Messages */}
        <div className="flex-1 relative overflow-hidden">
          <ScrollArea ref={scrollRef} className="flex-1 h-full p-4" onScroll={handleScroll}>
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center px-4 min-h-[400px]">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center mb-6">
                  <Lock className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-3">Chat Privado Seguro</h3>
                <p className="text-muted-foreground max-w-lg mb-6">
                  Esta conversación está cifrada de extremo a extremo. Tus mensajes privados nunca son compartidos ni almacenados en texto plano.
                </p>
                <div className="grid grid-cols-3 gap-4 max-w-lg">
                  {[
                    { icon: Lock, label: 'Cifrado E2E' },
                    { icon: Shield, label: 'Sin rastros' },
                    { icon: Eye, label: 'Solo tú' },
                  ].map((item) => (
                    <div key={item.label} className="flex flex-col items-center gap-2 p-4 rounded-lg bg-amber-50 dark:bg-amber-900/20">
                      <item.icon className="h-6 w-6 text-amber-600" />
                      <span className="text-sm font-medium">{item.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4 max-w-4xl mx-auto pb-4">
                {messages.map((message) => (
                  <div key={message.id} className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    {message.role === 'assistant' && (
                      <Avatar className="h-8 w-8 shrink-0">
                        <AvatarFallback className="bg-gradient-to-br from-amber-500 to-orange-600 text-white">
                          <Bot className="h-4 w-4" />
                        </AvatarFallback>
                      </Avatar>
                    )}
                    <div className={`max-w-[85%] ${message.role === 'user' ? 'order-first' : ''}`}>
                      <Card className={`p-4 relative ${message.role === 'user' ? 'bg-amber-600 text-white' : 'bg-muted'}`}>
                        {message.role === 'assistant' ? (
                          <div dangerouslySetInnerHTML={{ __html: formatText(message.content) }} />
                        ) : (
                          <p className="whitespace-pre-wrap">{message.content}</p>
                        )}
                        <Lock className="h-3 w-3 absolute top-2 right-2 opacity-50" />
                      </Card>
                      <p className="text-xs text-muted-foreground mt-1 px-1 flex items-center gap-1">
                        {formatTime(message.timestamp)}
                        <Lock className="h-2.5 w-2.5 text-amber-500" />
                      </p>
                    </div>
                    {message.role === 'user' && (
                      <Avatar className="h-8 w-8 shrink-0">
                        <AvatarFallback className="bg-amber-600">
                          <User className="h-4 w-4" />
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex gap-3 justify-start">
                    <Avatar className="h-8 w-8 shrink-0">
                      <AvatarFallback className="bg-gradient-to-br from-amber-500 to-orange-600 text-white">
                        <Bot className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                    <Card className="bg-muted p-4">
                      <div className="flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin text-amber-600" />
                        <span className="text-muted-foreground">Procesando de forma segura...</span>
                      </div>
                    </Card>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </ScrollArea>
          
          {showScrollButton && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10">
              <Button variant="secondary" size="sm" onClick={scrollToBottom} className="rounded-full shadow-lg bg-amber-600 hover:bg-amber-700 text-white">
                <ArrowDown className="h-4 w-4 mr-1" />Ir abajo
              </Button>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="border-t p-4 bg-gradient-to-r from-amber-50/50 to-orange-50/50 dark:from-amber-950/10 dark:to-orange-950/10 shrink-0">
          <div className="flex gap-2 max-w-4xl mx-auto">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Mensaje cifrado... Escribe con privacidad"
              className="min-h-[44px] max-h-32 resize-none border-amber-200 focus:border-amber-400"
              rows={1}
              disabled={isLoading}
            />
            <Button onClick={handleSend} disabled={!input.trim() || isLoading} className="bg-amber-600 hover:bg-amber-700 shrink-0 px-4">
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground text-center mt-2 flex items-center justify-center gap-1">
            <Lock className="h-3 w-3 text-amber-500" />
            Mensajes cifrados de extremo a extremo • {currentModel.name}
          </p>
        </div>
      </div>
      
      {/* Edit Title Dialog */}
      <Dialog open={!!editingConversation} onOpenChange={() => setEditingConversation(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar título</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} placeholder="Nuevo título..." onKeyDown={(e) => e.key === 'Enter' && handleSaveTitle()} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingConversation(null)}>Cancelar</Button>
            <Button onClick={handleSaveTitle} className="bg-amber-600 hover:bg-amber-700">Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
