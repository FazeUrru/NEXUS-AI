'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Globe, Loader2, Search, ExternalLink, Clock, 
  TrendingUp, ArrowRight
} from 'lucide-react';
import { toast } from 'sonner';

interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  published?: string;
}

export function WebSearchFeature() {
  const { isLoading, setIsLoading } = useAppStore();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = useCallback(async () => {
    if (!query.trim() || isLoading) return;
    
    setIsLoading(true);
    setHasSearched(true);
    
    try {
      const response = await fetch('/api/ai/web-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });

      const data = await response.json();
      
      if (data.results) {
        setResults(data.results);
        if (data.fallback) {
          toast.info('Mostrando resultados de respaldo');
        }
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error en la búsqueda');
    } finally {
      setIsLoading(false);
    }
  }, [query, isLoading, setIsLoading]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="h-full overflow-hidden flex flex-col">
      {/* Search Header */}
      <div className="border-b p-6 shrink-0 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center gap-2 mb-4">
            <Globe className="h-6 w-6 text-blue-600" />
            <h1 className="text-2xl font-bold">Búsqueda Web</h1>
            <Badge className="bg-blue-600">Live</Badge>
          </div>
          
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Buscar en la web en tiempo real..."
                className="pl-10 h-12 text-lg"
              />
            </div>
            <Button
              onClick={handleSearch}
              disabled={!query.trim() || isLoading}
              className="h-12 px-6 bg-blue-600 hover:bg-blue-700"
            >
              {isLoading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <>
                  <Search className="h-5 w-5 mr-2" />
                  Buscar
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Results */}
      <ScrollArea className="flex-1">
        <div className="max-w-3xl mx-auto p-6">
          {!hasSearched ? (
            <div className="text-center py-16">
              <Globe className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h2 className="text-xl font-semibold mb-2">Búsqueda Web en Tiempo Real</h2>
              <p className="text-muted-foreground max-w-md mb-6">
                Busca información actualizada de internet y obtén resultados relevantes al instante.
              </p>
              
              <div className="space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground">Búsquedas populares:</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {[
                    'Últimas noticias tecnología 2026',
                    'Precio bitcoin hoy',
                    'Resultados fútbol última jornada',
                    'Mejores restaurantes cerca de mí',
                  ].map((suggestion) => (
                    <Button
                      key={suggestion}
                      variant="outline"
                      className="h-auto py-3 justify-start text-left"
                      onClick={() => setQuery(suggestion)}
                    >
                      <TrendingUp className="h-4 w-4 mr-2 shrink-0 text-blue-600" />
                      <span className="truncate">{suggestion}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          ) : results.length === 0 && !isLoading ? (
            <div className="text-center py-16">
              <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No se encontraron resultados para "{query}"</p>
              <Button variant="outline" className="mt-4" onClick={() => setHasSearched(false)}>
                Nueva búsqueda
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                {results.length} resultados para "{query}"
              </p>
              
              {results.map((result) => (
                <Card key={result.url} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <a
                      href={result.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block"
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center shrink-0">
                          <Globe className="h-4 w-4 text-blue-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-sm text-blue-600 truncate">
                              {new URL(result.url).hostname}
                            </span>
                            {result.published && (
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {result.published}
                              </span>
                            )}
                          </div>
                          <h3 className="font-medium text-emerald-600 hover:underline flex items-center gap-1">
                            {result.title}
                            <ExternalLink className="h-3 w-3" />
                          </h3>
                          <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                            {result.snippet}
                          </p>
                        </div>
                      </div>
                    </a>
                  </CardContent>
                </Card>
              ))}

              {/* Actions */}
              <div className="flex justify-center pt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setHasSearched(false);
                    setResults([]);
                  }}
                >
                  <ArrowRight className="h-4 w-4 mr-2 rotate-180" />
                  Nueva búsqueda
                </Button>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
