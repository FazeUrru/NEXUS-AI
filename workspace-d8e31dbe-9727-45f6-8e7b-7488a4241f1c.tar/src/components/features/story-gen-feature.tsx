'use client';

import { useState } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { BookOpen, Loader2, Copy } from 'lucide-react';

export function StoryGenFeature() {
  const { isLoading, setIsLoading } = useAppStore();
  const [premise, setPremise] = useState('');
  const [genre, setGenre] = useState('fantasy');
  const [style, setStyle] = useState('narrative');
  const [length, setLength] = useState('medium');
  const [characters, setCharacters] = useState('');
  const [story, setStory] = useState('');

  const handleGenerate = async () => {
    if (!premise.trim() || isLoading) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/story', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          premise,
          genre,
          style,
          length,
          characters,
        }),
      });

      const data = await response.json();
      if (data.story) {
        setStory(data.story);
      }
    } catch (error) {
      console.error('Error generating story:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(story);
  };

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-emerald-600" />
              Generador de Historias
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Premisa o idea principal</Label>
              <Textarea
                value={premise}
                onChange={(e) => setPremise(e.target.value)}
                placeholder="Describe la idea de tu historia..."
                className="min-h-24"
              />
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Género</Label>
                <Select value={genre} onValueChange={setGenre}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fantasy">Fantasía</SelectItem>
                    <SelectItem value="scifi">Ciencia Ficción</SelectItem>
                    <SelectItem value="romance">Romance</SelectItem>
                    <SelectItem value="mystery">Misterio</SelectItem>
                    <SelectItem value="horror">Terror</SelectItem>
                    <SelectItem value="adventure">Aventura</SelectItem>
                    <SelectItem value="drama">Drama</SelectItem>
                    <SelectItem value="comedy">Comedia</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Estilo narrativo</Label>
                <Select value={style} onValueChange={setStyle}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="narrative">Narrativo</SelectItem>
                    <SelectItem value="first-person">Primera persona</SelectItem>
                    <SelectItem value="descriptive">Descriptivo</SelectItem>
                    <SelectItem value="dialogue">Basado en diálogos</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Longitud</Label>
                <Select value={length} onValueChange={setLength}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="short">Corto (500 palabras)</SelectItem>
                    <SelectItem value="medium">Medio (1000 palabras)</SelectItem>
                    <SelectItem value="long">Largo (2000 palabras)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Personajes (opcional)</Label>
                <Input
                  value={characters}
                  onChange={(e) => setCharacters(e.target.value)}
                  placeholder="Describe los personajes principales..."
                />
              </div>
            </div>

            <Button
              onClick={handleGenerate}
              disabled={!premise.trim() || isLoading}
              className="w-full bg-emerald-600 hover:bg-emerald-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creando historia...
                </>
              ) : (
                <>
                  <BookOpen className="mr-2 h-4 w-4" />
                  Generar Historia
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {story && (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Historia Generada</CardTitle>
              <Button variant="outline" size="sm" onClick={handleCopy}>
                <Copy className="mr-2 h-4 w-4" />
                Copiar
              </Button>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <p className="whitespace-pre-wrap">{story}</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
