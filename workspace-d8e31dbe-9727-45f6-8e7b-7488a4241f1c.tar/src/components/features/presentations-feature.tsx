'use client';

import { useState, useCallback } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Presentation, Loader2, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

export function PresentationsFeature() {
  const { isLoading, setIsLoading, profileSettings } = useAppStore();
  const [topic, setTopic] = useState('');
  const [slides, setSlides] = useState<Array<{ title: string; content: string }>>([]);

  const handleGenerate = useCallback(async () => {
    if (!topic.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/presentations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, style: 'professional', model: profileSettings.aiModel }),
      });
      const data = await response.json();
      if (data.slides) {
        setSlides(data.slides);
        toast.success(`¡${data.slides.length} diapositivas generadas!`);
      }
    } catch (error) {
      toast.error('Error al generar presentación');
    } finally {
      setIsLoading(false);
    }
  }, [topic, isLoading, setIsLoading, profileSettings.aiModel]);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
            <Presentation className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Presentaciones IA</h2>
            <p className="text-muted-foreground">Crea presentaciones completas automáticamente</p>
          </div>
        </div>

        <Card>
          <CardContent className="p-6 space-y-4">
            <Textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Describe el tema de tu presentación..."
              className="min-h-24"
            />
            <Button onClick={handleGenerate} disabled={!topic.trim() || isLoading} className="w-full bg-amber-600 hover:bg-amber-700">
              {isLoading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Generando...</> : <><Sparkles className="mr-2 h-4 w-4" />Generar Presentación</>}
            </Button>
          </CardContent>
        </Card>

        {slides.length > 0 && (
          <div className="grid gap-4">
            {slides.map((slide, i) => (
              <Card key={i}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <span className="h-6 w-6 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300 flex items-center justify-center text-sm">{i + 1}</span>
                    {slide.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{slide.content}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
