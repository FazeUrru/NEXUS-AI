'use client';

import { useState } from 'react';
import { useAppStore } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { FileMinus, Loader2 } from 'lucide-react';

export function SummarizeFeature() {
  const { isLoading, setIsLoading } = useAppStore();
  const [text, setText] = useState('');
  const [length, setLength] = useState('medium');
  const [summary, setSummary] = useState('');

  const handleSummarize = async () => {
    if (!text.trim() || isLoading) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, length }),
      });

      const data = await response.json();
      if (data.summary) {
        setSummary(data.summary);
      }
    } catch (error) {
      console.error('Error summarizing:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileMinus className="h-5 w-5 text-emerald-600" />
              Resumir Texto
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Texto a resumir</Label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Pega el texto que deseas resumir..."
                className="min-h-48"
              />
            </div>

            <div className="space-y-2">
              <Label>Longitud del resumen</Label>
              <Select value={length} onValueChange={setLength}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="short">Corto (1-2 oraciones)</SelectItem>
                  <SelectItem value="medium">Medio (1 párrafo)</SelectItem>
                  <SelectItem value="long">Largo (2-3 párrafos)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button
              onClick={handleSummarize}
              disabled={!text.trim() || isLoading}
              className="w-full bg-emerald-600 hover:bg-emerald-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Resumiendo...
                </>
              ) : (
                <>
                  <FileMinus className="mr-2 h-4 w-4" />
                  Generar Resumen
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {summary && (
          <Card>
            <CardHeader>
              <CardTitle>Resumen</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="whitespace-pre-wrap">{summary}</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
