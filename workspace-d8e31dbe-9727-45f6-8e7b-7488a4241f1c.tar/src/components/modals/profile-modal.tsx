'use client';

import { useAppStore, ProfileSettings, AI_MODELS, MemorySettings } from '@/store';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import {
  User,
  Mail,
  MapPin,
  Globe,
  Phone,
  Twitter,
  Linkedin,
  Github,
  Brain,
  Sliders,
  Cpu,
  Crown,
  BarChart,
  Shield,
  Smartphone,
  Eye,
  Bell,
  Trash2,
  Clock,
  Volume2,
  Sparkles,
  Zap,
  Database,
  MemoryStick,
  History,
  RefreshCw,
} from 'lucide-react';

interface ProfileFieldProps {
  icon: React.ElementType;
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
}

function ProfileField({ icon: Icon, label, value, onChange, placeholder, type = 'text' }: ProfileFieldProps) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-muted">
        <Icon className="h-5 w-5 text-muted-foreground" />
      </div>
      <div className="flex-1 space-y-1">
        <Label className="text-xs text-muted-foreground">{label}</Label>
        <Input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="h-9"
        />
      </div>
    </div>
  );
}

interface SettingToggleProps {
  icon: React.ElementType;
  label: string;
  description: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}

function SettingToggle({ icon: Icon, label, description, checked, onChange }: SettingToggleProps) {
  return (
    <div className="flex items-start justify-between gap-4 rounded-lg border p-4">
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-muted p-2">
          <Icon className="h-5 w-5 text-muted-foreground" />
        </div>
        <div>
          <Label className="font-medium">{label}</Label>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}

// Group models by provider
const groupedModels = AI_MODELS.reduce((acc, model) => {
  if (!acc[model.provider]) {
    acc[model.provider] = [];
  }
  acc[model.provider].push(model);
  return acc;
}, {} as Record<string, Array<{ id: string; name: string; provider: string; description: string }>>);

export function ProfileModal() {
  const { profileOpen, setProfileOpen, profileSettings, updateProfileSettings, memorySettings, updateMemorySettings } = useAppStore();

  const handleFieldChange = (key: keyof ProfileSettings) => (value: string) => {
    updateProfileSettings({ [key]: value });
  };

  const handleToggle = (key: keyof ProfileSettings) => (checked: boolean) => {
    updateProfileSettings({ [key]: checked });
  };

  const handleMemoryToggle = (key: keyof MemorySettings) => (checked: boolean) => {
    updateMemorySettings({ [key]: checked });
  };

  const usagePercentage = Math.min((profileSettings.usedTokens / profileSettings.monthlyLimit) * 100, 100);
  const memoryUsagePercentage = Math.min((memorySettings.maxMemorySize / 500) * 100, 100);
  
  const currentModel = AI_MODELS.find(m => m.id === profileSettings.aiModel);

  return (
    <Dialog open={profileOpen} onOpenChange={setProfileOpen}>
      <DialogContent className="max-w-3xl max-h-[90vh] p-0">
        <DialogHeader className="border-b p-6">
          <DialogTitle className="text-xl">Perfil y Cuenta</DialogTitle>
        </DialogHeader>
        <ScrollArea className="h-[70vh]">
          <div className="p-6">
            <Tabs defaultValue="ai" className="space-y-6">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="ai">Modelo IA</TabsTrigger>
                <TabsTrigger value="memory">Memoria</TabsTrigger>
                <TabsTrigger value="personal">Personal</TabsTrigger>
                <TabsTrigger value="subscription">Suscripción</TabsTrigger>
                <TabsTrigger value="security">Seguridad</TabsTrigger>
              </TabsList>

              {/* AI Settings Tab - Now First */}
              <TabsContent value="ai" className="space-y-6">
                {/* Current Model Display */}
                <div className="rounded-xl border-2 border-emerald-500/30 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20 p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="h-14 w-14 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg">
                        <Sparkles className="h-7 w-7 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold">{currentModel?.name || 'GPT-5.4'}</h3>
                        <p className="text-sm text-muted-foreground">{currentModel?.provider || 'OpenAI'} • {currentModel?.description}</p>
                      </div>
                    </div>
                    <Badge className="bg-emerald-600 text-white">Activo</Badge>
                  </div>
                </div>

                {/* Model Selection */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-emerald-600" />
                    <h4 className="font-semibold">Seleccionar Modelo de IA</h4>
                  </div>
                  
                  <div className="space-y-4">
                    {Object.entries(groupedModels).map(([provider, models]) => (
                      <div key={provider} className="space-y-2">
                        <h5 className="text-sm font-medium text-muted-foreground">{provider}</h5>
                        <div className="grid gap-2 md:grid-cols-2">
                          {models.map((model) => (
                            <button
                              key={model.id}
                              onClick={() => updateProfileSettings({ aiModel: model.id })}
                              className={`flex items-center gap-3 p-4 rounded-lg border-2 text-left transition-all ${
                                profileSettings.aiModel === model.id
                                  ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30'
                                  : 'border-border hover:border-emerald-300 dark:hover:border-emerald-700'
                              }`}
                            >
                              <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${
                                profileSettings.aiModel === model.id
                                  ? 'bg-emerald-500 text-white'
                                  : 'bg-muted'
                              }`}>
                                <Zap className="h-5 w-5" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="font-medium">{model.name}</div>
                                <div className="text-xs text-muted-foreground truncate">{model.description}</div>
                              </div>
                              {profileSettings.aiModel === model.id && (
                                <div className="h-5 w-5 rounded-full bg-emerald-500 flex items-center justify-center">
                                  <svg className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                  </svg>
                                </div>
                              )}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Response Settings */}
                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className="rounded-lg bg-muted p-2">
                      <Sliders className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <Label className="font-medium">Estilo de Respuesta</Label>
                      <p className="text-sm text-muted-foreground">Cómo debe responder la IA</p>
                    </div>
                  </div>
                  <Select
                    value={profileSettings.responseStyle}
                    onValueChange={(v) => updateProfileSettings({ responseStyle: v })}
                  >
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="concise">Conciso</SelectItem>
                      <SelectItem value="balanced">Equilibrado</SelectItem>
                      <SelectItem value="detailed">Detallado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-4 rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className="rounded-lg bg-muted p-2">
                      <Cpu className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <Label className="font-medium">Nivel de Creatividad</Label>
                      <p className="text-sm text-muted-foreground">{profileSettings.creativityLevel}% - Controla la aleatoriedad</p>
                    </div>
                  </div>
                  <Slider
                    value={[profileSettings.creativityLevel]}
                    onValueChange={(v) => updateProfileSettings({ creativityLevel: v[0] })}
                    max={100}
                    step={5}
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Preciso</span>
                    <span>Creativo</span>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2 rounded-lg border p-4">
                    <Label className="font-medium">Máximo de Tokens</Label>
                    <Input
                      type="number"
                      value={profileSettings.maxTokens}
                      onChange={(e) => updateProfileSettings({ maxTokens: parseInt(e.target.value) || 4000 })}
                    />
                    <p className="text-xs text-muted-foreground">Longitud máxima de respuesta</p>
                  </div>

                  <div className="space-y-2 rounded-lg border p-4">
                    <Label className="font-medium">Temperatura</Label>
                    <Input
                      type="number"
                      step="0.1"
                      min="0"
                      max="2"
                      value={profileSettings.temperature}
                      onChange={(e) => updateProfileSettings({ temperature: parseFloat(e.target.value) || 0.7 })}
                    />
                    <p className="text-xs text-muted-foreground">Precisión vs. Creatividad</p>
                  </div>
                </div>

                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className="rounded-lg bg-muted p-2">
                      <Volume2 className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <Label className="font-medium">Voz Preferida</Label>
                      <p className="text-sm text-muted-foreground">Voz para respuestas de audio</p>
                    </div>
                  </div>
                  <Select
                    value={profileSettings.preferredVoice}
                    onValueChange={(v) => updateProfileSettings({ preferredVoice: v })}
                  >
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="default">Por defecto</SelectItem>
                      <SelectItem value="alloy">Alloy</SelectItem>
                      <SelectItem value="echo">Echo</SelectItem>
                      <SelectItem value="fable">Fable</SelectItem>
                      <SelectItem value="onyx">Onyx</SelectItem>
                      <SelectItem value="nova">Nova</SelectItem>
                      <SelectItem value="shimmer">Shimmer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Separator />

                <h4 className="font-medium flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-emerald-600" />
                  v6.0 - Formato de Respuesta
                </h4>

                <SettingToggle
                  icon={Globe}
                  label="Detección Automática de Idioma"
                  description="Detecta automáticamente el idioma de entrada"
                  checked={profileSettings.autoLanguageDetect ?? true}
                  onChange={handleToggle('autoLanguageDetect')}
                />

                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className="rounded-lg bg-muted p-2">
                      <Cpu className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <Label className="font-medium">Tema de Código</Label>
                      <p className="text-sm text-muted-foreground">Estilo de resaltado de sintaxis</p>
                    </div>
                  </div>
                  <Select
                    value={profileSettings.codeTheme || 'github-dark'}
                    onValueChange={(v) => updateProfileSettings({ codeTheme: v })}
                  >
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="github-dark">GitHub Dark</SelectItem>
                      <SelectItem value="github-light">GitHub Light</SelectItem>
                      <SelectItem value="monokai">Monokai</SelectItem>
                      <SelectItem value="dracula">Dracula</SelectItem>
                      <SelectItem value="one-dark">One Dark</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className="rounded-lg bg-muted p-2">
                      <Zap className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <Label className="font-medium">Formato de Mensaje</Label>
                      <p className="text-sm text-muted-foreground">Estilo de formato de respuestas</p>
                    </div>
                  </div>
                  <Select
                    value={profileSettings.messageFormat || 'rich'}
                    onValueChange={(v) => updateProfileSettings({ messageFormat: v })}
                  >
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rich">Enriquecido</SelectItem>
                      <SelectItem value="plain">Plano</SelectItem>
                      <SelectItem value="markdown">Markdown</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <SettingToggle
                    icon={Clock}
                    label="Mostrar Marcas de Tiempo"
                    description="Muestra hora en cada mensaje"
                    checked={profileSettings.showTimestamps ?? true}
                    onChange={handleToggle('showTimestamps')}
                  />

                  <SettingToggle
                    icon={Brain}
                    label="Habilitar Markdown"
                    description="Renderiza formato Markdown"
                    checked={profileSettings.enableMarkdown ?? true}
                    onChange={handleToggle('enableMarkdown')}
                  />

                  <SettingToggle
                    icon={Sparkles}
                    label="Habilitar LaTeX"
                    description="Renderiza ecuaciones matemáticas"
                    checked={profileSettings.enableLatex ?? true}
                    onChange={handleToggle('enableLatex')}
                  />
                </div>

                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className="rounded-lg bg-muted p-2">
                      <Sliders className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <Label className="font-medium">Longitud de Respuesta</Label>
                      <p className="text-sm text-muted-foreground">Preferencia de longitud de respuesta</p>
                    </div>
                  </div>
                  <Select
                    value={profileSettings.responseLength || 'auto'}
                    onValueChange={(v) => updateProfileSettings({ responseLength: v })}
                  >
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Automático</SelectItem>
                      <SelectItem value="short">Corta</SelectItem>
                      <SelectItem value="medium">Mediana</SelectItem>
                      <SelectItem value="long">Larga</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </TabsContent>

              {/* Memory Settings Tab */}
              <TabsContent value="memory" className="space-y-6">
                {/* Memory Overview */}
                <div className="rounded-xl border-2 border-purple-500/30 bg-gradient-to-br from-purple-50 to-violet-50 dark:from-purple-950/20 dark:to-violet-950/20 p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="h-14 w-14 rounded-xl bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center shadow-lg">
                        <MemoryStick className="h-7 w-7 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold">Memoria de IA</h3>
                        <p className="text-sm text-muted-foreground">Controla cómo la IA recuerda información</p>
                      </div>
                    </div>
                    <Badge className={memorySettings.enabled ? "bg-purple-600 text-white" : "bg-slate-400"}>
                      {memorySettings.enabled ? 'Activa' : 'Inactiva'}
                    </Badge>
                  </div>
                </div>

                {/* Main Memory Toggle */}
                <SettingToggle
                  icon={MemoryStick}
                  label="Memoria de IA"
                  description="Permite que la IA recuerde información entre sesiones"
                  checked={memorySettings.enabled}
                  onChange={handleMemoryToggle('enabled')}
                />

                <Separator />

                {/* Memory Settings */}
                <div className="space-y-4">
                  <h4 className="font-medium flex items-center gap-2">
                    <Database className="h-4 w-4 text-purple-600" />
                    Configuración de Memoria
                  </h4>

                  <div className="space-y-4 rounded-lg border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="font-medium">Tamaño Máximo de Memoria</Label>
                        <p className="text-sm text-muted-foreground">{memorySettings.maxMemorySize} MB asignados</p>
                      </div>
                      <div className="w-32">
                        <Progress value={memoryUsagePercentage} className="h-2" />
                      </div>
                    </div>
                    <Slider
                      value={[memorySettings.maxMemorySize]}
                      onValueChange={(v) => updateMemorySettings({ maxMemorySize: v[0] })}
                      max={500}
                      step={10}
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>10 MB</span>
                      <span>500 MB</span>
                    </div>
                  </div>

                  <SettingToggle
                    icon={History}
                    label="Recordar Contexto"
                    description="La IA recuerda el contexto de conversaciones anteriores"
                    checked={memorySettings.rememberContext}
                    onChange={handleMemoryToggle('rememberContext')}
                  />

                  <SettingToggle
                    icon={Brain}
                    label="Preferencias de Usuario"
                    description="La IA recuerda tus preferencias y estilo"
                    checked={memorySettings.rememberUserPreferences}
                    onChange={handleMemoryToggle('rememberUserPreferences')}
                  />

                  <SettingToggle
                    icon={RefreshCw}
                    label="Memoria entre Sesiones"
                    description="Mantener memoria al cerrar y abrir la aplicación"
                    checked={memorySettings.crossSessionMemory}
                    onChange={handleMemoryToggle('crossSessionMemory')}
                  />
                </div>

                <Separator />

                {/* Auto-forget Settings */}
                <div className="space-y-4">
                  <h4 className="font-medium flex items-center gap-2">
                    <Clock className="h-4 w-4 text-purple-600" />
                    Olvido Automático
                  </h4>

                  <SettingToggle
                    icon={Trash2}
                    label="Olvido Automático"
                    description="Borrar automáticamente memorias antiguas"
                    checked={memorySettings.autoForget}
                    onChange={handleMemoryToggle('autoForget')}
                  />

                  {memorySettings.autoForget && (
                    <div className="rounded-lg border p-4 space-y-3">
                      <Label className="font-medium">Borrar después de</Label>
                      <Select
                        value={memorySettings.forgetAfterDays.toString()}
                        onValueChange={(v) => updateMemorySettings({ forgetAfterDays: parseInt(v) })}
                      >
                        <SelectTrigger className="w-40">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="7">7 días</SelectItem>
                          <SelectItem value="14">14 días</SelectItem>
                          <SelectItem value="30">30 días</SelectItem>
                          <SelectItem value="60">60 días</SelectItem>
                          <SelectItem value="90">90 días</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">
                        Las memorias más antiguas serán eliminadas automáticamente
                      </p>
                    </div>
                  )}
                </div>

                <Separator />

                {/* Memory Actions */}
                <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 dark:border-amber-800 dark:bg-amber-900/20">
                  <h4 className="font-medium text-amber-800 dark:text-amber-200 mb-3">Gestión de Memoria</h4>
                  <div className="flex gap-2 flex-wrap">
                    <Button variant="outline" size="sm">
                      <Database className="h-4 w-4 mr-2" />
                      Exportar Memoria
                    </Button>
                    <Button variant="outline" size="sm">
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Optimizar
                    </Button>
                    <Button variant="destructive" size="sm">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Borrar Todo
                    </Button>
                  </div>
                </div>
              </TabsContent>

              {/* Personal Info Tab */}
              <TabsContent value="personal" className="space-y-6">
                <div className="flex items-center gap-6">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={profileSettings.avatar} />
                    <AvatarFallback className="text-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                      {profileSettings.name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold text-lg">{profileSettings.name}</h3>
                    <p className="text-sm text-muted-foreground">{profileSettings.email}</p>
                    <Button variant="outline" size="sm" className="mt-2">
                      Cambiar Avatar
                    </Button>
                  </div>
                </div>

                <Separator />

                <div className="grid gap-4 md:grid-cols-2">
                  <ProfileField
                    icon={User}
                    label="Nombre"
                    value={profileSettings.name}
                    onChange={handleFieldChange('name')}
                    placeholder="Tu nombre"
                  />
                  <ProfileField
                    icon={Mail}
                    label="Email"
                    value={profileSettings.email}
                    onChange={handleFieldChange('email')}
                    placeholder="tu@email.com"
                    type="email"
                  />
                  <ProfileField
                    icon={MapPin}
                    label="Ubicación"
                    value={profileSettings.location}
                    onChange={handleFieldChange('location')}
                    placeholder="Ciudad, País"
                  />
                  <ProfileField
                    icon={Globe}
                    label="Sitio Web"
                    value={profileSettings.website}
                    onChange={handleFieldChange('website')}
                    placeholder="https://tusitio.com"
                  />
                  <ProfileField
                    icon={Phone}
                    label="Teléfono"
                    value={profileSettings.phone}
                    onChange={handleFieldChange('phone')}
                    placeholder="+34 600 000 000"
                  />
                </div>

                <Separator />

                <div className="space-y-4">
                  <h4 className="font-medium">Biografía</h4>
                  <Textarea
                    value={profileSettings.bio}
                    onChange={(e) => updateProfileSettings({ bio: e.target.value })}
                    placeholder="Cuéntanos sobre ti..."
                    className="min-h-24"
                  />
                </div>

                <Separator />

                <div className="space-y-4">
                  <h4 className="font-medium">Redes Sociales</h4>
                  <div className="grid gap-4 md:grid-cols-3">
                    <ProfileField
                      icon={Twitter}
                      label="Twitter"
                      value={profileSettings.twitter}
                      onChange={handleFieldChange('twitter')}
                      placeholder="@usuario"
                    />
                    <ProfileField
                      icon={Linkedin}
                      label="LinkedIn"
                      value={profileSettings.linkedin}
                      onChange={handleFieldChange('linkedin')}
                      placeholder="linkedin.com/in/usuario"
                    />
                    <ProfileField
                      icon={Github}
                      label="GitHub"
                      value={profileSettings.github}
                      onChange={handleFieldChange('github')}
                      placeholder="github.com/usuario"
                    />
                  </div>
                </div>
              </TabsContent>

              {/* Subscription Tab */}
              <TabsContent value="subscription" className="space-y-6">
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 dark:border-emerald-800 dark:bg-emerald-900/20">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Crown className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
                      <div>
                        <h3 className="font-semibold text-lg">Plan {profileSettings.planType.charAt(0).toUpperCase() + profileSettings.planType.slice(1)}</h3>
                        <p className="text-sm text-muted-foreground">Tu plan actual</p>
                      </div>
                    </div>
                    <Button className="bg-emerald-600 hover:bg-emerald-700">
                      Mejorar Plan
                    </Button>
                  </div>
                </div>

                <div className="space-y-4 rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <BarChart className="h-5 w-5 text-muted-foreground" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <Label className="font-medium">Uso Mensual</Label>
                        <span className="text-sm text-muted-foreground">
                          {profileSettings.usedTokens} / {profileSettings.monthlyLimit} tokens
                        </span>
                      </div>
                      <Progress value={usagePercentage} className="h-2" />
                    </div>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-3">
                  <div className="rounded-lg border p-4 text-center">
                    <h4 className="text-2xl font-bold">{profileSettings.usedTokens}</h4>
                    <p className="text-sm text-muted-foreground">Tokens Usados</p>
                  </div>
                  <div className="rounded-lg border p-4 text-center">
                    <h4 className="text-2xl font-bold">{Math.max(0, profileSettings.monthlyLimit - profileSettings.usedTokens)}</h4>
                    <p className="text-sm text-muted-foreground">Tokens Restantes</p>
                  </div>
                  <div className="rounded-lg border p-4 text-center">
                    <h4 className="text-2xl font-bold">{profileSettings.activeSessions}</h4>
                    <p className="text-sm text-muted-foreground">Sesiones Activas</p>
                  </div>
                </div>

                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <Eye className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <Label className="font-medium">Visibilidad del Perfil</Label>
                      <p className="text-sm text-muted-foreground">Quién puede ver tu perfil</p>
                    </div>
                  </div>
                  <Select
                    value={profileSettings.profileVisibility}
                    onValueChange={(v) => updateProfileSettings({ profileVisibility: v })}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="public">Público</SelectItem>
                      <SelectItem value="private">Privado</SelectItem>
                      <SelectItem value="friends">Amigos</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <Clock className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <Label className="font-medium">Retención de Datos</Label>
                      <p className="text-sm text-muted-foreground">Tiempo de conservación del historial</p>
                    </div>
                  </div>
                  <Select
                    value={profileSettings.dataRetention}
                    onValueChange={(v) => updateProfileSettings({ dataRetention: v })}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7days">7 días</SelectItem>
                      <SelectItem value="30days">30 días</SelectItem>
                      <SelectItem value="90days">90 días</SelectItem>
                      <SelectItem value="forever">Siempre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </TabsContent>

              {/* Security Tab */}
              <TabsContent value="security" className="space-y-6">
                <SettingToggle
                  icon={Shield}
                  label="Autenticación de Dos Factores"
                  description="Añade una capa extra de seguridad"
                  checked={profileSettings.twoFactorEnabled as boolean}
                  onChange={handleToggle('twoFactorEnabled')}
                />

                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <Smartphone className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <Label className="font-medium">Sesiones Activas</Label>
                      <p className="text-sm text-muted-foreground">{profileSettings.activeSessions} dispositivos conectados</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    Gestionar
                  </Button>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h4 className="font-medium">Preferencias de Notificación</h4>
                  
                  <SettingToggle
                    icon={Bell}
                    label="Notificaciones por Email"
                    description="Recibe actualizaciones por correo"
                    checked={profileSettings.emailNotifications as boolean}
                    onChange={handleToggle('emailNotifications')}
                  />

                  <SettingToggle
                    icon={Smartphone}
                    label="Notificaciones Push"
                    description="Recibe notificaciones en tiempo real"
                    checked={profileSettings.pushNotifications as boolean}
                    onChange={handleToggle('pushNotifications')}
                  />

                  <SettingToggle
                    icon={Mail}
                    label="Emails de Marketing"
                    description="Recibe ofertas y novedades"
                    checked={profileSettings.marketingEmails as boolean}
                    onChange={handleToggle('marketingEmails')}
                  />
                </div>

                <Separator />

                <div className="rounded-lg border border-red-200 bg-red-50 p-4 dark:border-red-800 dark:bg-red-900/20">
                  <div className="flex items-start gap-3">
                    <Trash2 className="h-5 w-5 text-red-600 dark:text-red-400" />
                    <div className="flex-1">
                      <h4 className="font-medium text-red-800 dark:text-red-200">Zona de Peligro</h4>
                      <p className="text-sm text-red-700 dark:text-red-300 mb-3">
                        Esta acción eliminará permanentemente tu cuenta y todos tus datos.
                      </p>
                      <Button variant="destructive" size="sm">
                        Eliminar Cuenta
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
