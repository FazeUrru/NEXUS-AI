'use client';

import { useAppStore, GeneralSettings } from '@/store';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Globe,
  Palette,
  Type,
  Bell,
  Volume2,
  Sparkles,
  Save,
  History,
  Shield,
  HardDrive,
  Accessibility,
  Keyboard,
  RefreshCw,
  BarChart3,
  Download,
  Database,
  Timer,
  Minimize2,
  Type as TypeIcon,
  Languages,
} from 'lucide-react';

interface SettingItemProps {
  icon: React.ElementType;
  label: string;
  description: string;
  children: React.ReactNode;
}

function SettingItem({ icon: Icon, label, description, children }: SettingItemProps) {
  return (
    <div className="flex items-start justify-between gap-4 rounded-lg border p-4">
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-muted p-2">
          <Icon className="h-5 w-5 text-muted-foreground" />
        </div>
        <div>
          <Label className="font-medium">{label}</Label>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

export function SettingsModal() {
  const { settingsOpen, setSettingsOpen, generalSettings, updateGeneralSettings } = useAppStore();

  const handleToggle = (key: keyof GeneralSettings) => (checked: boolean) => {
    updateGeneralSettings({ [key]: checked });
  };

  return (
    <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
      <DialogContent className="max-w-3xl max-h-[90vh] p-0">
        <DialogHeader className="border-b p-6">
          <DialogTitle className="text-xl">Ajustes Generales</DialogTitle>
        </DialogHeader>
        <ScrollArea className="h-[70vh]">
          <div className="p-6">
            <Tabs defaultValue="appearance" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="appearance">Apariencia</TabsTrigger>
                <TabsTrigger value="notifications">Notificaciones</TabsTrigger>
                <TabsTrigger value="privacy">Privacidad</TabsTrigger>
                <TabsTrigger value="advanced">Avanzado</TabsTrigger>
              </TabsList>

              {/* Appearance Tab */}
              <TabsContent value="appearance" className="space-y-4">
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg">Apariencia</h3>
                  <SettingItem
                    icon={Globe}
                    label="Idioma"
                    description="Selecciona el idioma de la interfaz"
                  >
                    <Select
                      value={generalSettings.language}
                      onValueChange={(v) => updateGeneralSettings({ language: v })}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="es">Español</SelectItem>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="pt">Português</SelectItem>
                        <SelectItem value="fr">Français</SelectItem>
                      </SelectContent>
                    </Select>
                  </SettingItem>

                  <SettingItem
                    icon={Palette}
                    label="Tema"
                    description="Elige el tema de la aplicación"
                  >
                    <Select
                      value={generalSettings.theme}
                      onValueChange={(v) => updateGeneralSettings({ theme: v })}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">Claro</SelectItem>
                        <SelectItem value="dark">Oscuro</SelectItem>
                        <SelectItem value="system">Sistema</SelectItem>
                      </SelectContent>
                    </Select>
                  </SettingItem>

                  <SettingItem
                    icon={Type}
                    label="Tamaño de Fuente"
                    description="Ajusta el tamaño del texto"
                  >
                    <Select
                      value={generalSettings.fontSize}
                      onValueChange={(v) => updateGeneralSettings({ fontSize: v })}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">Pequeño</SelectItem>
                        <SelectItem value="medium">Mediano</SelectItem>
                        <SelectItem value="large">Grande</SelectItem>
                      </SelectContent>
                    </Select>
                  </SettingItem>

                  <SettingItem
                    icon={Sparkles}
                    label="Animaciones"
                    description="Habilita efectos visuales y animaciones"
                  >
                    <Switch
                      checked={generalSettings.animations}
                      onCheckedChange={handleToggle('animations')}
                    />
                  </SettingItem>

                  <SettingItem
                    icon={Accessibility}
                    label="Accesibilidad"
                    description="Habilita opciones de accesibilidad adicionales"
                  >
                    <Switch
                      checked={generalSettings.accessibility}
                      onCheckedChange={handleToggle('accessibility')}
                    />
                  </SettingItem>
                </div>
              </TabsContent>

              {/* Notifications Tab */}
              <TabsContent value="notifications" className="space-y-4">
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg">Notificaciones</h3>
                  
                  <SettingItem
                    icon={Bell}
                    label="Notificaciones"
                    description="Recibe notificaciones del sistema"
                  >
                    <Switch
                      checked={generalSettings.notifications}
                      onCheckedChange={handleToggle('notifications')}
                    />
                  </SettingItem>

                  <SettingItem
                    icon={Volume2}
                    label="Sonidos"
                    description="Reproduce sonidos en las notificaciones"
                  >
                    <Switch
                      checked={generalSettings.sounds}
                      onCheckedChange={handleToggle('sounds')}
                    />
                  </SettingItem>

                  <Separator />

                  <h3 className="font-semibold text-lg">Datos y Almacenamiento</h3>

                  <SettingItem
                    icon={Save}
                    label="Guardado Automático"
                    description="Guarda automáticamente tus trabajos"
                  >
                    <Switch
                      checked={generalSettings.autoSave}
                      onCheckedChange={handleToggle('autoSave')}
                    />
                  </SettingItem>

                  <SettingItem
                    icon={History}
                    label="Historial"
                    description="Guarda el historial de conversaciones"
                  >
                    <Switch
                      checked={generalSettings.historyEnabled}
                      onCheckedChange={handleToggle('historyEnabled')}
                    />
                  </SettingItem>

                  <SettingItem
                    icon={HardDrive}
                    label="Límite de Almacenamiento"
                    description="Límite máximo de almacenamiento en MB"
                  >
                    <div className="w-32 space-y-2">
                      <Slider
                        value={[generalSettings.storageLimit]}
                        onValueChange={(v) => updateGeneralSettings({ storageLimit: v[0] })}
                        max={5000}
                        step={100}
                      />
                      <span className="text-xs text-muted-foreground">{generalSettings.storageLimit} MB</span>
                    </div>
                  </SettingItem>

                  <SettingItem
                    icon={Download}
                    label="Exportar Datos"
                    description="Prepara tus datos para exportar"
                  >
                    <Button variant="outline" size="sm">
                      Exportar
                    </Button>
                  </SettingItem>
                </div>
              </TabsContent>

              {/* Privacy Tab */}
              <TabsContent value="privacy" className="space-y-4">
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg">Privacidad y Seguridad</h3>
                  
                  <SettingItem
                    icon={Shield}
                    label="Nivel de Privacidad"
                    description="Controla qué datos se comparten"
                  >
                    <Select
                      value={generalSettings.privacy}
                      onValueChange={(v) => updateGeneralSettings({ privacy: v })}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="strict">Estricto</SelectItem>
                        <SelectItem value="standard">Estándar</SelectItem>
                        <SelectItem value="relaxed">Relajado</SelectItem>
                      </SelectContent>
                    </Select>
                  </SettingItem>

                  <Separator />

                  <h3 className="font-semibold text-lg">Estadísticas</h3>

                  <SettingItem
                    icon={BarChart3}
                    label="Mostrar Estadísticas"
                    description="Muestra estadísticas de uso"
                  >
                    <Switch
                      checked={generalSettings.showStats}
                      onCheckedChange={handleToggle('showStats')}
                    />
                  </SettingItem>

                  <SettingItem
                    icon={RefreshCw}
                    label="Actualización Automática"
                    description="Actualiza la app automáticamente"
                  >
                    <Switch
                      checked={generalSettings.autoUpdate}
                      onCheckedChange={handleToggle('autoUpdate')}
                    />
                  </SettingItem>
                </div>
              </TabsContent>

              {/* Advanced Tab */}
              <TabsContent value="advanced" className="space-y-4">
                <div className="space-y-4">
                  <h3 className="font-semibold text-lg">Avanzado</h3>
                  
                  <SettingItem
                    icon={Keyboard}
                    label="Atajos de Teclado"
                    description="Habilita atajos de teclado"
                  >
                    <Switch
                      checked={generalSettings.keyboardShortcuts}
                      onCheckedChange={handleToggle('keyboardShortcuts')}
                    />
                  </SettingItem>

                  <SettingItem
                    icon={Database}
                    label="Caché"
                    description="Habilita el caché para mejor rendimiento"
                  >
                    <Switch
                      checked={generalSettings.cacheEnabled}
                      onCheckedChange={handleToggle('cacheEnabled')}
                    />
                  </SettingItem>

                  <Separator />

                  <h3 className="font-semibold text-lg">v6.0 - Nuevas Funciones</h3>

                  <SettingItem
                    icon={Timer}
                    label="Intervalo de Autoguardado"
                    description="Cada cuántos segundos guardar"
                  >
                    <Select
                      value={generalSettings.autoSaveInterval?.toString() || '30'}
                      onValueChange={(v) => updateGeneralSettings({ autoSaveInterval: parseInt(v) })}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="10">10 seg</SelectItem>
                        <SelectItem value="30">30 seg</SelectItem>
                        <SelectItem value="60">1 min</SelectItem>
                        <SelectItem value="300">5 min</SelectItem>
                      </SelectContent>
                    </Select>
                  </SettingItem>

                  <SettingItem
                    icon={Minimize2}
                    label="Modo Compacto"
                    description="Reduce el espacio entre elementos"
                  >
                    <Switch
                      checked={generalSettings.compactMode || false}
                      onCheckedChange={handleToggle('compactMode')}
                    />
                  </SettingItem>

                  <SettingItem
                    icon={Type}
                    label="Indicador de Escritura"
                    description="Muestra cuando la IA está escribiendo"
                  >
                    <Switch
                      checked={generalSettings.showTypingIndicator ?? true}
                      onCheckedChange={handleToggle('showTypingIndicator')}
                    />
                  </SettingItem>

                  <SettingItem
                    icon={Sparkles}
                    label="Texto Enriquecido"
                    description="Permite formato de negritas, cursivas, etc."
                  >
                    <Switch
                      checked={generalSettings.enableRichText ?? true}
                      onCheckedChange={handleToggle('enableRichText')}
                    />
                  </SettingItem>

                  <SettingItem
                    icon={Languages}
                    label="Detección de Idioma"
                    description="Detecta automáticamente el idioma"
                  >
                    <Switch
                      checked={generalSettings.languageDetection ?? true}
                      onCheckedChange={handleToggle('languageDetection')}
                    />
                  </SettingItem>

                  <Separator />

                  <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 dark:border-amber-800 dark:bg-amber-900/20">
                    <h4 className="font-medium text-amber-800 dark:text-amber-200">Zona de Peligro</h4>
                    <p className="text-sm text-amber-700 dark:text-amber-300 mb-3">
                      Estas acciones son irreversibles
                    </p>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Limpiar Caché
                      </Button>
                      <Button variant="destructive" size="sm">
                        Borrar Todos los Datos
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
