import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const API_TIMEOUT = 90000;

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

export async function POST(request: NextRequest) {
  try {
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }
    
    const { description, style = 'modern', components = [] } = body;

    if (!description || typeof description !== 'string') {
      return NextResponse.json({ error: 'Description is required' }, { status: 400 });
    }

    const zai = await ZAI.create();
    
    const prompt = `Genera un diseño UI moderno basado en la siguiente descripción:

Descripción: "${description}"
Estilo: ${style}
Componentes: ${components.length > 0 ? components.join(', ') : 'Ninguno especificado'}

Responde en formato JSON:
{
  "design": {
    "html": "Código HTML completo con clases Tailwind CSS",
    "css": "CSS adicional si es necesario",
    "description": "Descripción del diseño generado"
  },
  "components": [
    {
      "name": "Nombre del componente",
      "code": "Código del componente",
      "props": ["Lista de props sugeridas"]
    }
  ],
  "colorPalette": {
    "primary": "#color",
    "secondary": "#color",
    "background": "#color",
    "text": "#color"
  },
  "suggestions": ["Sugerencias de mejora"]
}

Usa Tailwind CSS para los estilos. El diseño debe ser responsive y moderno.
Responde SOLO con JSON válido.`;

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Eres un experto diseñador UI/UX. Genera diseños modernos, limpios y responsive usando Tailwind CSS. Responde solo con JSON válido.'
          },
          { role: 'user', content: prompt }
        ],
        thinking: { type: 'disabled' }
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const responseText = completion.choices[0]?.message?.content || '';
    
    let design;
    try {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        design = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found');
      }
    } catch {
      // Fallback design
      design = {
        design: {
          html: `<div class="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
  <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-8 max-w-md w-full mx-4">
    <h1 class="text-2xl font-bold text-slate-900 dark:text-white mb-4">Mi Diseño</h1>
    <p class="text-slate-600 dark:text-slate-300 mb-6">${description}</p>
    <button class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-3 px-6 rounded-lg transition-colors">
      Comenzar
    </button>
  </div>
</div>`,
          css: '',
          description: 'Diseño de tarjeta centrada con botón CTA'
        },
        components: [
          {
            name: 'Card',
            code: `<div class="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-6">
  {children}
</div>`,
            props: ['children', 'className']
          }
        ],
        colorPalette: {
          primary: '#10b981',
          secondary: '#6366f1',
          background: '#0f172a',
          text: '#f8fafc'
        },
        suggestions: ['Agregar animaciones de transición', 'Implementar modo oscuro']
      };
    }

    return NextResponse.json({ ...design, success: true });
  } catch (error) {
    console.error('UI Designer API error:', error);
    
    return NextResponse.json({ 
      design: {
        html: '<div class="p-4">Diseño generado</div>',
        css: '',
        description: 'Diseño básico'
      },
      components: [],
      colorPalette: { primary: '#10b981', secondary: '#6366f1', background: '#ffffff', text: '#000000' },
      suggestions: [],
      success: true, 
      fallback: true 
    });
  }
}
