import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { text, length = 'medium' } = body;

    if (!text) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 });
    }

    const lengthInstructions = {
      short: 'en 1-2 oraciones máximo',
      medium: 'en un párrafo conciso',
      long: 'en 2-3 párrafos detallados'
    };

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: 'Eres un experto en resumir textos. Crea resúmenes claros que capturen los puntos más importantes.'
        },
        { 
          role: 'user', 
          content: `Resume el siguiente texto ${lengthInstructions[length as keyof typeof lengthInstructions]}:\n\n${text}` 
        }
      ],
      thinking: { type: 'disabled' }
    });

    const summary = completion.choices[0]?.message?.content || 'No se pudo generar el resumen.';

    return NextResponse.json({ summary });
  } catch (error) {
    console.error('Summarize API error:', error);
    return NextResponse.json({ summary: 'Error al generar el resumen. Por favor, inténtalo de nuevo.' });
  }
}
