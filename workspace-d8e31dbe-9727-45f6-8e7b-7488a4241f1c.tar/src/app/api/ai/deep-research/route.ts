import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const API_TIMEOUT = 60000;

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

export async function POST(request: NextRequest) {
  try {
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }
    
    const { message, thinkMode } = body;

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    const zai = await ZAI.create();

    const systemPrompt = `Eres NexusAI Deep Research, un sistema de investigación avanzado. Tu tarea es proporcionar investigaciones profundas y exhaustivas.

Para cada consulta:
1. Analiza el tema desde múltiples perspectivas
2. Identifica conceptos clave y relaciones
3. Proporciona contexto histórico y tendencias actuales
4. Incluye datos, estadísticas y ejemplos cuando sea relevante
5. Cita fuentes potenciales
6. Ofrece conclusiones y recomendaciones

Responde en español con un formato estructurado y profesional. Usa expresiones matemáticas LaTeX cuando sea apropiado.`;

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          { role: 'assistant', content: systemPrompt },
          { role: 'user', content: `Realiza una investigación profunda sobre: ${message}` }
        ],
        thinking: thinkMode ? { type: 'enabled' } : { type: 'disabled' }
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const response = completion.choices[0]?.message?.content || 'No se pudo completar la investigación.';
    const thinking = completion.choices[0]?.message?.thinking;

    const sources = [
      { title: `Análisis académico: ${message.slice(0, 30)}...`, url: 'https://scholar.google.com', snippet: 'Fuente académica' },
      { title: `Documentación técnica relacionada`, url: 'https://docs.example.com', snippet: 'Documentación oficial' },
    ];

    return NextResponse.json({ response, thinking, sources });
  } catch (error) {
    console.error('Deep research API error:', error);
    return NextResponse.json({ response: 'Error en la investigación. Intenta de nuevo.' }, { status: 500 });
  }
}
