import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { topic, category = 'business', count = 5 } = body;

    if (!topic) {
      return NextResponse.json({ error: 'Topic is required' }, { status: 400 });
    }

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: `Eres un generador de ideas creativas experto en ${category}. Genera ideas innovadoras, prácticas y originales. Responde SOLO con un JSON array de strings con las ideas.`
        },
        { 
          role: 'user', 
          content: `Genera ${count} ideas creativas sobre: ${topic}` 
        }
      ],
      thinking: { type: 'disabled' }
    });

    const content = completion.choices[0]?.message?.content || '[]';
    
    let ideas: string[] = [];
    try {
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        ideas = JSON.parse(jsonMatch[0]);
      } else {
        // Try to extract ideas from numbered list
        const lines = content.split('\n').filter((line: string) => line.trim().length > 0);
        ideas = lines.slice(0, count).map((line: string) => line.replace(/^\d+[\.\)]\s*/, '').trim());
      }
    } catch {
      ideas = ['Idea 1: ' + topic, 'Idea 2: ' + topic, 'Idea 3: ' + topic];
    }

    return NextResponse.json({ ideas: ideas.slice(0, count) });
  } catch (error) {
    console.error('Ideas generation API error:', error);
    return NextResponse.json({ ideas: ['Error al generar ideas. Por favor, inténtalo de nuevo.'] });
  }
}
