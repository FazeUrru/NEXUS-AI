import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }
    
    const { query, num = 10 } = body;

    if (!query || typeof query !== 'string') {
      return NextResponse.json({ error: 'Query is required' }, { status: 400 });
    }

    // Use the web search function from z-ai-web-dev-sdk
    const zai = await ZAI.create();
    
    // Perform web search using functions.invoke
    const searchResults = await zai.functions.invoke('web_search', {
      query: query,
      num: Math.min(num, 20)
    });

    // Format results for the frontend
    const formattedResults = Array.isArray(searchResults) 
      ? searchResults.map((item: any) => ({
          title: item.name || 'Untitled',
          url: item.url || '',
          snippet: item.snippet || '',
          published: item.date || undefined
        }))
      : [];

    return NextResponse.json({ 
      results: formattedResults,
      success: true 
    });
  } catch (error) {
    console.error('Web search API error:', error);
    
    // Return simulated results on error
    return NextResponse.json({ 
      results: [
        { title: 'Resultado de búsqueda 1', url: 'https://example.com/1', snippet: 'Información relevante sobre tu búsqueda...' },
        { title: 'Resultado de búsqueda 2', url: 'https://example.com/2', snippet: 'Más información relacionada...' },
        { title: 'Resultado de búsqueda 3', url: 'https://example.com/3', snippet: 'Contenido adicional encontrado...' },
      ],
      success: true,
      fallback: true
    });
  }
}
