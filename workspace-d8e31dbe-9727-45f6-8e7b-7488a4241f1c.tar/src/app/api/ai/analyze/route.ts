import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { text } = body;

    if (!text) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 });
    }

    const zai = await ZAI.create();

    // Basic stats calculation
    const words = text.split(/\s+/).filter(w => w.length > 0);
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const paragraphs = text.split(/\n\n+/).filter(p => p.trim().length > 0);
    const avgWordLength = words.length > 0 ? Math.round(words.reduce((a, b) => a + b.length, 0) / words.length) : 0;

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: 'Eres un analista de texto experto. Extrae las 5-10 palabras clave más importantes del texto y genera un resumen breve. Responde en JSON con formato: {"keywords": ["palabra1", "palabra2"], "summary": "resumen"}'
        },
        { role: 'user', content: `Analiza este texto y extrae palabras clave y un resumen: ${text}` }
      ],
      thinking: { type: 'disabled' }
    });

    const content = completion.choices[0]?.message?.content || '{}';
    
    let analysis;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      const parsed = jsonMatch ? JSON.parse(jsonMatch[0]) : { keywords: [], summary: '' };
      
      analysis = {
        wordCount: words.length,
        charCount: text.length,
        sentenceCount: sentences.length,
        paragraphCount: paragraphs.length,
        avgWordLength,
        keywords: parsed.keywords || words.slice(0, 5),
        summary: parsed.summary || 'Análisis completado.'
      };
    } catch {
      analysis = {
        wordCount: words.length,
        charCount: text.length,
        sentenceCount: sentences.length,
        paragraphCount: paragraphs.length,
        avgWordLength,
        keywords: words.slice(0, 5),
        summary: 'Análisis completado.'
      };
    }

    return NextResponse.json({ analysis });
  } catch (error) {
    console.error('Text analysis API error:', error);
    return NextResponse.json({ 
      analysis: {
        wordCount: 0,
        charCount: 0,
        sentenceCount: 0,
        paragraphCount: 0,
        avgWordLength: 0,
        keywords: [],
        summary: 'Error al analizar el texto.'
      }
    });
  }
}
