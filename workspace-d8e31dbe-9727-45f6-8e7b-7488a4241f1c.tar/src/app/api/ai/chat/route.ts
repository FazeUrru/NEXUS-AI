import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Timeout for API calls
const API_TIMEOUT = 30000; // 30 seconds

// Helper function to create timeout promise
function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

// Smart fallback responses for demo mode
function getSmartFallback(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Greeting patterns
  if (lowerMessage.match(/^(hola|hi|hello|hey|buenos|buenas)/)) {
    return `¡Hola! 👋 Soy NexusAI 7.3, tu asistente de inteligencia artificial. Estoy aquí para ayudarte con lo que necesites.

**¿En qué puedo ayudarte hoy?**

- 💬 Responder preguntas
- 📝 Generar contenido
- 💻 Ayuda con código
- 🎨 Crear imágenes
- 🔍 Investigar temas

Simplemente escribe tu consulta y haré todo lo posible por ayudarte.`;
  }
  
  // Code-related
  if (lowerMessage.includes('código') || lowerMessage.includes('code') || lowerMessage.includes('programar')) {
    return `¡Por supuesto! Puedo ayudarte con programación. 🖥️

**Lenguajes que domino:**
- JavaScript / TypeScript
- Python
- Java
- C/C++
- Rust
- Go
- Y muchos más...

**Ejemplo de código Python:**
\`\`\`python
def saludar(nombre):
    return f"¡Hola, {nombre}!"

print(saludar("Mundo"))
\`\`\`

¿En qué lenguaje o proyecto necesitas ayuda?`;
  }
  
  // Image-related
  if (lowerMessage.includes('imagen') || lowerMessage.includes('image') || lowerMessage.includes('dibujo')) {
    return `Puedo generar imágenes para ti usando IA. 🎨

**Para generar una imagen:**
1. Ve a la función "Generar Imágenes" en el menú lateral
2. Describe la imagen que quieres crear
3. Selecciona el tamaño deseado
4. ¡Listo!

**Ejemplo de prompt:**
"Un atardecer sobre un lago tranquilo con montañas al fondo, estilo pintura al óleo"

¿Te gustaría que te ayude a crear una imagen?`;
  }
  
  // Help-related
  if (lowerMessage.includes('ayuda') || lowerMessage.includes('help') || lowerMessage.includes('qué puedes')) {
    return `¡Claro! Aquí está lo que puedo hacer por ti: ✨

**🤖 Asistente**
- Chat IA - Conversación inteligente
- Chat Privado - Cifrado extremo a extremo
- Asistente Pro - Tareas complejas automáticas
- Programador IA - Programa tareas (21:15 hoy)

**🎨 Creación**
- Generar Imágenes - Crea arte con IA
- Generar Videos - Videos desde texto (Beta)
- Generar Audio - Voz y música
- Clonador de Voz - Clona voces (Beta)

**💻 Desarrollo**
- Generar Código - Cualquier lenguaje
- Páginas Web - Landing pages
- Aplicaciones - Apps completas
- Juegos - Juegos interactivos
- Fullstack - Proyectos completos

**📊 Análisis**
- Análisis de Datos - Insights automáticos
- Investigación Profunda - Análisis exhaustivo
- Búsqueda Web - Info en tiempo real

**🆕 Novedades v7.3**
- Asistente de Reuniones
- Scroll inteligente mejorado
- Mejor manejo de errores

¿Qué te gustaría probar?`;
  }
  
  // Default response
  return `Gracias por tu mensaje. He recibido: "${message.slice(0, 100)}${message.length > 100 ? '...' : ''}"

**Nota:** El servicio de IA está en modo de demostración. Para acceso completo, asegúrate de que la API esté configurada correctamente.

**Mientras tanto, puedo:**
- Responder preguntas básicas
- Mostrar las capacidades de NexusAI
- Guiarte sobre cómo usar cada función

¿Hay algo específico en lo que pueda ayudarte?`;
}

export async function POST(request: NextRequest) {
  try {
    // Parse request body with validation
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ response: 'Error: No se pudo procesar la solicitud. Por favor, inténtalo de nuevo.' });
    }
    
    const { message, model = 'gpt-4', temperature = 0.7, thinkMode, agentMode } = body;

    // Validate input
    if (!message || typeof message !== 'string') {
      return NextResponse.json({ response: 'Por favor, escribe un mensaje para continuar.' });
    }

    // Limit message length to prevent abuse
    if (message.length > 10000) {
      return NextResponse.json({ response: 'Tu mensaje es muy largo. Por favor, reduce el contenido a menos de 10,000 caracteres.' });
    }

    // Clamp temperature
    const safeTemperature = Math.max(0, Math.min(2, Number(temperature) || 0.7));

    // Try to use the AI SDK
    try {
      const zai = await ZAI.create();

      // Build system prompt based on mode
      let systemPrompt = 'Eres NexusAI 7.3, un asistente de IA amigable y útil del año 2026. Responde de manera clara y concisa en español.';
      
      if (agentMode) {
        systemPrompt += ' Estás en modo Agente, lo que significa que puedes ejecutar tareas complejas automáticamente.';
      }
      
      if (thinkMode) {
        systemPrompt += ' Piensa paso a paso antes de responder.';
      }

      // Race between API call and timeout
      const completion = await Promise.race([
        zai.chat.completions.create({
          messages: [
            { role: 'assistant', content: systemPrompt },
            { role: 'user', content: message.slice(0, 10000) }
          ],
          thinking: { type: 'disabled' }
        }),
        createTimeoutPromise(API_TIMEOUT)
      ]);

      const response = completion.choices[0]?.message?.content || getSmartFallback(message);
      return NextResponse.json({ response });

    } catch (apiError) {
      // SDK error - use smart fallback
      console.log('SDK unavailable, using smart fallback:', apiError instanceof Error ? apiError.message : 'Unknown error');
      const fallbackResponse = getSmartFallback(message);
      return NextResponse.json({ response: fallbackResponse });
    }

  } catch (error) {
    console.error('Chat API error:', error);
    
    // Return a friendly error response
    return NextResponse.json({ 
      response: 'Lo siento, ha ocurrido un error inesperado. Por favor, inténtalo de nuevo en unos momentos.' 
    });
  }
}
