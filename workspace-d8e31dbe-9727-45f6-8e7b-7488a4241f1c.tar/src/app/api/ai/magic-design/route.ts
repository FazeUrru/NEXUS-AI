import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const API_TIMEOUT = 90000;

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type = 'landing', description, style = 'modern' } = body;

    if (!description || typeof description !== 'string') {
      return NextResponse.json({ error: 'Description is required' }, { status: 400 });
    }

    const zai = await ZAI.create();
    
    const stylePresets: Record<string, string> = {
      modern: 'colores slate, blue y blanco, diseño limpio y minimalista',
      minimal: 'blanco, gris y negro, máximo espacio en blanco',
      vibrant: 'colores vibrantes: purple, pink, yellow',
      professional: 'azul oscuro y gris profesional',
      playful: 'colores divertidos: orange, green, purple',
    };
    
    const colorStyle = stylePresets[style] || stylePresets.modern;

    const prompt = `Genera un diseño UI para: "${description}"
Tipo: ${type}
Estilo: ${colorStyle}

Responde SOLO en JSON válido con esta estructura:
{
  "html": "Código HTML completo con clases Tailwind CSS",
  "css": "CSS adicional si es necesario",
  "description": "Descripción del diseño",
  "components": ["componente1", "componente2"],
  "colorPalette": ["#color1", "#color2"],
  "responsive": true
}

El HTML debe usar Tailwind CSS via CDN y ser completamente funcional.`;

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Eres un diseñador UI/UX experto. Genera diseños modernos, responsivos y funcionales usando Tailwind CSS. Responde solo con JSON válido.'
          },
          { role: 'user', content: prompt }
        ],
        thinking: { type: 'disabled' }
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const responseText = completion.choices[0]?.message?.content || '';
    
    let design;
    try {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        design = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found');
      }
    } catch {
      // Fallback design
      design = {
        html: `<div class="min-h-screen bg-gradient-to-br from-slate-900 to-blue-900 flex items-center justify-center p-8">
  <div class="max-w-4xl mx-auto text-center">
    <h1 class="text-5xl font-bold text-white mb-4">${description.slice(0, 50)}</h1>
    <p class="text-xl text-slate-300 mb-8">Diseño generado automáticamente con IA</p>
    <button class="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-medium transition">Comenzar</button>
  </div>
</div>`,
        css: '',
        description: 'Diseño generado automáticamente',
        components: ['Hero', 'Button'],
        colorPalette: ['#1e293b', '#2563eb', '#ffffff'],
        responsive: true
      };
    }

    return NextResponse.json({ design, success: true });
  } catch (error) {
    console.error('Magic Design API error:', error);
    
    return NextResponse.json({ 
      design: {
        html: '<div class="p-8 text-center">Error generando diseño</div>',
        css: '',
        description: 'Error',
        components: [],
        colorPalette: [],
        responsive: true
      },
      success: false 
    });
  }
}
