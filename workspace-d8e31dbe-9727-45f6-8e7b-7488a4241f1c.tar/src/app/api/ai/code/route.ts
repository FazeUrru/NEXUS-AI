import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  let description = '';
  try {
    const body = await request.json();
    description = body.description || '';
    const { language = 'javascript' } = body;

    if (!description) {
      return NextResponse.json({ error: 'Description is required' }, { status: 400 });
    }

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: `Eres un experto programador en ${language}. Genera código limpio, bien documentado y eficiente. Responde SOLO con el código, sin explicaciones adicionales, dentro de bloques de código markdown.`
        },
        { role: 'user', content: `Genera código en ${language} para: ${description}` }
      ],
      thinking: { type: 'disabled' }
    });

    const code = completion.choices[0]?.message?.content || '';
    
    // Extract code from markdown if present
    const codeMatch = code.match(/```[\w]*\n?([\s\S]*?)```/);
    const cleanCode = codeMatch ? codeMatch[1].trim() : code.replace(/```[\w]*\n?/g, '').replace(/```/g, '').trim();

    return NextResponse.json({ code: cleanCode || code });
  } catch (error) {
    console.error('Code generation API error:', error);
    return NextResponse.json({ 
      code: `// Error al generar código - Por favor, inténtalo de nuevo\n// Descripción: ${description || 'No proporcionada'}` 
    });
  }
}
