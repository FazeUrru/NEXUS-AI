import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Timeout for API calls
const API_TIMEOUT = 60000; // 60 seconds for image generation

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

export async function POST(request: NextRequest) {
  try {
    // Parse request body with validation
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }
    
    const { prompt, style = 'realistic', size = '1024x1024' } = body;

    // Validate input
    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json({ error: 'Prompt is required and must be a string' }, { status: 400 });
    }

    // Limit prompt length
    if (prompt.length > 2000) {
      return NextResponse.json({ error: 'Prompt too long. Maximum 2000 characters.' }, { status: 400 });
    }

    const zai = await ZAI.create();

    // Valid sizes for the API
    const validSizes = ['1024x1024', '768x1344', '864x1152', '1344x768', '1152x864', '1440x720', '720x1440'] as const;
    type ValidSize = typeof validSizes[number];
    const safeSize: ValidSize = validSizes.includes(size as ValidSize) ? (size as ValidSize) : '1024x1024';

    // Build prompt with style
    const styleMap: Record<string, string> = {
      realistic: 'photorealistic, high detail, natural lighting',
      artistic: 'artistic, creative, expressive, painted',
      cartoon: 'cartoon style, animated, colorful, playful',
      anime: 'anime style, manga, Japanese animation, detailed',
      '3d': '3D render, CGI, volumetric lighting, realistic textures',
      watercolor: 'watercolor painting, soft colors, artistic, flowing'
    };
    
    const styleDesc = styleMap[style] || styleMap.realistic;
    const fullPrompt = `${prompt.slice(0, 1800)}, ${styleDesc}, high quality, detailed`;

    // Race between API call and timeout
    const response = await Promise.race([
      zai.images.generations.create({
        prompt: fullPrompt,
        size: safeSize
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const imageBase64 = response.data[0]?.base64;

    if (imageBase64) {
      return NextResponse.json({ 
        image: `data:image/png;base64,${imageBase64}`,
        success: true 
      });
    }

    // Fallback to placeholder
    return NextResponse.json({ 
      image: `https://picsum.photos/seed/${Date.now()}/1024/1024`,
      success: true,
      fallback: true
    });
  } catch (error) {
    console.error('Image generation API error:', error);
    
    // Return fallback image instead of error
    return NextResponse.json({ 
      image: `https://picsum.photos/seed/${Date.now()}/1024/1024`,
      success: true,
      fallback: true,
      message: 'Using fallback image due to generation error'
    });
  }
}
