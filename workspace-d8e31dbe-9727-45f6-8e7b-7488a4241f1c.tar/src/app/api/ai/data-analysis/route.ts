import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const API_TIMEOUT = 60000;

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type = 'descriptive', data, question = '' } = body;

    if (!data || typeof data !== 'string') {
      return NextResponse.json({ error: 'Data is required' }, { status: 400 });
    }

    const zai = await ZAI.create();
    
    const prompts: Record<string, string> = {
      descriptive: `Analiza los siguientes datos y proporciona un análisis descriptivo completo. Incluye estadísticas básicas, resumen y observaciones clave. Responde en JSON con: {"summary": "resumen", "insights": ["insight1", ...], "statistics": {"key": "value"}, "recommendations": ["rec1", ...]}. Datos: ${data.slice(0, 3000)}`,
      trend: `Analiza las tendencias en los siguientes datos. Identifica patrones, direcciones y predicciones. Responde en JSON con: {"summary": "resumen", "insights": [...], "statistics": {}, "recommendations": [...]}. Datos: ${data.slice(0, 3000)}`,
      correlation: `Busca correlaciones y relaciones entre variables en estos datos. Responde en JSON con: {"summary": "resumen", "insights": [...], "statistics": {}, "recommendations": [...]}. Datos: ${data.slice(0, 3000)}`,
      predictive: `Realiza un análisis predictivo basado en estos datos. Identifica tendencias futuras probables. Responde en JSON con: {"summary": "resumen", "insights": [...], "statistics": {}, "recommendations": [...]}. Datos: ${data.slice(0, 3000)}`,
    };

    const prompt = `${prompts[type]} ${question ? `Pregunta específica: ${question}` : ''}`;

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Eres un analista de datos experto. Proporciona análisis detallados y útiles en formato JSON válido.'
          },
          { role: 'user', content: prompt }
        ],
        thinking: { type: 'disabled' }
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const responseText = completion.choices[0]?.message?.content || '';
    
    let result;
    try {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      result = jsonMatch ? JSON.parse(jsonMatch[0]) : null;
    } catch {
      result = {
        summary: responseText,
        insights: ['Análisis completado'],
        recommendations: ['Revisa los datos para más detalles']
      };
    }

    return NextResponse.json({ result, success: true });
  } catch (error) {
    console.error('Data Analysis API error:', error);
    
    return NextResponse.json({ 
      result: {
        summary: 'Error en el análisis',
        insights: [],
        recommendations: ['Inténtalo de nuevo']
      },
      success: false 
    });
  }
}
