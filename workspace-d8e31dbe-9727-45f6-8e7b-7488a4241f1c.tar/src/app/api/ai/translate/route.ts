import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  let text = '';
  try {
    const body = await request.json();
    text = body.text || '';
    const { sourceLang = 'auto', targetLang = 'en' } = body;

    if (!text) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 });
    }

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: 'Eres un traductor profesional multilingüe. Traduce el texto al idioma de destino. Responde SOLO con la traducción, sin explicaciones.'
        },
        { 
          role: 'user', 
          content: `Traduce el siguiente texto${sourceLang !== 'auto' ? ` del ${sourceLang}` : ''} al ${targetLang}: ${text}` 
        }
      ],
      thinking: { type: 'disabled' }
    });

    const translation = completion.choices[0]?.message?.content || text;

    return NextResponse.json({ translation });
  } catch (error) {
    console.error('Translation API error:', error);
    return NextResponse.json({ translation: text });
  }
}
