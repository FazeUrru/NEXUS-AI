import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { subject, recipient, purpose = 'professional', tone = 'formal', keyPoints } = body;

    if (!subject) {
      return NextResponse.json({ error: 'Subject is required' }, { status: 400 });
    }

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: 'Eres un asistente experto en redacción de emails profesionales. Genera emails bien estructurados con saludo apropiado, cuerpo claro y despedida profesional.'
        },
        { 
          role: 'user', 
          content: `Escribe un email ${purpose} con tono ${tone} sobre: ${subject}${recipient ? ` dirigido a: ${recipient}` : ''}${keyPoints ? `. Puntos clave a incluir: ${keyPoints}` : ''}` 
        }
      ],
      thinking: { type: 'disabled' }
    });

    const email = completion.choices[0]?.message?.content || 'No se pudo generar el email.';

    return NextResponse.json({ email });
  } catch (error) {
    console.error('Email generation API error:', error);
    return NextResponse.json({ email: 'Error al generar el email. Por favor, inténtalo de nuevo.' });
  }
}
