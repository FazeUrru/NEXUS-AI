import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { concept, level = 'intermediate', context } = body;

    if (!concept) {
      return NextResponse.json({ error: 'Concept is required' }, { status: 400 });
    }

    const levelDescriptions = {
      simple: 'como si le explicaras a un niño de 5 años, usando analogías simples y ejemplos cotidianos',
      beginner: 'para alguien que está empezando a aprender el tema, sin tecnicismos',
      intermediate: 'para alguien con conocimientos básicos previos, con algunos términos técnicos',
      advanced: 'con profundidad técnica y detalles especializados',
      expert: 'con el máximo nivel de detalle y complejidad técnica'
    };

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: 'Eres un educador experto. Explica conceptos de manera clara, adaptada al nivel del usuario y con ejemplos prácticos.'
        },
        { 
          role: 'user', 
          content: `Explica "${concept}" ${levelDescriptions[level as keyof typeof levelDescriptions]}${context ? ` en el contexto de: ${context}` : ''}` 
        }
      ],
      thinking: { type: 'disabled' }
    });

    const explanation = completion.choices[0]?.message?.content || 'No se pudo generar la explicación.';

    return NextResponse.json({ explanation });
  } catch (error) {
    console.error('Explain API error:', error);
    return NextResponse.json({ explanation: 'Error al generar la explicación. Por favor, inténtalo de nuevo.' });
  }
}
