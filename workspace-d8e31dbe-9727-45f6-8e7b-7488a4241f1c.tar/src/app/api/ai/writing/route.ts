import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const API_TIMEOUT = 60000;

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, topic, tone = 'Profesional', length = 'medium' } = body;

    if (!topic || typeof topic !== 'string') {
      return NextResponse.json({ error: 'Topic is required' }, { status: 400 });
    }

    const zai = await ZAI.create();
    
    const lengthWords = { short: 300, medium: 600, long: 1000 };
    const targetWords = lengthWords[length as keyof typeof lengthWords] || 600;
    
    const prompts: Record<string, string> = {
      blog: `Escribe un artículo de blog profesional sobre: "${topic}". Tono: ${tone}. Longitud aproximada: ${targetWords} palabras. Incluye introducción, desarrollo con subtítulos y conclusión.`,
      article: `Escribe un artículo periodístico sobre: "${topic}". Tono: ${tone}. Longitud aproximada: ${targetWords} palabras. Estructura con título atractivo, lead y cuerpo.`,
      essay: `Escribe un ensayo académico sobre: "${topic}". Tono: ${tone}. Longitud aproximada: ${targetWords} palabras. Incluye tesis, argumentos y conclusión.`,
      story: `Escribe una historia creativa sobre: "${topic}". Tono: ${tone}. Longitud aproximada: ${targetWords} palabras. Incluye narrativa, diálogo y desarrollo de personajes.`,
      copy: `Escribe texto persuasivo (copywriting) para: "${topic}". Tono: ${tone}. Longitud aproximada: ${targetWords} palabras. Enfocado en convertir.`,
      email: `Escribe un email profesional sobre: "${topic}". Tono: ${tone}. Longitud aproximada: ${targetWords} palabras. Incluye asunto, saludo, cuerpo y despedida.`,
      improve: `Mejora y reescribe el siguiente texto manteniendo su esencia pero haciéndolo más profesional y pulido. Texto: "${topic}". Tono: ${tone}.`,
    };

    const prompt = prompts[type] || prompts.blog;

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Eres un escritor profesional experto en crear contenido de alta calidad. Genera texto bien estructurado, sin errores y con estilo profesional.'
          },
          { role: 'user', content: prompt }
        ],
        thinking: { type: 'disabled' }
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const content = completion.choices[0]?.message?.content || '';

    return NextResponse.json({ content, success: true });
  } catch (error) {
    console.error('Writing API error:', error);
    
    return NextResponse.json({ 
      content: 'Error al generar el contenido. Por favor, inténtalo de nuevo.',
      success: false 
    });
  }
}
