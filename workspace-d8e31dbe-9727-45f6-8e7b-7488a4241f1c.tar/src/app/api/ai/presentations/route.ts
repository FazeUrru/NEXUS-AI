import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

interface Slide {
  id: string;
  title: string;
  content: string;
  type: 'title' | 'content' | 'image' | 'two-column';
}

const API_TIMEOUT = 60000;

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

export async function POST(request: NextRequest) {
  try {
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }
    
    const { topic, style = 'professional' } = body;

    if (!topic || typeof topic !== 'string') {
      return NextResponse.json({ error: 'Topic is required' }, { status: 400 });
    }

    const zai = await ZAI.create();
    
    const prompt = `Crea una presentación sobre: "${topic}"
Estilo: ${style}

Genera 6 diapositivas en formato JSON con esta estructura:
[
  {
    "title": "Título de la diapositiva",
    "content": "Contenido detallado con bullet points separados por \\n• ",
    "type": "title|content|image|two-column"
  }
]

La primera diapositiva debe ser type "title" con el título principal.
Las demás deben ser type "content".
Incluye contenido rico y detallado en cada diapositiva.

Responde SOLO con el JSON válido, sin markdown ni explicaciones.`;

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Eres un experto en crear presentaciones profesionales. Responde solo con JSON válido.'
          },
          { role: 'user', content: prompt }
        ],
        thinking: { type: 'disabled' }
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const responseText = completion.choices[0]?.message?.content || '';
    
    // Parse JSON from response
    let slides: Slide[] = [];
    try {
      // Try to extract JSON from response
      const jsonMatch = responseText.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        slides = parsed.map((s: Partial<Slide>, i: number) => ({
          id: `slide-${i + 1}`,
          title: s.title || `Diapositiva ${i + 1}`,
          content: s.content || '',
          type: s.type || 'content'
        }));
      }
    } catch (parseError) {
      console.error('JSON parse error:', parseError);
      // Generate default slides if parsing fails
      slides = [
        { id: 'slide-1', title: topic, content: 'Presentación generada con IA', type: 'title' },
        { id: 'slide-2', title: 'Introducción', content: '• Contexto del tema\n• Importancia\n• Objetivos', type: 'content' },
        { id: 'slide-3', title: 'Desarrollo', content: '• Punto principal 1\n• Punto principal 2\n• Análisis', type: 'content' },
        { id: 'slide-4', title: 'Conclusiones', content: '• Resumen de puntos clave\n• Próximos pasos\n• Preguntas', type: 'content' },
      ];
    }

    return NextResponse.json({ slides, success: true });
  } catch (error) {
    console.error('Presentations API error:', error);
    
    // Return fallback slides
    const fallbackSlides: Slide[] = [
      { id: 'slide-1', title: 'Tema de Presentación', content: 'Creado con IA', type: 'title' },
      { id: 'slide-2', title: 'Contenido Principal', content: '• Punto 1\n• Punto 2\n• Punto 3', type: 'content' },
      { id: 'slide-3', title: 'Resumen', content: 'Conclusiones principales', type: 'content' },
    ];
    
    return NextResponse.json({ 
      slides: fallbackSlides, 
      success: true, 
      fallback: true 
    });
  }
}
