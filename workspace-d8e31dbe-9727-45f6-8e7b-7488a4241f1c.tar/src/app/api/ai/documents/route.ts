import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const API_TIMEOUT = 60000;

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

const documentPrompts: Record<string, string> = {
  report: 'Escribe un informe profesional estructurado con: Introducción, Desarrollo, Conclusiones y Recomendaciones.',
  proposal: 'Escribe una propuesta de proyecto profesional con: Resumen ejecutivo, Descripción del proyecto, Metodología, Cronograma y Presupuesto.',
  article: 'Escribe un artículo informativo bien estructurado con: Título atractivo, Introducción, Desarrollo con subtítulos, y Conclusión.',
  resume: 'Crea un currículum vitae profesional con: Datos de contacto, Perfil profesional, Experiencia laboral, Educación y Habilidades.',
  letter: 'Escribe una carta formal profesional con: Encabezado, Saludo, Cuerpo del mensaje, Despedida y Firma.',
  contract: 'Redacta un borrador de contrato legal con: Partes involucradas, Objeto del contrato, Cláusulas principales, Duración y Firmas.',
};

export async function POST(request: NextRequest) {
  try {
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }
    
    const { type = 'report', topic, details = '' } = body;

    if (!topic || typeof topic !== 'string') {
      return NextResponse.json({ error: 'Topic is required' }, { status: 400 });
    }

    const zai = await ZAI.create();
    
    const basePrompt = documentPrompts[type] || documentPrompts.report;
    
    const prompt = `${basePrompt}

Tema: "${topic}"
${details ? `Detalles adicionales: ${details}` : ''}

Genera un documento profesional completo y detallado. Usa formato markdown con títulos (# ## ###), listas y párrafos bien estructurados.`;

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Eres un experto en redacción de documentos profesionales. Genera contenido de alta calidad, bien estructurado y profesional.'
          },
          { role: 'user', content: prompt }
        ],
        thinking: { type: 'disabled' }
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const content = completion.choices[0]?.message?.content || '';

    return NextResponse.json({ content, success: true });
  } catch (error) {
    console.error('Documents API error:', error);
    
    return NextResponse.json({ 
      content: `# Documento: Error en la generación

No se pudo generar el documento en este momento. Por favor, inténtalo de nuevo más tarde.

---
*Generado con NexusAI*`,
      success: true,
      fallback: true 
    });
  }
}
