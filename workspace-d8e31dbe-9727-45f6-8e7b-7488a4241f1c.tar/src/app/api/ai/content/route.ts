import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { topic, contentType = 'article', tone = 'professional', length = 'medium' } = body;

    if (!topic) {
      return NextResponse.json({ error: 'Topic is required' }, { status: 400 });
    }

    const lengthWords = {
      short: '200-300 palabras',
      medium: '400-600 palabras',
      long: '800-1000 palabras'
    };

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: `Eres un creador de contenido profesional especializado en ${contentType}. Escribe con un tono ${tone}. Genera contenido de alta calidad, bien estructurado y atractivo.`
        },
        { 
          role: 'user', 
          content: `Crea un ${contentType} sobre "${topic}" con un tono ${tone}. Longitud: ${lengthWords[length as keyof typeof lengthWords]}. Incluye un título atractivo.` 
        }
      ],
      thinking: { type: 'disabled' }
    });

    const content = completion.choices[0]?.message?.content || 'No se pudo generar el contenido.';

    return NextResponse.json({ content });
  } catch (error) {
    console.error('Content generation API error:', error);
    return NextResponse.json({ content: 'Error al generar el contenido. Por favor, inténtalo de nuevo.' });
  }
}
