import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const API_TIMEOUT = 90000;

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

export async function POST(request: NextRequest) {
  try {
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }
    
    const { description, pageType = 'landing', framework = 'nextjs' } = body;

    if (!description || typeof description !== 'string') {
      return NextResponse.json({ error: 'Description is required' }, { status: 400 });
    }

    const zai = await ZAI.create();
    
    const prompt = `Genera una página web completa para:

Tipo de página: ${pageType}
Framework: ${framework}
Descripción: "${description}"

Responde en formato JSON:
{
  "html": "Código HTML/JSX completo de la página",
  "css": "CSS adicional si es necesario",
  "sections": [
    {
      "name": "Nombre de la sección",
      "description": "Descripción",
      "code": "Código de la sección"
    }
  ],
  "features": ["Características incluidas"],
  "seo": {
    "title": "Título SEO sugerido",
    "description": "Meta descripción",
    "keywords": ["palabras clave"]
  }
}

Usa Tailwind CSS para estilos. La página debe ser responsive y moderna.
Responde SOLO con JSON válido.`;

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Eres un experto desarrollador web. Genera páginas web modernas, responsive y optimizadas. Responde solo con JSON válido.'
          },
          { role: 'user', content: prompt }
        ],
        thinking: { type: 'disabled' }
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const responseText = completion.choices[0]?.message?.content || '';
    
    let page;
    try {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        page = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found');
      }
    } catch {
      // Fallback page
      page = {
        html: `export default function Page() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center">
          <h1 className="text-5xl font-bold text-slate-900 mb-6">
            ${description}
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-8">
            Bienvenido a nuestra página web
          </p>
          <button className="bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-3 px-8 rounded-lg transition-colors">
            Comenzar Ahora
          </button>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-3 gap-8">
          {['Característica 1', 'Característica 2', 'Característica 3'].map((feature, i) => (
            <div key={i} className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-semibold mb-2">{feature}</h3>
              <p className="text-slate-600">Descripción de la característica</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}`,
        css: '',
        sections: [
          { name: 'Hero', description: 'Sección principal con CTA', code: '<section>...</section>' },
          { name: 'Features', description: 'Características del producto', code: '<section>...</section>' }
        ],
        features: ['Responsive design', 'Optimizado SEO', 'Animaciones CSS'],
        seo: {
          title: `${description} | Mi Sitio Web`,
          description: `Página web sobre ${description}`,
          keywords: [description, 'web', 'landing page']
        }
      };
    }

    return NextResponse.json({ ...page, success: true });
  } catch (error) {
    console.error('Web Pages API error:', error);
    
    return NextResponse.json({ 
      html: '<div>Página generada</div>',
      css: '',
      sections: [],
      features: ['Diseño básico'],
      seo: { title: 'Página Web', description: '', keywords: [] },
      success: true, 
      fallback: true 
    });
  }
}
