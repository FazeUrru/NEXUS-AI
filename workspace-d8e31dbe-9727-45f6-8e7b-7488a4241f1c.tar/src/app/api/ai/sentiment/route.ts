import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { text } = body;

    if (!text) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 });
    }

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: 'Eres un analista de sentimientos experto. Analiza el texto y responde SOLO en formato JSON válido con: {"sentiment": "positive/neutral/negative/very_negative", "confidence": 0.85, "emotions": {"joy": 0.2, "sadness": 0.1, "anger": 0.1, "fear": 0.1, "surprise": 0.1}, "explanation": "explicación breve"}'
        },
        { 
          role: 'user', 
          content: `Analiza el sentimiento de este texto: ${text}` 
        }
      ],
      thinking: { type: 'disabled' }
    });

    const content = completion.choices[0]?.message?.content || '{}';
    
    let result;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      result = jsonMatch ? JSON.parse(jsonMatch[0]) : null;
    } catch {
      result = null;
    }

    if (!result) {
      result = {
        sentiment: 'neutral',
        confidence: 0.5,
        emotions: { joy: 0.2, sadness: 0.2, anger: 0.2, fear: 0.2, surprise: 0.2 },
        explanation: 'Análisis completado. El texto parece tener un tono neutral.'
      };
    }

    return NextResponse.json({ result });
  } catch (error) {
    console.error('Sentiment analysis API error:', error);
    return NextResponse.json({ 
      result: {
        sentiment: 'neutral',
        confidence: 0.5,
        emotions: { joy: 0.2, sadness: 0.2, anger: 0.2, fear: 0.2, surprise: 0.2 },
        explanation: 'Error al analizar el sentimiento.'
      }
    });
  }
}
