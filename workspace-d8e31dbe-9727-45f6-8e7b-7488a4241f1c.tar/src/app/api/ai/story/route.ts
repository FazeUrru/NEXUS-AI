import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { premise, genre = 'fantasy', style = 'narrative', length = 'medium', characters } = body;

    if (!premise) {
      return NextResponse.json({ error: 'Premise is required' }, { status: 400 });
    }

    const lengthWords = {
      short: 'aproximadamente 500 palabras',
      medium: 'aproximadamente 1000 palabras',
      long: 'aproximadamente 2000 palabras'
    };

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: `Eres un escritor creativo profesional especializado en ${genre}. Crea historias envolventes, con personajes memorables y tramas interesantes. Escribe en español con calidad literaria.`
        },
        { 
          role: 'user', 
          content: `Escribe una historia de ${genre} con estilo ${style}, ${lengthWords[length as keyof typeof lengthWords]}. Premisa: ${premise}${characters ? `. Personajes principales: ${characters}` : ''}. Incluye descripciones vívidas y diálogos naturales.` 
        }
      ],
      thinking: { type: 'disabled' }
    });

    const story = completion.choices[0]?.message?.content || 'No se pudo generar la historia.';

    return NextResponse.json({ story });
  } catch (error) {
    console.error('Story generation API error:', error);
    return NextResponse.json({ story: 'Error al generar la historia. Por favor, inténtalo de nuevo.' });
  }
}
