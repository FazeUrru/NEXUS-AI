import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { topic, context, style = 'catchy', count = 5 } = body;

    if (!topic) {
      return NextResponse.json({ error: 'Topic is required' }, { status: 400 });
    }

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: `Eres un experto en crear títulos ${style} y atractivos. Responde SOLO con un JSON array de strings con ${count} títulos.`
        },
        { 
          role: 'user', 
          content: `Genera ${count} títulos ${style} sobre "${topic}"${context ? ` con este contexto: ${context}` : ''}` 
        }
      ],
      thinking: { type: 'disabled' }
    });

    const content = completion.choices[0]?.message?.content || '[]';
    
    let titles: string[] = [];
    try {
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        titles = JSON.parse(jsonMatch[0]);
      } else {
        const lines = content.split('\n').filter((line: string) => line.trim().length > 0);
        titles = lines.slice(0, count).map((line: string) => line.replace(/^\d+[\.\)]\s*/, '').replace(/["']/g, '').trim());
      }
    } catch {
      titles = [`${topic} - Guía Completa 2026`, `Todo sobre ${topic}`, `${topic}: Lo que debes saber`];
    }

    return NextResponse.json({ titles: titles.slice(0, count) });
  } catch (error) {
    console.error('Titles generation API error:', error);
    return NextResponse.json({ titles: ['Error al generar títulos'] });
  }
}
