import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const API_TIMEOUT = 90000;

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

export async function POST(request: NextRequest) {
  try {
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }
    
    const { type = 'mobile', category = 'Productividad', description } = body;

    if (!description || typeof description !== 'string') {
      return NextResponse.json({ error: 'Description is required' }, { status: 400 });
    }

    const zai = await ZAI.create();
    
    const prompt = `Genera el diseño completo para una aplicación ${type} de categoría "${category}".

Descripción de la app: "${description}"

Responde en formato JSON con esta estructura:
{
  "structure": "Estructura de carpetas del proyecto",
  "screens": [
    {
      "name": "Nombre de la pantalla",
      "description": "Descripción de la pantalla",
      "code": "Código de ejemplo para esta pantalla"
    }
  ],
  "features": ["Lista de funcionalidades principales"]
}

Incluye al menos 4 pantallas principales. El código debe ser funcional y bien comentado.
Responde SOLO con JSON válido.`;

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Eres un experto desarrollador de aplicaciones móviles y web. Genera código limpio, moderno y funcional. Responde solo con JSON válido.'
          },
          { role: 'user', content: prompt }
        ],
        thinking: { type: 'disabled' }
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const responseText = completion.choices[0]?.message?.content || '';
    
    let app;
    try {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        app = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found');
      }
    } catch {
      // Fallback app structure
      app = {
        structure: `app/
├── src/
│   ├── screens/
│   │   ├── HomeScreen.tsx
│   │   ├── DetailScreen.tsx
│   │   └── ProfileScreen.tsx
│   ├── components/
│   │   ├── Header.tsx
│   │   └── Footer.tsx
│   └── App.tsx
├── package.json
└── README.md`,
        screens: [
          {
            name: 'HomeScreen',
            description: 'Pantalla principal de la aplicación',
            code: `import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export function HomeScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Bienvenido</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 24, fontWeight: 'bold' }
});`
          }
        ],
        features: ['Autenticación', 'Navegación', 'Notificaciones', 'Perfil de usuario']
      };
    }

    return NextResponse.json({ app, success: true });
  } catch (error) {
    console.error('Apps API error:', error);
    
    return NextResponse.json({ 
      app: {
        structure: 'src/\n├── components/\n├── screens/\n└── utils/',
        screens: [],
        features: ['Funcionalidad básica']
      }, 
      success: true, 
      fallback: true 
    });
  }
}
