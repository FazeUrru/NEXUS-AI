import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { code, language = 'javascript', task = 'explain' } = body;

    if (!code) {
      return NextResponse.json({ error: 'Code is required' }, { status: 400 });
    }

    const taskInstructions = {
      explain: 'Explica qué hace el código paso a paso y su propósito general.',
      debug: 'Identifica posibles errores, bugs o problemas y proporciona sugerencias de corrección.',
      optimize: 'Sugiere mejoras de rendimiento y legibilidad con ejemplos de código optimizado.',
      document: 'Agrega comentarios explicativos y documentación completa al código.'
    };

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: `Eres un experto programador en ${language}. ${taskInstructions[task as keyof typeof taskInstructions]} Responde con explicaciones claras y código cuando sea necesario.`
        },
        { 
          role: 'user', 
          content: `Analiza este código en ${language}:\n\n${code}` 
        }
      ],
      thinking: { type: 'disabled' }
    });

    const content = completion.choices[0]?.message?.content || '';
    
    const result = {
      explanation: content,
      suggestions: [] as string[],
      code: undefined as string | undefined,
      fixedCode: undefined as string | undefined
    };

    // Try to extract code if present
    const codeMatch = content.match(/```[\w]*\n?([\s\S]*?)```/);
    if (codeMatch && (task === 'optimize' || task === 'debug')) {
      if (task === 'optimize') {
        result.code = codeMatch[1].trim();
      } else {
        result.fixedCode = codeMatch[1].trim();
      }
    }

    return NextResponse.json({ result });
  } catch (error) {
    console.error('Code assistant API error:', error);
    return NextResponse.json({ 
      result: {
        explanation: 'Error al analizar el código. Por favor, inténtalo de nuevo.',
        suggestions: []
      }
    });
  }
}
