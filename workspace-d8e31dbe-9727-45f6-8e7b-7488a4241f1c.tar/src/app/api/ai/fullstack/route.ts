import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const API_TIMEOUT = 120000;

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

export async function POST(request: NextRequest) {
  try {
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }
    
    const { projectType = 'saas', techStack = 'nextjs', projectName, description } = body;

    if (!projectName || !description) {
      return NextResponse.json({ error: 'Project name and description are required' }, { status: 400 });
    }

    const zai = await ZAI.create();
    
    const prompt = `Genera un proyecto fullstack completo para:

Tipo: ${projectType}
Stack: ${techStack}
Nombre: ${projectName}
Descripción: ${description}

Responde en formato JSON:
{
  "structure": "Árbol de carpetas del proyecto completo",
  "frontend": [
    {"path": "ruta/del/archivo.tsx", "code": "código completo"}
  ],
  "backend": [
    {"path": "api/route.ts", "code": "código del endpoint"}
  ],
  "database": [
    {"path": "schema.prisma", "code": "esquema de base de datos"}
  ],
  "features": ["lista de funcionalidades incluidas"],
  "commands": "comandos de instalación y ejecución"
}

Incluye código funcional y completo para al menos 2 archivos de cada sección.
Responde SOLO con JSON válido.`;

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Eres un arquitecto de software experto en desarrollo fullstack. Genera código profesional, limpio y funcional. Responde solo con JSON válido.'
          },
          { role: 'user', content: prompt }
        ],
        thinking: { type: 'disabled' }
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const responseText = completion.choices[0]?.message?.content || '';
    
    let project;
    try {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        project = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found');
      }
    } catch {
      // Fallback project
      project = {
        structure: `${projectName}/
├── frontend/
│   ├── src/
│   │   ├── app/
│   │   ├── components/
│   │   └── lib/
│   └── package.json
├── backend/
│   ├── src/
│   │   ├── routes/
│   │   └── middleware/
│   └── package.json
└── database/
    └── schema.prisma`,
        frontend: [
          {
            path: 'frontend/src/app/page.tsx',
            code: `export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center">
      <h1 className="text-4xl font-bold">${projectName}</h1>
      <p>${description}</p>
    </main>
  );
}`
          }
        ],
        backend: [
          {
            path: 'backend/src/routes/api.ts',
            code: `import { Router } from 'express';

const router = Router();

router.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

export default router;`
          }
        ],
        database: [
          {
            path: 'database/schema.prisma',
            code: `model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  createdAt DateTime @default(now())
}`
          }
        ],
        features: ['Autenticación JWT', 'CRUD completo', 'API REST', 'Base de datos PostgreSQL'],
        commands: `# Instalar dependencias
cd frontend && npm install
cd ../backend && npm install

# Configurar base de datos
npx prisma migrate dev

# Ejecutar
npm run dev`
      };
    }

    return NextResponse.json({ project, success: true });
  } catch (error) {
    console.error('Fullstack API error:', error);
    
    return NextResponse.json({ 
      project: {
        structure: 'project/\n├── frontend/\n├── backend/\n└── database/',
        frontend: [],
        backend: [],
        database: [],
        features: ['Estructura básica'],
        commands: 'npm install && npm run dev'
      }, 
      success: true, 
      fallback: true 
    });
  }
}
