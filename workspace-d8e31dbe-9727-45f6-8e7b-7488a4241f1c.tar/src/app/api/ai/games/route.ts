import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

const API_TIMEOUT = 90000;

function createTimeoutPromise(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), ms);
  });
}

export async function POST(request: NextRequest) {
  try {
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }
    
    const { type = 'arcade', name = 'Mi Juego', description } = body;

    if (!description || typeof description !== 'string') {
      return NextResponse.json({ error: 'Description is required' }, { status: 400 });
    }

    const zai = await ZAI.create();
    
    const prompt = `Genera un juego ${type} completo en HTML5 con JavaScript vanilla.

Nombre del juego: "${name}"
Descripción: "${description}"

Requisitos:
1. Código HTML completo en un solo archivo con <style> y <script> embebidos
2. Canvas para renderizar el juego
3. Controles con teclado (flechas o WASD)
4. Sistema de puntuación
5. Detección de colisiones
6. Pantalla de Game Over con opción de reiniciar

Responde en formato JSON:
{
  "html": "Código HTML completo del juego",
  "features": ["Lista de características"],
  "controls": "Descripción de los controles"
}

El juego debe ser jugable y divertido. Responde SOLO con JSON válido.`;

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'Eres un experto desarrollador de juegos HTML5. Genera código de juegos completos, funcionales y divertidos. Responde solo con JSON válido.'
          },
          { role: 'user', content: prompt }
        ],
        thinking: { type: 'disabled' }
      }),
      createTimeoutPromise(API_TIMEOUT)
    ]);

    const responseText = completion.choices[0]?.message?.content || '';
    
    let game;
    try {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        game = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found');
      }
    } catch {
      // Fallback simple game
      game = {
        html: `<!DOCTYPE html>
<html>
<head>
<style>
  body { margin: 0; display: flex; justify-content: center; align-items: center; min-height: 100vh; background: #1a1a2e; }
  canvas { border: 2px solid #4ecca3; }
</style>
</head>
<body>
<canvas id="game" width="400" height="400"></canvas>
<script>
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
let score = 0;
let player = { x: 180, y: 350, w: 40, h: 40 };
let enemies = [];
let gameOver = false;

document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowLeft') player.x -= 20;
  if (e.key === 'ArrowRight') player.x += 20;
  if (gameOver && e.key === ' ') location.reload();
  player.x = Math.max(0, Math.min(360, player.x));
});

function spawnEnemy() {
  enemies.push({ x: Math.random() * 360, y: 0, w: 30, h: 30 });
}

function update() {
  if (gameOver) return;
  enemies.forEach((e, i) => {
    e.y += 3;
    if (e.y > 400) { enemies.splice(i, 1); score++; }
    if (player.x < e.x + e.w && player.x + player.w > e.x &&
        player.y < e.y + e.h && player.y + player.h > e.y) {
      gameOver = true;
    }
  });
}

function draw() {
  ctx.fillStyle = '#1a1a2e';
  ctx.fillRect(0, 0, 400, 400);
  ctx.fillStyle = '#4ecca3';
  ctx.fillRect(player.x, player.y, player.w, player.h);
  ctx.fillStyle = '#ff6b6b';
  enemies.forEach(e => ctx.fillRect(e.x, e.y, e.w, e.h));
  ctx.fillStyle = '#fff';
  ctx.font = '20px Arial';
  ctx.fillText('Score: ' + score, 10, 30);
  if (gameOver) {
    ctx.fillText('Game Over! Press SPACE', 100, 200);
  }
}

setInterval(spawnEnemy, 1000);
function loop() { update(); draw(); requestAnimationFrame(loop); }
loop();
</script>
</body>
</html>`,
        features: ['Controles con flechas', 'Sistema de puntuación', 'Enemigos que caen', 'Detección de colisiones'],
        controls: 'Flechas izquierda/derecha para moverse. ESPACIO para reiniciar.'
      };
    }

    return NextResponse.json({ game, success: true });
  } catch (error) {
    console.error('Games API error:', error);
    
    return NextResponse.json({ 
      game: {
        html: '<!DOCTYPE html><html><body><h1>Error generando juego</h1></body></html>',
        features: ['Juego básico'],
        controls: 'N/A'
      }, 
      success: true, 
      fallback: true 
    });
  }
}
