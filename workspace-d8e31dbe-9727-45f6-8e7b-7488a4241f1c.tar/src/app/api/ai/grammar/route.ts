import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  let text = '';
  try {
    const body = await request.json();
    text = body.text || '';

    if (!text) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 });
    }

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: 'Eres un corrector gramatical experto en español. Corrige el texto y responde SOLO en JSON con: {"correctedText": "texto corregido", "corrections": [{"original": "error", "corrected": "corrección", "type": "tipo", "explanation": "explicación"}], "score": 85}'
        },
        { 
          role: 'user', 
          content: `Corrige gramaticalmente este texto en español: ${text}` 
        }
      ],
      thinking: { type: 'disabled' }
    });

    const content = completion.choices[0]?.message?.content || '{}';
    
    let result;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      result = jsonMatch ? JSON.parse(jsonMatch[0]) : null;
    } catch {
      result = null;
    }

    if (!result) {
      result = {
        correctedText: text,
        corrections: [],
        score: 85
      };
    }

    return NextResponse.json({ result });
  } catch (error) {
    console.error('Grammar correction API error:', error);
    return NextResponse.json({ 
      result: {
        correctedText: text || '',
        corrections: [],
        score: 0
      }
    });
  }
}
