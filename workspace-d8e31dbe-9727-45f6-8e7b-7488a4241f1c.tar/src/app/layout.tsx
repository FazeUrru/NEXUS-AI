import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "NexusAI 7.4 - Plataforma de Inteligencia Artificial",
  description: "Tu plataforma completa de IA con 30+ funcionalidades, Captcha de seguridad obligatorio, Modo Agente y más. Versión 7.4",
  keywords: ["IA", "Inteligencia Artificial", "GPT-5", "Claude", "Grok", "Gemini", "Chat IA", "Agente IA", "Captcha"],
  authors: [{ name: "NexusAI Team" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}
