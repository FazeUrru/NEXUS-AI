'use client';

import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useAppStore, AI_MODELS, Conversation } from '@/store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Send, Bot, User, Loader2, Sparkles, Trash2, Plus, 
  MessageSquare, Save, ChevronDown, Zap, Archive, 
  ArchiveRestore, Pin, PinOff, Edit2, Share2, Copy,
  MoreHorizontal, ArrowDown, Brain, Search,
  Cpu, AlertCircle
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { useSyncExternalStore } from 'react';

// Simple text formatter for bold and basic markdown
function formatText(text: string): string {
  if (!text) return '';
  let result = text;
  // Bold
  result = result.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  // Italic
  result = result.replace(/\*([^*]+)\*/g, '<em>$1</em>');
  // Code
  result = result.replace(/`([^`]+)`/g, '<code class="bg-muted px-1 rounded">$1</code>');
  // Newlines
  result = result.replace(/\n/g, '<br/>');
  return result;
}

// Custom hook to detect if we're on the client (prevents hydration mismatch)
function useIsClient() {
  return useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  );
}

export function ChatFeature() {
  const { 
    messages, addMessage, isLoading, setIsLoading, profileSettings,
    conversations, createNewConversation, saveCurrentConversation,
    loadConversation, deleteConversation, currentConversationId,
    generalSettings, updateProfileSettings,
    archiveConversation, unarchiveConversation,
    pinConversation, unpinConversation,
    editConversationTitle, shareConversation,
    thinkModeEnabled, deepResearchEnabled,
    setThinkMode, setDeepResearch,
    chatMode, setChatMode
  } = useAppStore();
  
  // Client-side only mounting state using useSyncExternalStore
  const isClient = useIsClient();
  
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const lastMessageCountRef = useRef(0);
  const isUserScrollingRef = useRef(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const isTypingRef = useRef(false);
  
  // Dialog states
  const [editingConversation, setEditingConversation] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [shareUrl, setShareUrl] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'archived' | 'pinned'>('all');
  
  // Scroll state
  const [showScrollButton, setShowScrollButton] = useState(false);
  
  // Error state
  const [hasError, setHasError] = useState(false);

  // Scroll to bottom smoothly - only when explicitly requested
  const scrollToBottom = useCallback((behavior: 'smooth' | 'auto' = 'smooth') => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior });
    }
  }, []);

  // Handle scroll events to detect user scrolling
  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    if (!isClient) return;
    
    const target = e.target as HTMLDivElement;
    const { scrollTop, scrollHeight, clientHeight } = target;
    const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
    
    // Only update user scrolling if not typing
    if (!isTypingRef.current) {
      isUserScrollingRef.current = !isNearBottom;
    }
    setShowScrollButton(!isNearBottom && messages.length > 3);
  }, [messages.length, isClient]);

  // Effect to update message count - NO AUTO SCROLL
  useEffect(() => {
    if (!isClient) return;
    lastMessageCountRef.current = messages.length;
  }, [messages.length, isClient]);

  // Auto-save
  useEffect(() => {
    if (!isClient || !generalSettings.autoSave || messages.length === 0) return;
    
    const timer = setTimeout(() => {
      saveCurrentConversation();
    }, 5000);
    return () => clearTimeout(timer);
  }, [messages.length, generalSettings.autoSave, saveCurrentConversation, isClient]);

  // Handle sending message
  const handleSend = useCallback(async () => {
    if (!input.trim() || isLoading || !isClient) return;

    const userMessage = input.trim();
    setInput('');
    setHasError(false);
    
    // Mark that user just sent a message
    isTypingRef.current = false;
    isUserScrollingRef.current = false;
    
    addMessage({ role: 'user', content: userMessage });
    setIsLoading(true);
    
    // NO AUTO SCROLL - user controls scroll position

    try {
      const endpoint = deepResearchEnabled 
        ? '/api/ai/deep-research'
        : '/api/ai/chat';
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000); // 60s timeout
      
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: userMessage,
          model: profileSettings.aiModel,
          temperature: profileSettings.temperature,
          thinkMode: thinkModeEnabled,
          agentMode: chatMode === 'agent'
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.response) {
        addMessage({ 
          role: 'assistant', 
          content: data.response,
          thinking: data.thinking,
          sources: data.sources
        });
        // NO AUTO SCROLL - user controls scroll position
      } else {
        throw new Error('No response from server');
      }
    } catch (error) {
      console.error('Chat error:', error);
      setHasError(true);
      
      // Don't add error message to chat, just show toast
      if (error instanceof Error && error.name === 'AbortError') {
        toast.error('La solicitud tardó demasiado. Intenta de nuevo.');
      } else {
        toast.error('Error de conexión. Revisa tu conexión a internet.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [input, isLoading, isClient, deepResearchEnabled, profileSettings.aiModel, profileSettings.temperature, thinkModeEnabled, chatMode, addMessage, setIsLoading]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  const handleNewChat = useCallback(() => {
    saveCurrentConversation();
    createNewConversation('chat');
  }, [saveCurrentConversation, createNewConversation]);

  const handleLoadConversation = useCallback((conversationId: string) => {
    loadConversation(conversationId);
  }, [loadConversation]);

  const handleAction = useCallback((action: string, conv: Conversation, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    
    switch (action) {
      case 'delete':
        deleteConversation(conv.id);
        toast.success('Conversación eliminada');
        break;
      case 'archive':
        archiveConversation(conv.id);
        toast.success('Conversación archivada');
        break;
      case 'unarchive':
        unarchiveConversation(conv.id);
        toast.success('Conversación desarchivada');
        break;
      case 'pin':
        pinConversation(conv.id);
        toast.success('Conversación anclada');
        break;
      case 'unpin':
        unpinConversation(conv.id);
        toast.success('Conversación desanclada');
        break;
      case 'edit':
        setEditingConversation(conv.id);
        setEditTitle(conv.title);
        break;
      case 'share':
        const shareId = shareConversation(conv.id);
        setShareUrl(`${window.location.origin}?share=${shareId}`);
        setShareDialogOpen(true);
        break;
      case 'copy':
        navigator.clipboard.writeText(conv.messages.map(m => `${m.role}: ${m.content}`).join('\n\n'));
        toast.success('Copiado al portapapeles');
        break;
    }
  }, [deleteConversation, archiveConversation, unarchiveConversation, pinConversation, unpinConversation, shareConversation]);

  const handleSaveTitle = useCallback(() => {
    if (editingConversation && editTitle.trim()) {
      editConversationTitle(editingConversation, editTitle.trim());
      toast.success('Título actualizado');
      setEditingConversation(null);
    }
  }, [editingConversation, editTitle, editConversationTitle]);

  const formatTime = useCallback((timestamp: string) => {
    if (!isClient) return '';
    try {
      return new Date(timestamp).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  }, [isClient]);

  const formatDate = useCallback((timestamp: string) => {
    if (!isClient) return '';
    try {
      return new Date(timestamp).toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
    } catch {
      return '';
    }
  }, [isClient]);

  const currentModel = AI_MODELS.find(m => m.id === profileSettings.aiModel) || AI_MODELS[0];
  
  // Filter conversations - memoized for performance
  const chatConversations = useMemo(() => {
    if (!isClient) return [];
    return conversations
      .filter(c => c.featureType === 'chat' || c.featureType === 'deep-research' || c.featureType === 'think-mode')
      .filter(c => {
        if (filter === 'active') return c.status === 'active';
        if (filter === 'archived') return c.status === 'archived';
        if (filter === 'pinned') return c.status === 'pinned';
        return true;
      })
      .sort((a, b) => {
        if (a.status === 'pinned' && b.status !== 'pinned') return -1;
        if (b.status === 'pinned' && a.status !== 'pinned') return 1;
        return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
      })
      .slice(0, 30);
  }, [isClient, conversations, filter]);

  // Don't render until mounted on client
  if (!isClient) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="flex h-full">
      {/* Conversations Sidebar */}
      <div className="w-72 border-r bg-card/50 flex-col hidden md:flex">
        <div className="p-3 border-b space-y-2 shrink-0">
          <Button onClick={handleNewChat} className="w-full bg-emerald-600 hover:bg-emerald-700">
            <Plus className="mr-2 h-4 w-4" />
            Nueva Conversación
          </Button>
          
          <div className="flex gap-1">
            {['all', 'pinned', 'archived'].map(f => (
              <Button
                key={f}
                variant={filter === f ? 'secondary' : 'ghost'}
                size="sm"
                className="flex-1 text-xs"
                onClick={() => setFilter(f as typeof filter)}
              >
                {f === 'all' ? 'Todas' : f === 'pinned' ? 'Ancladas' : 'Archivadas'}
              </Button>
            ))}
          </div>
        </div>
        
        <ScrollArea className="flex-1 p-2 overflow-y-auto">
          <div className="space-y-1">
            <p className="text-xs font-medium text-muted-foreground px-2 py-1">
              Historial ({chatConversations.length})
            </p>
            {chatConversations.length === 0 ? (
              <p className="text-xs text-muted-foreground px-2 py-4 text-center">
                No hay conversaciones
              </p>
            ) : (
              chatConversations.map((conv) => (
                <div key={conv.id} className="group">
                  <div
                    className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-colors ${
                      currentConversationId === conv.id 
                        ? 'bg-emerald-100 dark:bg-emerald-900/30' 
                        : 'hover:bg-muted'
                    }`}
                    onClick={() => handleLoadConversation(conv.id)}
                  >
                    <MessageSquare className="h-4 w-4 shrink-0 text-muted-foreground" />
                    <div className="flex-1 min-w-0">
                      <p className="truncate text-xs font-medium">{conv.title}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {formatDate(conv.updatedAt)} • {conv.messages.length} msgs
                      </p>
                    </div>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0 opacity-0 group-hover:opacity-100">
                          <MoreHorizontal className="h-3 w-3" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuItem onClick={(e) => handleAction('edit', conv, e)}>
                          <Edit2 className="h-4 w-4 mr-2" />Editar título
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => handleAction('copy', conv, e)}>
                          <Copy className="h-4 w-4 mr-2" />Copiar
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => handleAction('share', conv, e)}>
                          <Share2 className="h-4 w-4 mr-2" />Compartir
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        {conv.status === 'pinned' ? (
                          <DropdownMenuItem onClick={(e) => handleAction('unpin', conv, e)}>
                            <PinOff className="h-4 w-4 mr-2" />Desanclar
                          </DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem onClick={(e) => handleAction('pin', conv, e)}>
                            <Pin className="h-4 w-4 mr-2" />Anclar
                          </DropdownMenuItem>
                        )}
                        {conv.status === 'archived' ? (
                          <DropdownMenuItem onClick={(e) => handleAction('unarchive', conv, e)}>
                            <ArchiveRestore className="h-4 w-4 mr-2" />Desarchivar
                          </DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem onClick={(e) => handleAction('archive', conv, e)}>
                            <Archive className="h-4 w-4 mr-2" />Archivar
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={(e) => handleAction('delete', conv, e)} className="text-red-600">
                          <Trash2 className="h-4 w-4 mr-2" />Eliminar
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Chat Header */}
        <div className="border-b px-4 py-2 flex items-center justify-between bg-card/30 shrink-0 flex-wrap gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <Bot className="h-5 w-5 text-emerald-600" />
            <span className="font-medium">NexusAI 7.6</span>
            {chatMode === 'agent' && (
              <Badge className="bg-purple-100 text-purple-700 text-xs">
                <Cpu className="h-3 w-3 mr-1" />Agente
              </Badge>
            )}
            
            {/* Quick Actions */}
            <Button
              variant={chatMode === 'agent' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setChatMode && setChatMode(chatMode === 'agent' ? 'chat' : 'agent')}
              className={chatMode === 'agent' ? 'bg-purple-600 hover:bg-purple-700' : ''}
            >
              <Cpu className="h-3 w-3 mr-1" />
              Agente
            </Button>
            <Button
              variant={deepResearchEnabled ? 'default' : 'outline'}
              size="sm"
              onClick={() => { setDeepResearch(!deepResearchEnabled); setThinkMode(false); }}
              className={deepResearchEnabled ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
            >
              <Search className="h-3 w-3 mr-1" />
              Investigar
            </Button>
            <Button
              variant={thinkModeEnabled ? 'default' : 'outline'}
              size="sm"
              onClick={() => { setThinkMode(!thinkModeEnabled); setDeepResearch(false); }}
              className={thinkModeEnabled ? 'bg-purple-600 hover:bg-purple-700' : ''}
            >
              <Brain className="h-3 w-3 mr-1" />
              Pensar
            </Button>
            
            {/* Model Selector */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1">
                  <Zap className="h-3 w-3" />
                  <span className="hidden lg:inline">{currentModel.name}</span>
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-64 max-h-80 overflow-y-auto">
                {AI_MODELS.map((model) => (
                  <DropdownMenuItem
                    key={model.id}
                    onClick={() => updateProfileSettings({ aiModel: model.id })}
                    className={profileSettings.aiModel === model.id ? 'bg-emerald-50 dark:bg-emerald-900/20' : ''}
                  >
                    <div className="flex-1">
                      <div className="font-medium">{model.name}</div>
                      <div className="text-xs text-muted-foreground">{model.provider}</div>
                    </div>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={handleNewChat}>
              <Plus className="h-4 w-4 mr-1" />Nuevo
            </Button>
            <Button variant="ghost" size="sm" onClick={saveCurrentConversation}>
              <Save className="h-4 w-4 mr-1" />Guardar
            </Button>
          </div>
        </div>

        {/* Mode Indicators */}
        {(thinkModeEnabled || deepResearchEnabled || chatMode === 'agent') && (
          <div className="px-4 py-2 bg-emerald-50 dark:bg-emerald-900/20 border-b flex items-center gap-2 flex-wrap">
            {chatMode === 'agent' && (
              <Badge className="bg-purple-100 text-purple-700">
                <Cpu className="h-3 w-3 mr-1" />Agente
              </Badge>
            )}
            {thinkModeEnabled && (
              <Badge className="bg-purple-100 text-purple-700">
                <Brain className="h-3 w-3 mr-1" />Pensar
              </Badge>
            )}
            {deepResearchEnabled && (
              <Badge className="bg-blue-100 text-blue-700">
                <Search className="h-3 w-3 mr-1" />Investigación
              </Badge>
            )}
          </div>
        )}

        {/* Chat Messages */}
        <div className="flex-1 relative overflow-hidden">
          <ScrollArea ref={scrollAreaRef} className="h-full p-4" onScroll={handleScroll}>
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-center px-4 min-h-[400px]">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center mb-4">
                  {chatMode === 'agent' ? <Cpu className="h-8 w-8 text-white" /> : <Sparkles className="h-8 w-8 text-white" />}
                </div>
                <h3 className="text-xl font-bold mb-2">
                  {chatMode === 'agent' ? '¡Hola! Soy el Agente IA' : '¡Hola! Soy NexusAI 7.6'}
                </h3>
                <p className="text-muted-foreground max-w-md mb-4">
                  Modelo: {currentModel.name} • Listo para conversar
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-w-md w-full">
                  {['Explícame quantum computing', 'Escribe un poema sobre IA', 'Ayuda con código Python', 'Genera ideas creativas'].map((suggestion) => (
                    <Button
                      key={suggestion}
                      variant="outline"
                      className="h-auto py-2 text-left justify-start hover:bg-emerald-50"
                      onClick={() => setInput(suggestion)}
                    >
                      {suggestion}
                    </Button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4 max-w-4xl mx-auto pb-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    {message.role === 'assistant' && (
                      <Avatar className="h-8 w-8 shrink-0">
                        <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                          {chatMode === 'agent' ? <Cpu className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                        </AvatarFallback>
                      </Avatar>
                    )}
                    <div className={`max-w-[85%] ${message.role === 'user' ? 'order-first' : ''}`}>
                      {/* Thinking block */}
                      {message.thinking && (
                        <Card className="p-3 mb-2 bg-purple-50 dark:bg-purple-900/20">
                          <div className="flex items-center gap-2 mb-1">
                            <Brain className="h-4 w-4 text-purple-600" />
                            <span className="text-xs font-medium text-purple-600">Pensamiento</span>
                          </div>
                          <p className="text-xs text-muted-foreground italic">{message.thinking}</p>
                        </Card>
                      )}
                      
                      {/* Sources block */}
                      {message.sources && message.sources.length > 0 && (
                        <Card className="p-3 mb-2 bg-blue-50 dark:bg-blue-900/20">
                          <div className="flex items-center gap-2 mb-1">
                            <Search className="h-4 w-4 text-blue-600" />
                            <span className="text-xs font-medium text-blue-600">Fuentes</span>
                          </div>
                          <div className="space-y-1">
                            {message.sources.map((source, i) => (
                              <a key={i} href={source.url} target="_blank" rel="noopener noreferrer" className="block text-xs text-blue-600 hover:underline truncate">
                                {i + 1}. {source.title}
                              </a>
                            ))}
                          </div>
                        </Card>
                      )}
                      
                      <Card className={`p-4 ${message.role === 'user' ? 'bg-emerald-600 text-white' : 'bg-muted'}`}>
                        {message.role === 'assistant' ? (
                          <div dangerouslySetInnerHTML={{ __html: formatText(message.content) }} />
                        ) : (
                          <p className="whitespace-pre-wrap">{message.content}</p>
                        )}
                      </Card>
                      <p className="text-xs text-muted-foreground mt-1 px-1">
                        {formatTime(message.timestamp)}
                      </p>
                    </div>
                    {message.role === 'user' && (
                      <Avatar className="h-8 w-8 shrink-0">
                        <AvatarFallback className="bg-primary">
                          <User className="h-4 w-4" />
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex gap-3 justify-start">
                    <Avatar className="h-8 w-8 shrink-0">
                      <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                        <Bot className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                    <Card className="bg-muted p-4">
                      <div className="flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin text-emerald-600" />
                        <span className="text-muted-foreground">Procesando con {currentModel.name}...</span>
                      </div>
                    </Card>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </ScrollArea>
          
          {showScrollButton && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10">
              <Button variant="secondary" size="sm" onClick={() => scrollToBottom('smooth')} className="rounded-full bg-emerald-600 hover:bg-emerald-700 text-white">
                <ArrowDown className="h-4 w-4 mr-1" />Ir abajo
              </Button>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="border-t p-4 bg-card/30 shrink-0">
          {/* Error indicator */}
          {hasError && (
            <div className="flex items-center gap-2 mb-2 text-sm text-red-600 bg-red-50 dark:bg-red-900/20 p-2 rounded-lg">
              <AlertCircle className="h-4 w-4" />
              <span>Error de conexión. El mensaje no se envió.</span>
              <Button variant="ghost" size="sm" onClick={() => setHasError(false)} className="ml-auto">
                ✕
              </Button>
            </div>
          )}
          
          <div className="flex gap-2 max-w-4xl mx-auto">
            <Textarea
              ref={inputRef}
              value={input}
              onChange={(e) => {
                setInput(e.target.value);
                isTypingRef.current = true;
              }}
              onFocus={() => {
                isTypingRef.current = true;
              }}
              onBlur={() => {
                // Delay to allow click events to fire
                setTimeout(() => {
                  isTypingRef.current = false;
                }, 200);
              }}
              onKeyDown={handleKeyDown}
              placeholder="Escribe tu mensaje... (Enter para enviar)"
              className="min-h-[44px] max-h-32 resize-none"
              rows={1}
              disabled={isLoading}
            />
            <Button 
              onClick={handleSend} 
              disabled={!input.trim() || isLoading}
              className="bg-emerald-600 hover:bg-emerald-700 shrink-0 px-4"
            >
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground text-center mt-2">
            Enter para enviar • Shift+Enter para nueva línea • {currentModel.name}
          </p>
        </div>
      </div>
      
      {/* Edit Title Dialog */}
      <Dialog open={!!editingConversation} onOpenChange={() => setEditingConversation(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar título</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} placeholder="Nuevo título..." onKeyDown={(e) => e.key === 'Enter' && handleSaveTitle()} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingConversation(null)}>Cancelar</Button>
            <Button onClick={handleSaveTitle} className="bg-emerald-600 hover:bg-emerald-700">Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Share Dialog */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Compartir conversación</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <p className="text-sm text-muted-foreground">Cualquiera con este enlace puede ver la conversación.</p>
            <div className="flex gap-2">
              <Input value={shareUrl} readOnly className="flex-1" />
              <Button onClick={() => { navigator.clipboard.writeText(shareUrl); toast.success('URL copiada'); }}><Copy className="h-4 w-4" /></Button>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setShareDialogOpen(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
